#!/usr/bin/env python3
"""Regenerate CGT Figure 1 from its frozen source-data workbook.

This revision changes only presentation and scientific wording. It recomputes all
displayed summary statistics from the workbook, validates the shuffle scope when
the upstream fold-level table is supplied, and fails if text leaves the fixed
publication canvas, escapes a workflow container, or collides with a protected
layout element.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import re
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import sklearn
from matplotlib.colors import Normalize
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle
from scipy.stats import spearmanr
from sklearn.metrics import r2_score


MM = 1 / 25.4
FIGURE_SIZE_MM = (183, 165)
FONT_FAMILY = "DejaVu Sans"

COLORS = {
    "ink": "#17222D",
    "muted": "#5E6B77",
    "grid": "#DCE3E8",
    "neutral": "#8B98A3",
    "neutral_light": "#D6DDE2",
    "blue": "#0072B2",
    "blue_dark": "#174F78",
    "blue_light": "#DCECF5",
    "green": "#009E73",
    "green_light": "#E4F3EE",
    "purple": "#6F5AA8",
    "purple_light": "#EEEAF5",
    "gold": "#E69F00",
    "gold_light": "#FAEED8",
    "vermilion": "#D55E00",
    "external": "#C66B00",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require_columns(frame: pd.DataFrame, sheet: str, columns: set[str]) -> None:
    missing = columns.difference(frame.columns)
    if missing:
        raise ValueError(f"{sheet}: missing columns {sorted(missing)}")


def load_source(workbook: Path) -> dict[str, pd.DataFrame]:
    required = {
        "Fig1a_workflow": {
            "n_datasets", "n_contexts", "n_coordinate_rows", "n_families",
            "n_genes", "external_endpoint",
        },
        "Fig1b_oof": {
            "gene_symbol", "essentiality_strength",
            "predicted_essentiality_strength", "n_rows", "n_datasets",
            "n_contexts",
        },
        "Fig1c_regression": {"source", "value", "replicate_id"},
        "Fig1d_classification": {"source", "value", "replicate_id"},
        "Fig1e_weights": {
            "feature", "family", "short_label", "ridge_coef", "abs_ridge_coef",
        },
        "Fig1f_robustness": {
            "scheme", "scheme_label", "variant", "variant_label", "task", "metric",
        },
    }
    xls = pd.ExcelFile(workbook)
    absent = set(required).difference(xls.sheet_names)
    if absent:
        raise ValueError(f"Workbook missing sheets: {sorted(absent)}")
    data = {name: pd.read_excel(workbook, sheet_name=name) for name in required}
    for name, columns in required.items():
        require_columns(data[name], name, columns)
        if data[name].isna().any().any():
            raise ValueError(f"{name}: missing values are not allowed")

    workflow = data["Fig1a_workflow"]
    if len(workflow) != 1:
        raise ValueError("Fig1a_workflow must contain exactly one row")

    oof = data["Fig1b_oof"]
    if len(oof) != oof["gene_symbol"].nunique() or len(oof) != 1229:
        raise ValueError("Fig1b_oof must contain one row for each of 1,229 genes")

    for sheet in ("Fig1c_regression", "Fig1d_classification"):
        counts = data[sheet]["source"].value_counts().to_dict()
        if counts != {"endpoint_shuffle_mean": 100, "observed_fold": 5}:
            raise ValueError(f"{sheet}: expected 5 observed folds and 100 shuffle means; got {counts}")

    weights = data["Fig1e_weights"]
    if len(weights) != 8 or not np.allclose(
        weights["abs_ridge_coef"], weights["ridge_coef"].abs()
    ):
        raise ValueError("Fig1e_weights must contain the exported top-eight coefficients")

    robust = data["Fig1f_robustness"]
    expected_combinations = 3 * 3 * 2
    if len(robust) != expected_combinations:
        raise ValueError("Fig1f_robustness must be a complete 3 x 3 x 2 table")
    return data


def validate_upstream_shuffles(path: Path | None, source: dict[str, pd.DataFrame]) -> dict:
    if path is None:
        return {"validated": False, "reason": "upstream shuffle table not supplied"}

    frame = pd.read_csv(path)
    required = {"benchmark", "task", "model", "fold", "shuffle_id", "spearman", "roc_auc"}
    require_columns(frame, path.name, required)
    normalized = frame["benchmark"].astype(str).str.replace(
        r"^endpoint_shuffle_\d+__", "", regex=True
    )
    if set(normalized) != {"context__groupby_gene"}:
        raise ValueError(f"Unexpected shuffle benchmark scope: {sorted(set(normalized))}")

    report: dict[str, object] = {
        "validated": True,
        "normalized_benchmark": "context__groupby_gene",
        "tasks": {},
    }
    task_map = {
        "regression": ("spearman", "Fig1c_regression"),
        "classification": ("roc_auc", "Fig1d_classification"),
    }
    for task, (metric, sheet) in task_map.items():
        subset = frame[(frame["task"] == task) & (frame["model"] == "rf")].copy()
        fold_counts = subset.groupby("shuffle_id").size()
        if subset["shuffle_id"].nunique() != 100 or set(fold_counts) != {5}:
            raise ValueError(f"{task}: expected 100 shuffles with five folds apiece")
        recomputed = subset.groupby("shuffle_id")[metric].mean().sort_index().to_numpy()
        exported = (
            source[sheet].query("source == 'endpoint_shuffle_mean'")
            .sort_values("replicate_id")["value"].to_numpy()
        )
        if not np.allclose(recomputed, exported, atol=5e-13, rtol=0):
            raise ValueError(f"{task}: exported shuffle means do not match upstream fold table")
        report["tasks"][task] = {
            "n_shuffles": 100,
            "folds_per_shuffle": 5,
            "null_mean": float(recomputed.mean()),
            "null_min": float(recomputed.min()),
            "null_max": float(recomputed.max()),
        }
    return report


def set_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": FONT_FAMILY,
            "font.size": 6.4,
            "axes.titlesize": 8.1,
            "axes.titleweight": "bold",
            "axes.labelsize": 7.1,
            "axes.labelcolor": COLORS["ink"],
            "axes.edgecolor": COLORS["ink"],
            "axes.linewidth": 0.72,
            "xtick.labelsize": 6.2,
            "ytick.labelsize": 6.2,
            "xtick.color": COLORS["ink"],
            "ytick.color": COLORS["ink"],
            "xtick.major.width": 0.65,
            "ytick.major.width": 0.65,
            "xtick.major.size": 2.7,
            "ytick.major.size": 2.7,
            "text.color": COLORS["ink"],
            "axes.spines.top": False,
            "axes.spines.right": False,
            "svg.fonttype": "path",
            "pdf.fonttype": 42,
            "pdf.use14corefonts": False,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
        }
    )


def panel_letter(ax: mpl.axes.Axes, letter: str, x: float = -0.14, y: float = 1.06) -> None:
    ax.text(
        x, y, letter, transform=ax.transAxes, ha="left", va="bottom",
        fontsize=9.2, fontweight="bold", clip_on=False,
    )


def clean_axis(ax: mpl.axes.Axes, grid_axis: str | None = "y") -> None:
    if grid_axis:
        ax.grid(True, axis=grid_axis, color=COLORS["grid"], linewidth=0.55, zorder=0)
    ax.set_axisbelow(True)


def draw_box(
    ax: mpl.axes.Axes,
    x: float,
    y: float,
    w: float,
    h: float,
    title: str,
    body: str,
    edge: str,
    face: str,
    audit_id: str,
) -> None:
    box = FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.012,rounding_size=0.018",
        transform=ax.transAxes,
        facecolor=face,
        edgecolor=edge,
        linewidth=1.05,
        clip_on=False,
    )
    box.set_gid(f"audit_container:{audit_id}")
    ax.add_patch(box)
    title_artist = ax.text(
        x + 0.055 * w, y + 0.732 * h, title,
        transform=ax.transAxes, ha="left", va="center",
        fontsize=6.7, fontweight="bold", linespacing=0.98,
    )
    body_artist = ax.text(
        x + 0.055 * w, y + 0.255 * h, body,
        transform=ax.transAxes, ha="left", va="center",
        fontsize=6.0, color=COLORS["muted"], linespacing=1.02,
    )
    title_artist.set_gid(f"audit_contained_text:{audit_id}:title")
    body_artist.set_gid(f"audit_contained_text:{audit_id}:body")


def panel_a(ax: mpl.axes.Axes, workflow: pd.DataFrame) -> None:
    ax.set_axis_off()
    panel_letter(ax, "a", x=-0.012, y=0.91)
    row = workflow.iloc[0]
    x_positions = [0.004, 0.203, 0.402, 0.601, 0.800]
    width = 0.166
    y, height = 0.22, 0.56
    boxes = [
        (
            "Perturb-seq\ninput",
            f"{int(row.n_coordinate_rows):,} response profiles\n"
            f"{int(row.n_datasets)} datasets · {int(row.n_contexts)} contexts",
            COLORS["blue"], COLORS["blue_light"],
        ),
        (
            "Context-mean\nsubtraction",
            "r = y − E[y | context]\nestimated shift removed",
            COLORS["green"], COLORS["green_light"],
        ),
        (
            "Gene-level\nCGT features",
            f"{int(row.n_families)} family summaries\n"
            f"{int(row.n_genes):,} measured genes",
            COLORS["purple"], COLORS["purple_light"],
        ),
        (
            "Supervised\nmapping",
            "random forest\n5-fold gene-grouped CV",
            COLORS["blue_dark"], "#E8F0F5",
        ),
        (
            "External fitness\nendpoint",
            "−GeneEffect endpoint\nDepMap 26Q1 CRISPR",
            COLORS["external"], COLORS["gold_light"],
        ),
    ]
    for index, (x, (title, body, edge, face)) in enumerate(zip(x_positions, boxes)):
        draw_box(ax, x, y, width, height, title, body, edge, face, f"panel_a_box_{index}")
    for i in range(4):
        x0 = x_positions[i] + width + 0.005
        x1 = x_positions[i + 1] - 0.006
        arrow = FancyArrowPatch(
            (x0, y + height / 2), (x1, y + height / 2),
            transform=ax.transAxes, arrowstyle="-|>", mutation_scale=8,
            linewidth=0.95, color=COLORS["muted"], clip_on=False,
        )
        ax.add_patch(arrow)
    boundary_x = x_positions[4] - 0.019
    for lower, upper in ((0.11, 0.42), (0.58, 0.88)):
        ax.plot(
            [boundary_x, boundary_x], [lower, upper], transform=ax.transAxes,
            color="#98A3AD", linewidth=0.8, linestyle=(0, (3, 3)), clip_on=False,
        )
    ax.text(
        boundary_x, 0.91, "external data source", transform=ax.transAxes,
        ha="center", va="bottom", fontsize=6.2, color=COLORS["muted"],
    )


def panel_b(ax: mpl.axes.Axes, oof: pd.DataFrame) -> dict[str, float]:
    x = oof["essentiality_strength"].to_numpy(float)
    y = oof["predicted_essentiality_strength"].to_numpy(float)
    rho = float(spearmanr(x, y).statistic)
    r2 = float(r2_score(x, y))
    slope, intercept = np.polyfit(x, y, 1)

    points = ax.scatter(
        x, y, s=6.3, color=COLORS["neutral"], alpha=0.37, linewidths=0, zorder=2
    )
    points.set_gid("audit_points:panel_b_oof")
    xx = np.linspace(min(-0.48, x.min()), max(3.32, x.max()), 200)
    ax.plot(xx, xx, color=COLORS["muted"], linestyle=(0, (3, 3)), linewidth=0.85,
            label="identity", zorder=1)
    ax.plot(xx, intercept + slope * xx, color=COLORS["blue_dark"], linewidth=1.45,
            label="OLS fit", zorder=3)
    ax.set_xlim(-0.52, 3.35)
    ax.set_ylim(-0.18, 3.35)
    ax.set_xticks([0, 1, 2, 3])
    ax.set_yticks(np.arange(0, 3.1, 0.5))
    ax.set_xlabel("Observed essentiality strength (−GeneEffect)")
    ax.set_ylabel("Out-of-fold prediction")
    ax.set_title("Gene-level OOF prediction", pad=4)
    panel_letter(ax, "b")
    statistics = ax.text(
        0.04, 0.96,
        f"n = {len(oof):,}\nSpearman ρ = {rho:.3f}\nR²$_{{pred}}$ = {r2:.3f}",
        transform=ax.transAxes, ha="left", va="top", fontsize=6.35,
        bbox={"boxstyle": "round,pad=0.18", "facecolor": "white", "edgecolor": "none", "alpha": 0.88},
        zorder=5,
    )
    statistics.set_gid("audit_protected:panel_b_statistics")
    legend = ax.legend(
        loc="upper right", frameon=True, framealpha=0.93, facecolor="white",
        edgecolor=COLORS["grid"], fontsize=6.0, handlelength=1.6, borderpad=0.35,
    )
    legend.set_gid("audit_protected:panel_b_legend")
    clean_axis(ax)
    return {"n_genes": len(oof), "pooled_spearman": rho, "predictive_r2": r2,
            "ols_slope": float(slope), "ols_intercept": float(intercept)}


def _null_comparison(
    ax: mpl.axes.Axes,
    frame: pd.DataFrame,
    ylabel: str,
    title: str,
    letter: str,
    chance: float,
    ylim: tuple[float, float],
) -> dict[str, float]:
    observed = frame.query("source == 'observed_fold'")["value"].to_numpy(float)
    null = frame.query("source == 'endpoint_shuffle_mean'")["value"].to_numpy(float)
    mean_observed = float(np.mean(observed))
    p_perm = float((1 + np.sum(null >= mean_observed)) / (1 + len(null)))

    violin = ax.violinplot(
        [null], positions=[0], widths=0.62, showmeans=False, showmedians=True, showextrema=False,
    )
    for body in violin["bodies"]:
        body.set_facecolor(COLORS["neutral_light"])
        body.set_edgecolor(COLORS["muted"])
        body.set_linewidth(0.8)
        body.set_alpha(0.86)
    violin["cmedians"].set_color(COLORS["muted"])
    violin["cmedians"].set_linewidth(0.8)

    jitter = np.linspace(-0.07, 0.07, len(observed))
    ax.plot([1, 1], [observed.min(), observed.max()], color=COLORS["blue_dark"], linewidth=0.9, zorder=2)
    ax.scatter(1 + jitter, observed, s=15, facecolor="white", edgecolor=COLORS["blue"],
               linewidth=0.8, zorder=3, label="fold")
    ax.scatter([1], [mean_observed], s=37, marker="D", color=COLORS["blue_dark"],
               edgecolor="white", linewidth=0.65, zorder=4, label="mean")
    ax.axhline(chance, color=COLORS["muted"], linewidth=0.75, linestyle=(0, (2.5, 2.5)), zorder=1)

    ax.set_xticks([0, 1], ["Endpoint shuffled\n100 CV means", "Observed\n5 folds"])
    ax.set_ylabel(ylabel)
    ax.set_ylim(*ylim)
    ax.set_xlim(-0.48, 1.48)
    if chance == 0.0:
        ax.set_yticks(np.arange(-0.1, 0.71, 0.1))
    else:
        ax.set_yticks(np.arange(0.4, 0.96, 0.1))
    display_title = "Essential-gene\nclassification" if title == "Essential-gene classification" else title
    ax.set_title(display_title, pad=2.5)
    panel_letter(ax, letter)
    ax.text(
        0.96, 0.52,
        f"mean = {mean_observed:.3f}\none-sided P$_{{perm}}$ = {p_perm:.4f}",
        transform=ax.transAxes, ha="right", va="center", fontsize=6.05,
        bbox={"boxstyle": "round,pad=0.15", "facecolor": "white", "edgecolor": "none", "alpha": 0.9},
    )
    ax.text(
        0.03, 0.955, "diamond = fold mean", transform=ax.transAxes,
        ha="left", va="top", fontsize=6.0, color=COLORS["muted"],
    )
    clean_axis(ax)
    return {
        "observed_fold_mean": mean_observed,
        "null_mean": float(null.mean()),
        "null_max": float(null.max()),
        "permutation_p_plus_one": p_perm,
        "n_shuffles": len(null),
    }


def panel_e(ax_labels: mpl.axes.Axes, ax: mpl.axes.Axes, weights: pd.DataFrame) -> None:
    ordered = weights.sort_values("abs_ridge_coef", ascending=True).reset_index(drop=True)
    y = np.arange(len(ordered))
    colors = [COLORS["blue"] if v > 0 else COLORS["vermilion"] for v in ordered["ridge_coef"]]
    ax.barh(y, ordered["ridge_coef"], color=colors, height=0.62, zorder=3)
    ax.axvline(0, color=COLORS["ink"], linewidth=0.8, zorder=2)
    ax.set_yticks(y, [])
    ax.set_xlim(-0.29, 0.14)
    ax.set_ylim(-0.7, len(ordered) - 0.3)
    ax.set_xlabel("Standardized ridge coefficient")
    clean_axis(ax, grid_axis="x")
    ax_labels.text(
        0.0, 1.115, "Conditional weights (top 8 of 16)",
        transform=ax_labels.transAxes, ha="left", va="bottom",
        fontsize=8.1, fontweight="bold", clip_on=False,
    )
    ax_labels.text(
        0.0, 1.045, "mean |residual| · descriptive point estimates",
        transform=ax_labels.transAxes, ha="left", va="bottom",
        fontsize=6.0, color=COLORS["muted"], clip_on=False,
    )

    ax_labels.set_xlim(0, 1)
    ax_labels.set_ylim(ax.get_ylim())
    ax_labels.set_axis_off()
    for yi, row in ordered.iterrows():
        label = re.sub(r"^F(\d+)\s+", r"F\1 · ", str(row["short_label"]))
        ax_labels.text(0.98, yi, label, ha="right", va="center", fontsize=6.2)
    panel_letter(ax_labels, "e", x=-0.19, y=1.115)


def heatmap(
    ax: mpl.axes.Axes,
    values: np.ndarray,
    title: str,
    vmin: float,
    vmax: float,
    show_y: bool,
    letter: str | None = None,
) -> None:
    rows = ["Context mean", "Dataset shrink", "Dataset mean"]
    cols = ["Mean", "+ median", "+ s.d."]
    norm = Normalize(vmin=vmin, vmax=vmax)
    cmap = mpl.colormaps["Blues"]
    for i in range(3):
        for j in range(3):
            value = float(values[i, j])
            rect = Rectangle(
                (j, i), 1, 1, facecolor=cmap(norm(value)), edgecolor="white", linewidth=0.8,
            )
            ax.add_patch(rect)
            rgba = cmap(norm(value))
            luminance = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
            text_color = "white" if luminance < 0.58 else COLORS["ink"]
            ax.text(j + 0.5, i + 0.5, f"{value:.3f}", ha="center", va="center",
                    fontsize=6.05, fontweight="bold", color=text_color)
    ax.set_xlim(0, 3)
    ax.set_ylim(3, 0)
    ax.set_aspect("auto")
    ax.set_xticks(np.arange(3) + 0.5, cols)
    ax.set_yticks(np.arange(3) + 0.5, rows if show_y else ["", "", ""])
    ax.tick_params(length=0, pad=2)
    ax.set_title(f"{title}\ncolor scale {vmin:.2f}–{vmax:.2f}", pad=3, fontsize=7.6)
    for spine in ax.spines.values():
        spine.set_visible(False)
    if letter:
        panel_letter(ax, letter, x=-0.31, y=1.06)


def panel_f(ax_reg: mpl.axes.Axes, ax_cls: mpl.axes.Axes, robust: pd.DataFrame) -> dict:
    scheme_order = ["context", "dataset_shrink", "dataset"]
    variant_order = ["mean", "mean_median", "mean_median_sd"]

    def matrix(task: str) -> np.ndarray:
        pivot = robust.query("task == @task").pivot(index="scheme", columns="variant", values="metric")
        return pivot.loc[scheme_order, variant_order].to_numpy(float)

    reg = matrix("regression")
    cls = matrix("classification")
    heatmap(ax_reg, reg, "Regression: Spearman ρ", 0.45, 0.65, True, "f")
    heatmap(ax_cls, cls, "Classification: ROC AUC", 0.75, 0.95, False)
    return {
        "regression": reg.tolist(),
        "classification": cls.tolist(),
        "scheme_order": scheme_order,
        "variant_order": variant_order,
    }


def _intersection_area(first: object, second: object) -> float:
    """Return the intersection area of two display-coordinate bounding boxes."""
    width = max(0.0, min(first.x1, second.x1) - max(first.x0, second.x0))
    height = max(0.0, min(first.y1, second.y1) - max(first.y0, second.y0))
    return float(width * height)


def audit_text_bounds(
    fig: mpl.figure.Figure,
    safety_pt: float = 1.5,
    container_inset_pt: float = 2.0,
) -> dict:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    margin_px = safety_pt * fig.dpi / 72
    outside: list[dict] = []
    fonts: list[float] = []
    rendered_text: list[tuple[mpl.text.Text, object]] = []
    for artist in fig.findobj(mpl.text.Text):
        if not artist.get_visible() or not artist.get_text().strip():
            continue
        fonts.append(float(artist.get_fontsize()))
        bbox = artist.get_window_extent(renderer=renderer)
        rendered_text.append((artist, bbox))
        if (
            bbox.x0 < bounds.x0 + margin_px
            or bbox.y0 < bounds.y0 + margin_px
            or bbox.x1 > bounds.x1 - margin_px
            or bbox.y1 > bounds.y1 - margin_px
        ):
            outside.append(
                {
                    "text": artist.get_text(),
                    "bbox_px": [float(v) for v in bbox.extents],
                }
            )
    overlaps: list[dict] = []
    for index, (first, bbox_first) in enumerate(rendered_text):
        for second, bbox_second in rendered_text[index + 1:]:
            overlap_area = _intersection_area(bbox_first, bbox_second)
            if overlap_area > 10.0:
                overlaps.append(
                    {
                        "first": first.get_text(),
                        "second": second.get_text(),
                        "overlap_area_px2": overlap_area,
                    }
                )

    containers: dict[str, object] = {}
    contained_text: list[tuple[str, mpl.text.Text]] = []
    protected: dict[str, object] = {}
    point_sets: dict[str, object] = {}
    for artist in fig.findobj():
        get_gid = getattr(artist, "get_gid", None)
        if get_gid is None:
            continue
        gid = get_gid()
        if not isinstance(gid, str):
            continue
        if gid.startswith("audit_container:"):
            containers[gid.split(":", 1)[1]] = artist
        elif gid.startswith("audit_contained_text:"):
            _, container_id, role = gid.split(":", 2)
            contained_text.append((f"{container_id}:{role}", artist))
        elif gid.startswith("audit_protected:"):
            protected[gid.split(":", 1)[1]] = artist
        elif gid.startswith("audit_points:"):
            point_sets[gid.split(":", 1)[1]] = artist

    inset_px = container_inset_pt * fig.dpi / 72
    container_violations: list[dict] = []
    container_checks: list[dict] = []
    for qualified_id, artist in contained_text:
        container_id, role = qualified_id.rsplit(":", 1)
        container = containers.get(container_id)
        if container is None:
            container_violations.append(
                {"container": container_id, "role": role, "reason": "container not found"}
            )
            continue
        text_bbox = artist.get_window_extent(renderer=renderer)
        container_bbox = container.get_window_extent(renderer=renderer)
        clearances_px = {
            "left": float(text_bbox.x0 - container_bbox.x0),
            "bottom": float(text_bbox.y0 - container_bbox.y0),
            "right": float(container_bbox.x1 - text_bbox.x1),
            "top": float(container_bbox.y1 - text_bbox.y1),
        }
        container_checks.append(
            {
                "container": container_id,
                "role": role,
                "minimum_clearance_pt": float(min(clearances_px.values()) * 72 / fig.dpi),
                "clearances_px": clearances_px,
            }
        )
        inside = (
            text_bbox.x0 >= container_bbox.x0 + inset_px
            and text_bbox.y0 >= container_bbox.y0 + inset_px
            and text_bbox.x1 <= container_bbox.x1 - inset_px
            and text_bbox.y1 <= container_bbox.y1 - inset_px
        )
        if not inside:
            container_violations.append(
                {
                    "container": container_id,
                    "role": role,
                    "text": artist.get_text(),
                    "text_bbox_px": [float(v) for v in text_bbox.extents],
                    "container_bbox_px": [float(v) for v in container_bbox.extents],
                }
            )

    protected_pairs = [("panel_b_statistics", "panel_b_legend")]
    protected_overlaps: list[dict] = []
    protected_pair_checks: list[dict] = []
    for first_id, second_id in protected_pairs:
        first = protected.get(first_id)
        second = protected.get(second_id)
        if first is None or second is None:
            protected_overlaps.append(
                {
                    "first": first_id,
                    "second": second_id,
                    "reason": "protected artist not found",
                }
            )
            continue
        first_bbox = first.get_window_extent(renderer=renderer)
        second_bbox = second.get_window_extent(renderer=renderer)
        overlap_area = _intersection_area(first_bbox, second_bbox)
        horizontal_gap = max(
            float(second_bbox.x0 - first_bbox.x1),
            float(first_bbox.x0 - second_bbox.x1),
            0.0,
        )
        vertical_gap = max(
            float(second_bbox.y0 - first_bbox.y1),
            float(first_bbox.y0 - second_bbox.y1),
            0.0,
        )
        protected_pair_checks.append(
            {
                "first": first_id,
                "second": second_id,
                "overlap_area_px2": overlap_area,
                "minimum_separation_pt": float(
                    math.hypot(horizontal_gap, vertical_gap) * 72 / fig.dpi
                ),
            }
        )
        if overlap_area > 1.0:
            protected_overlaps.append(
                {
                    "first": first_id,
                    "second": second_id,
                    "overlap_area_px2": overlap_area,
                    "first_bbox_px": [float(v) for v in first_bbox.extents],
                    "second_bbox_px": [float(v) for v in second_bbox.extents],
                }
            )

    point_occlusion_pairs = [("panel_b_oof", "panel_b_legend")]
    point_occlusion_checks: list[dict] = []
    point_occlusion_violations: list[dict] = []
    for point_set_id, occluder_id in point_occlusion_pairs:
        point_set = point_sets.get(point_set_id)
        occluder = protected.get(occluder_id)
        if point_set is None or occluder is None:
            violation = {
                "point_set": point_set_id,
                "occluder": occluder_id,
                "reason": "audited artist not found",
            }
            point_occlusion_checks.append(violation)
            point_occlusion_violations.append(violation)
            continue
        points_display = point_set.get_offset_transform().transform(point_set.get_offsets())
        occluder_bbox = occluder.get_window_extent(renderer=renderer)
        inside = (
            (points_display[:, 0] >= occluder_bbox.x0)
            & (points_display[:, 0] <= occluder_bbox.x1)
            & (points_display[:, 1] >= occluder_bbox.y0)
            & (points_display[:, 1] <= occluder_bbox.y1)
        )
        check = {
            "point_set": point_set_id,
            "occluder": occluder_id,
            "n_points": int(len(points_display)),
            "occluded_point_count": int(np.sum(inside)),
        }
        point_occlusion_checks.append(check)
        if check["occluded_point_count"]:
            point_occlusion_violations.append(check)
    report = {
        "canvas_px_at_audit_dpi": [float(bounds.width), float(bounds.height)],
        "safety_margin_pt": safety_pt,
        "min_font_pt": min(fonts),
        "max_font_pt": max(fonts),
        "outside_text_count": len(outside),
        "outside_text": outside,
        "text_overlap_count": len(overlaps),
        "text_overlaps": overlaps,
        "container_inset_pt": container_inset_pt,
        "contained_text_count": len(contained_text),
        "minimum_container_clearance_pt": float(
            min(item["minimum_clearance_pt"] for item in container_checks)
        ),
        "container_checks": container_checks,
        "container_violation_count": len(container_violations),
        "container_violations": container_violations,
        "protected_pair_count": len(protected_pairs),
        "protected_pair_checks": protected_pair_checks,
        "protected_overlap_count": len(protected_overlaps),
        "protected_overlaps": protected_overlaps,
        "point_occlusion_checks": point_occlusion_checks,
        "point_occlusion_violation_count": len(point_occlusion_violations),
        "point_occlusion_violations": point_occlusion_violations,
    }
    if outside:
        labels = "; ".join(item["text"].replace("\n", " / ")[:80] for item in outside[:8])
        raise RuntimeError(f"Text-bound audit failed ({len(outside)} objects): {labels}")
    if overlaps:
        labels = "; ".join(
            f"{item['first'].replace(chr(10), ' / ')[:40]} <> {item['second'].replace(chr(10), ' / ')[:40]}"
            for item in overlaps[:8]
        )
        raise RuntimeError(f"Text-overlap audit failed ({len(overlaps)} pairs): {labels}")
    if container_violations:
        labels = "; ".join(
            f"{item['container']}:{item['role']}" for item in container_violations[:8]
        )
        raise RuntimeError(
            f"Text-container audit failed ({len(container_violations)} objects): {labels}"
        )
    if protected_overlaps:
        labels = "; ".join(
            f"{item['first']} <> {item['second']}" for item in protected_overlaps[:8]
        )
        raise RuntimeError(
            f"Protected-overlap audit failed ({len(protected_overlaps)} pairs): {labels}"
        )
    if point_occlusion_violations:
        labels = "; ".join(
            f"{item['point_set']} <> {item['occluder']}"
            for item in point_occlusion_violations[:8]
        )
        raise RuntimeError(
            f"Point-occlusion audit failed ({len(point_occlusion_violations)} pairs): {labels}"
        )
    if min(fonts) < 6.0:
        raise RuntimeError(f"Minimum font is {min(fonts):.2f} pt; required >= 6.0 pt")
    return report


def create_figure(source: dict[str, pd.DataFrame]) -> tuple[mpl.figure.Figure, dict]:
    set_style()
    fig = plt.figure(figsize=(FIGURE_SIZE_MM[0] * MM, FIGURE_SIZE_MM[1] * MM), dpi=150)
    outer = fig.add_gridspec(
        3, 1,
        left=0.075, right=0.975, bottom=0.075, top=0.965,
        height_ratios=[0.49, 1.25, 1.16], hspace=0.47,
    )

    ax_a = fig.add_subplot(outer[0])
    panel_a(ax_a, source["Fig1a_workflow"])

    middle = outer[1].subgridspec(1, 3, width_ratios=[1.20, 1, 1], wspace=0.54)
    ax_b = fig.add_subplot(middle[0])
    ax_c = fig.add_subplot(middle[1])
    ax_d = fig.add_subplot(middle[2])
    metrics = {"panel_b": panel_b(ax_b, source["Fig1b_oof"])}
    metrics["panel_c"] = _null_comparison(
        ax_c, source["Fig1c_regression"], "Spearman ρ", "Regression", "c", 0.0, (-0.12, 0.71)
    )
    metrics["panel_d"] = _null_comparison(
        ax_d, source["Fig1d_classification"], "ROC AUC", "Essential-gene classification", "d", 0.5, (0.38, 0.985)
    )

    bottom = outer[2].subgridspec(1, 2, width_ratios=[1.18, 2.08], wspace=0.52)
    coeff = bottom[0].subgridspec(1, 2, width_ratios=[1.05, 1.38], wspace=0.025)
    ax_e_labels = fig.add_subplot(coeff[0])
    ax_e = fig.add_subplot(coeff[1])
    panel_e(ax_e_labels, ax_e, source["Fig1e_weights"])

    sensitivity = bottom[1].subgridspec(1, 2, width_ratios=[1.09, 1], wspace=0.37)
    ax_f_reg = fig.add_subplot(sensitivity[0])
    ax_f_cls = fig.add_subplot(sensitivity[1])
    metrics["panel_f"] = panel_f(ax_f_reg, ax_f_cls, source["Fig1f_robustness"])

    metrics["layout"] = audit_text_bounds(fig)
    return fig, metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-workbook", required=True, type=Path)
    parser.add_argument("--upstream-shuffles", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()

    workbook = args.source_workbook.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not workbook.exists():
        raise FileNotFoundError(workbook)
    if args.upstream_shuffles and not args.upstream_shuffles.exists():
        raise FileNotFoundError(args.upstream_shuffles)

    source = load_source(workbook)
    upstream_report = validate_upstream_shuffles(args.upstream_shuffles, source)
    fig, metrics = create_figure(source)
    web_dpi = 2400 / (FIGURE_SIZE_MM[0] * MM)
    original_dpi = float(fig.dpi)
    metrics["layout_export_dpi_audits"] = {}
    for label, dpi in (("web_png", web_dpi), ("png_600dpi", 600.0)):
        fig.set_dpi(dpi)
        metrics["layout_export_dpi_audits"][label] = audit_text_bounds(fig)
    fig.set_dpi(original_dpi)

    stem = "CGT_FIGURE_001_residual_geometry_predicts_fitness_revised"
    paths = {
        "pdf": output_dir / f"{stem}.pdf",
        "svg": output_dir / f"{stem}.svg",
        "png_600dpi": output_dir / f"{stem}_600dpi.png",
        "png_web": output_dir / f"{stem}_web.png",
    }
    metadata = {
        "Title": "Residual perturbation geometry predicts external CRISPR-derived gene fitness",
        "Author": "John Patrick Collins",
        "Subject": "CGT Figure 1, publication-layout revision",
        "Keywords": "CGT, Perturb-seq, DepMap, gene fitness, cross-validation",
    }
    fig.savefig(paths["pdf"], bbox_inches=None, pad_inches=0, metadata=metadata)
    fig.savefig(paths["svg"], bbox_inches=None, pad_inches=0, metadata={"Title": metadata["Title"], "Description": metadata["Subject"]})
    fig.savefig(paths["png_600dpi"], dpi=600, bbox_inches=None, pad_inches=0)
    fig.savefig(paths["png_web"], dpi=web_dpi, bbox_inches=None, pad_inches=0)
    plt.close(fig)

    report = {
        "figure_id": "CGT_FIGURE_001",
        "revision_scope": "presentation and scientific-label corrections; frozen numerical inputs",
        "figure_size_mm": list(FIGURE_SIZE_MM),
        "source_workbook": {"name": workbook.name, "sha256": sha256(workbook)},
        "upstream_shuffle_validation": upstream_report,
        "metrics": metrics,
        "environment": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "matplotlib": mpl.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
            "font": FONT_FAMILY,
            "svg_text_mode": "paths",
            "pdf_fonttype": 42,
        },
        "outputs": {},
        "known_source_limitations": [
            "The workbook supplies only the top eight of sixteen ridge coefficients.",
            "Family shorthand labels are inherited from the frozen workbook and are not re-derived here.",
            "The 2,720 upstream response-profile count and 1,630 matched gene-dataset records are different stages; the figure labels 2,720 as upstream response profiles.",
            "One hundred shuffles make 1/101 the smallest attainable plus-one empirical P value.",
            "Test-gene CGT features were measured; this is supervised-stage gene holdout, not prediction without CGT measurements.",
        ],
    }
    for label, path in paths.items():
        report["outputs"][label] = {
            "name": path.name,
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
    report_path = output_dir / f"{stem}_audit.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"outputs": {k: str(v) for k, v in paths.items()}, "audit": str(report_path)}, indent=2))


if __name__ == "__main__":
    main()
