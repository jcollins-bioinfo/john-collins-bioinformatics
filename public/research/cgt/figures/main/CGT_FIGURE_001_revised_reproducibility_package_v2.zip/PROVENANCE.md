# Provenance

## Frozen inputs located in Google Drive

| Role | Drive item | Identifier |
|---|---|---|
| Canonical figure folder | `CGT_FIGURE_001` | `19o6-JhL3s3e-Ey_YjXRumnB2eVVApC7i` |
| Original source-data workbook | `source_data.xlsx` | `1rF65jj_l3hDVt6QTWYOgpJjUajUS6Wki` |
| Original notebook archive | `CGT_FIGURE_001.zip` | `1JaOHntY00PlNODdViN6DI0hqAGmwTYNs` |
| Original PDF | canonical Figure 1 PDF | `13Cn7A0lTja6aEn2IpRdh1zviqweXLCRi` |
| Original SVG | canonical Figure 1 SVG | `19NjC0Kq-5Tn5vl3ub9knzprA05Xy2zYQ` |
| Original PNG | canonical Figure 1 PNG | `1pgsLAUOGNdnVZSUV_9SQG59i2xMLLCJn` |
| Fold-level endpoint shuffles | `CGT_PREDICT_005_endpoint_shuffle_results.csv` | `1Y3-L-PAVORuYLg1RpaRSbCjZWYzhtbtq` |

The original Drive artifacts were treated as frozen and were not overwritten.

## Input validation

- Source workbook SHA-256:
  `ec301ca02aa9246fd3c6b447b6682a3cb25b86adebfe78ed7b7ded8d993c0be3`.
- The OOF table contains exactly 1,229 unique genes and one row per gene.
- The exported regression and classification comparisons each contain five
  observed folds and 100 shuffle means.
- The upstream shuffle table contains only the normalized benchmark
  `context__groupby_gene`; for each task, the random-forest subset contains 100
  shuffles and exactly five folds per shuffle.
- Recomputed fold-averaged shuffle metrics match the workbook exports to
  numerical tolerance.

## Revision boundary

The renderer changes layout, graphical encoding, and scientific wording. It does
not alter the frozen predictions, fold metrics, null metrics, coefficients, or
feature-construction results. Known upstream limitations are recorded in the
generated audit JSON and the package README.

## Corrective layout revision

The first revised export was rejected after direct visual review identified two
layout defects: every panel-a workflow body was anchored too low (most visibly
the word `removed` outside the green box), and panel b's legend frame occluded
the terminal digits of `Spearman ρ = 0.613`. The corrective renderer:

- reflows the green workflow body to two lines and rebalances the shared title
  and body anchors for all five workflow boxes;
- retains the panel-b legend in the data-sparse upper-right region but shortens
  its calibration-line label to `OLS fit`, preserving the full statistic and
  avoiding plotted observations;
- adds hard-fail checks for workflow-text containment, statistics–legend frame
  overlap, and legend occlusion of plotted points; and
- repeats the geometry audit at design, web-PNG, and 600-dpi export resolution.

The frozen numerical inputs and all reported performance values remain unchanged.
