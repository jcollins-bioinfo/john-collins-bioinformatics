# CGT Figure 1 — audited layout revision

This package regenerates Figure 1 from the frozen `source_data.xlsx` workbook.
It does not rerun the upstream biological analysis or replace the frozen source
data. The revision fixes clipping, collisions, ambiguous graphical comparisons,
and several overbroad labels while preserving the reported numerical results.

## Principal corrections

- Panel a now distinguishes upstream response profiles, gene-level measured CGT
  features, the supervised prediction step, and the external `−GeneEffect`
  endpoint. Context subtraction is described narrowly as removing estimated
  context mean shifts.
- Panel b uses neutral points, removes cherry-selected gene annotations, labels
  the predictive coefficient of determination as `R²_pred`, and places the line
  key in the data-sparse upper-right region with enough clearance from the
  upper-left statistics annotation.
- Panels c–d make the inferential unit explicit: 100 cross-validated shuffle
  means form the null, the diamond is the mean of the five observed folds, and
  the one-sided plus-one empirical permutation P value is reported as 1/101.
- Panel e states that it contains the top 8 of 16 coefficients and that the
  features are mean absolute residual magnitudes. The family-name column has a
  dedicated layout gutter, eliminating the original deterministic crop.
- Panel f is labeled as feature-construction sensitivity. It separates stability
  to aggregation choice from the material attenuation under dataset-mean
  residualization. Heatmap cells are vector objects with explicit fixed scales.
- The SVG converts text to paths to prevent browser font substitution. The PDF
  embeds TrueType text. A rendering-time audit fails on text outside the fixed
  183 × 165 mm canvas, workflow text outside its own container, protected
  statistics–legend collisions, legend occlusion of plotted observations,
  text–text overlap, or fonts smaller than 6 pt.
  The same geometry checks run at design, web-PNG, and 600-dpi export resolution.

## Reproduction

```bash
python render_cgt_figure_001.py \
  --source-workbook source_data.xlsx \
  --upstream-shuffles endpoint_shuffle_results.csv \
  --output-dir output
```

The upstream shuffle input is optional for drawing but required to independently
verify that the exported null contains one benchmark (`context__groupby_gene`),
100 label shuffles, and five folds per shuffle.

## Scientific limits retained from the frozen source

- Test-gene CGT features were measured; gene grouping holds out the supervised
  mapping, not the feature measurement.
- The empirical P values are at the resolution floor created by 100 shuffles.
- The workbook exports only the top eight ridge coefficients, and its biological
  family shorthand is inherited rather than programmatically re-derived.
- The 2,720 response-profile count is upstream of endpoint matching. The modeled
  OOF genes represent 1,630 gene–dataset records, so those counts should not be
  treated as the same analysis unit.
- Harder program-family, dataset, context, and study-proxy holdouts remain weak;
  the figure supports predictive association within the represented regime, not
  universal transportability or causality.

See the generated `*_audit.json` for exact metrics, checksums, environment
versions, and layout-audit results.
