# Figure 1

## Residual perturbation geometry predicts external CRISPR-derived gene fitness

**Caption.** **a,** A prediction-focused set of 2,720 perturbational response
profiles from 39 datasets and 8 contexts was context-mean residualized and
summarized as 16 gene-level CGT features. These measured features were mapped to
an external DepMap 26Q1 CRISPR endpoint in five-fold, gene-grouped supervised
cross-validation. **b,** Out-of-fold predictions for 1,229 genes. Essentiality
strength is −GeneEffect; pooled Spearman ρ = 0.613 and predictive R² = 0.353.
The OLS calibration slope is 0.386, indicating shrinkage toward the mean.
**c–d,** Regression and essential-gene classification compared with 100 endpoint
label shuffles. The null distributions contain cross-validated means from whole
shuffles; open circles are the five observed fold values and the diamond is their
mean. One-sided plus-one empirical permutation P = 1/101 = 0.0099 for each
endpoint view. **e,** The eight largest absolute standardized ridge coefficients
among 16 mean-absolute-residual features. These full-data coefficients are
descriptive conditional weights, not causal effects or coefficient-stability
estimates. **f,** Feature-construction sensitivity across three residualization
schemes and three cumulative gene-level aggregation choices. Aggregation choice
has little effect within a scheme, whereas dataset-mean residualization materially
attenuates performance.

Regression and thresholded classification are two views of the same external
GeneEffect source, not independent biological confirmations. Test-gene CGT
features were measured rather than predicted. Harder program-family, dataset,
context, and study-proxy holdouts remain weak, so the result supports predictive
association within the represented data regime rather than universal transfer or
causality.

## Accessible description

The figure has six labeled panels. Panel a is a five-box workflow from Perturb-seq
response profiles through context-mean subtraction and measured gene-level CGT
features to a supervised random-forest mapping and an external DepMap −GeneEffect
endpoint. Panel b is a neutral-gray scatter plot of observed essentiality strength
against out-of-fold prediction for 1,229 genes. The fitted calibration line rises
more shallowly than the identity line, showing regression toward the mean; pooled
rank correlation is 0.613. Panels c and d show 100 shuffle-level null means near
zero Spearman correlation and 0.5 ROC AUC, respectively, while all five observed
folds cluster near 0.62 correlation and 0.92 AUC. Panel e is a horizontal bar plot
of the top eight standardized ridge coefficients; F12 translation/RQC is the
largest-magnitude coefficient and is negative. Panel f contains two three-by-three
heatmaps. Performance changes little when median or standard-deviation summaries
are added within a residualization scheme, but falls under dataset-mean
residualization to about 0.51 correlation and 0.80 AUC.

## Replacement quality note

- Fixed canvas: 183 × 165 mm.
- Minimum text: 6.0 pt; maximum text: 9.2 pt.
- Automated geometry audits at design, web-export, and 600-dpi resolution:
  zero out-of-canvas text objects, zero text–text overlaps, zero workflow-box
  containment violations, and zero protected statistics–legend overlaps.
- Minimum workflow-text clearance from its container stroke: 2.002 pt at design
  resolution; panel-b statistics–legend separation: 12.762 pt.
- The panel-b legend occludes 0 of 1,229 plotted observations at all three audited
  resolutions.
- SVG: all-vector paths, with no embedded raster images or live-font dependency.
- PDF: embedded DejaVu Sans TrueType fonts.
- Web PNG: 2,400 × 2,163 px; 554,317 bytes; SHA-256
  `6e4a410c90763ded6aac2eb7d95e14296c511dbbdf8b9b0d494634b583721808`.
- 600-dpi PNG: 4,322 × 3,897 px; 1,095,745 bytes; SHA-256
  `990bce7ba1bb698295367fc374e2f392c6c55cc0517ef59abf0cff4304dd7dca`.
- Publication PDF: 63,527 bytes; SHA-256
  `e850d1b4cc26209f1f365017dad32f24640c5726e75b251e80529939d5dfa1d9`.
- Vector SVG: 349,381 bytes; SHA-256
  `9a5c12ce5a611eb2e51a9b2a2dc2eaeaa0f8a05eaa1094144ee3219009c4f773`.
- Machine-readable audit: 18,645 bytes; SHA-256
  `f0e4a977b845adfe07cf41f1473b2bac7ec6a0d1d7a20f0f7f882b3caddb8ab1`.
