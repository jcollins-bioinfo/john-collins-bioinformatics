# Frozen inputs for revised CGT Figure 4

- `panel_a_claim_scope.csv` is a claim-calibrated synthesis of audited Figures 1-3. It creates no new inferential result.
- `panel_d_fitness_replicates.csv` transcribes all regression-Spearman replicates from the revised Figure 1 `source_data.xlsx` generalization-boundary sheet.
- `panel_e_scope.csv` contains interpretive labels only; the final row is an explicit non-claim.
- The renderer also reads byte-preserved upstream tables in `../upstream/`: revised Figure 2 robustness estimates and revised Figure 3 candidate-axis summaries.

Figure 4 is a synthesis figure. Its panels reuse results from Figures 1-3 and must not be described as independent validation.
