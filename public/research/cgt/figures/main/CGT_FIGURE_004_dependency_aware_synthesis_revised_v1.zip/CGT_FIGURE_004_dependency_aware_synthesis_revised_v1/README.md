# CGT Figure 4 revised release v1

This immutable release contains the audited replacement for CGT Figure 4, titled **“Dependency-aware synthesis of current CGT analyses and their generalization boundaries.”** It synthesizes frozen results from revised Figures 1–3 and does not add an independent replication, new fitted model, or causal analysis.

## Public assets

- `assets/CGT_FIGURE_004_dependency_aware_synthesis_revised_web.png` — 2,400-pixel web composite.
- `assets/CGT_FIGURE_004_dependency_aware_synthesis_revised_600dpi.png` — 600-dpi publication PNG with embedded sRGB profile.
- `assets/CGT_FIGURE_004_dependency_aware_synthesis_revised.pdf` — one-page 183 × 204 mm publication PDF with embedded fonts.
- `assets/CGT_FIGURE_004_dependency_aware_synthesis_revised.svg` — self-contained, font-independent public SVG with explicit title and description.
- `assets/CGT_FIGURE_004_dependency_aware_synthesis_revised_mobile_panel_[a-e].png` — responsive panel crops.

The editable-text SVG under `audit/` is for text inspection only and must never replace the public path-based SVG.

## Responsive use

Do not squeeze the desktop composite or the wide panel crops to phone width. Panel c may be shown at the available mobile width. Panels a, b, d, and e must retain a readable minimum rendered width in an accessible horizontal-scroll/zoom wrapper. Provide the full composite through a full-resolution link or lightbox.

## Integrity and reproduction

`CGT_FIGURE_004_release_manifest.json` is a self-excluding inventory: it lists every other file in the release directory with role, MIME type, structural metadata where relevant, byte count, and SHA-256. Run `code/verify_cgt_figure_004_release.py` before integration. Reproduction commands and pinned-environment details are in `documentation/environment_and_reproduction.md`.

The public PNG, PDF, SVG, and responsive assets must be copied byte-for-byte. Do not re-encode, optimize, resave, or route checksum-sensitive files through an image optimizer.
