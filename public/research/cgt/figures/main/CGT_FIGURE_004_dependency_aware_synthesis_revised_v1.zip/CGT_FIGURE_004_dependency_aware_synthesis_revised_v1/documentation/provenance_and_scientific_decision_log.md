# Figure 4 provenance and scientific decision log

## Scope

Figure 4 is a synthesis of frozen, revised Figures 1–3. No new model was fitted and no enrichment, residualization, or bootstrap analysis was rerun for this redesign. The renderer consumes exact corrected upstream tables plus the frozen fold/group replicate values.

## Frozen renderer inputs

- `CGT_FIGURE_003_axis_evidence_revised.csv`: corrected nine-row Figure 3 candidate-summary table, including separate ORA and rank columns and dominant-study-proxy share.
- `CGT_FIGURE_002_Fig2f_robustness_revised.csv`: corrected Figure 2 residual-transfer means, 4,000-resample cluster intervals, cluster counts, and finite-row denominators.
- `panel_d_fitness_replicates.csv`: all available finite regression-Spearman fold/group estimates used in the original fitness-boundary summary.
- `panel_a_claim_scope.csv` and `panel_e_scope.csv`: explicit claim-status and scope language used to prevent inferential overreach.

## Corrections relative to the original Figure 4

1. Panel b no longer mixes stale ORA/rank values or unlike metrics into a generic support column. Corrected ORA and rank values are separate; study concentration replaces unqualified coessentiality lift.
2. Panel c removes the undocumented 50:50 composite, bubble-area encoding, thresholds, and unreported F10 plotting jitter. The two F10-linked rows retain their identical recurrence, beta, and rho coordinates. Candidate 2 remains visible at its nearly coincident location through nested shape encoding, not displacement.
3. Panel d removes the duplicated “within context” row, restores the revised Figure 2 intervals, uses “same-study-proxy” terminology, and exposes every finite fitness replicate rather than presenting tiny-n bootstrap intervals as if they were stable.
4. Panel e replaces fitted-looking equations and causal arrows with an explicitly descriptive scope sequence, an orange STOP barrier, and the experiments required for broader claims.
5. All statuses and tiers are text-labelled and therefore do not depend on color. The release includes grayscale and three color-vision simulations.

## Important dependency structure

- ORA and rank summaries reuse the same residual coordinates and overlapping gene-set memberships.
- Ridge \(|\beta|\) and high-confidence Spearman \(|\rho|\) reuse the same DepMap-derived essentiality-strength endpoint.
- Values in panel b are maxima over constituent query or family views.
- Candidate labels were assigned manually after analysis.
- The 16-feature closed residual matrix has rank 12; F15 is a scaled copy of F3, F6 is the negative of F5, and F4/F13 are zero.
- Seven of nine displayed groups have maximum dominant-study-proxy share 1.000; the remaining shares are 0.875 and 0.643.

## Remaining upstream limitations

Residual baselines were estimated once from the full PREDICT-003B table rather than inside each training fold. Study identity is approximated by a dataset-name prefix. The META-003 and PREDICT-003B universes differ without a row-level inclusion map. Candidate annotations remain post hoc and study-conditioned. No external prospective intervention, mechanism experiment, or causal identification design is present.
