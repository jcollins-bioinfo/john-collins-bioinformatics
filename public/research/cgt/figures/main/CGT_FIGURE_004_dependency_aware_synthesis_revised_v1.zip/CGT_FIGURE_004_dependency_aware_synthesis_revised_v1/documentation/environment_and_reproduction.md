# Environment and reproduction

Render date: 2026-08-23 UTC.

The renderer pins DejaVu Sans and DejaVu Sans Bold by SHA-256, uses an embedded sRGB ICC profile, fixes locale/timezone and Matplotlib SVG hash salt, and writes fixed PDF/SVG metadata. It requires Python 3, Matplotlib, NumPy, pandas, and Pillow. The audit additionally requires SciPy, Poppler (`pdfinfo`, `pdffonts`, `pdftotext`, `pdftoppm`), and Inkscape.

From the unpacked release root:

```bash
python3 code/render_cgt_figure_004.py \
  --source-root source \
  --output-dir reproduced/output \
  --qa-dir reproduced/qa

python3 code/audit_cgt_figure_004.py \
  --source-root source \
  --output-dir reproduced/output \
  --qa-dir reproduced/qa
```

Compare reproduced artifact hashes with `audit/CGT_FIGURE_004_render_metadata.json` and the release manifest. The release builder performs two independent ZIP builds and requires exact byte equality.
