#!/usr/bin/env python3
"""Verify the immutable CGT Figure 4 release directory and optional ZIP."""

from __future__ import annotations

import argparse
import hashlib
import json
import stat
import subprocess
import sys
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

from PIL import Image


RELEASE_ID = "CGT_FIGURE_004_dependency_aware_synthesis_revised_v1"
MANIFEST_NAME = "CGT_FIGURE_004_release_manifest.json"
BASE = "CGT_FIGURE_004_dependency_aware_synthesis_revised"
EXPECTED_ROLE_PATHS = {
    "web_png": f"assets/{BASE}_web.png",
    "publication_png": f"assets/{BASE}_600dpi.png",
    "publication_pdf": f"assets/{BASE}.pdf",
    "release_svg": f"assets/{BASE}.svg",
    **{f"mobile_panel_{panel}": f"assets/{BASE}_mobile_panel_{panel}.png" for panel in "abcde"},
    "final_audit": f"audit/{BASE}_audit.json",
    "layout_registry": "audit/CGT_FIGURE_004_layout_registry.json",
    "render_metadata": "audit/CGT_FIGURE_004_render_metadata.json",
    "editable_qa_svg": f"audit/{BASE}_editable_text_QA.svg",
    "renderer": "code/render_cgt_figure_004.py",
    "figure_auditor": "code/audit_cgt_figure_004.py",
    "release_verifier": "code/verify_cgt_figure_004_release.py",
    "release_builder": "code/build_cgt_figure_004_release.py",
    "caption_accessibility": "documentation/website_copy.md",
    "environment_documentation": "documentation/environment_and_reproduction.md",
    "icc_profile": "source/assets/sRGB.icc",
    "claim_scope_table": "source/data/panel_a_claim_scope.csv",
    "fitness_replicates_table": "source/data/panel_d_fitness_replicates.csv",
    "scope_table": "source/data/panel_e_scope.csv",
    "figure2_upstream_table": "source/upstream/CGT_FIGURE_002_Fig2f_robustness_revised.csv",
    "figure3_upstream_table": "source/upstream/CGT_FIGURE_003_axis_evidence_revised.csv",
}


class VerificationError(RuntimeError):
    pass


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")


def load_json(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise VerificationError(f"Duplicate JSON key {key!r} in {path}")
            result[key] = value
        return result

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=reject_duplicates)


def validate_relative(value: str) -> str:
    if not value or "\\" in value or "\x00" in value or unicodedata.normalize("NFC", value) != value:
        raise VerificationError(f"Unsafe or noncanonical path: {value!r}")
    pure = PurePosixPath(value)
    if pure.is_absolute() or any(part in {"", ".", ".."} for part in pure.parts):
        raise VerificationError(f"Unsafe relative path: {value!r}")
    if any(ord(character) < 32 or 0x202A <= ord(character) <= 0x202E or 0x2066 <= ord(character) <= 0x2069 for character in value):
        raise VerificationError(f"Control character in path: {value!r}")
    return value


def walk_files(root: Path) -> list[str]:
    files: list[str] = []
    seen: dict[str, str] = {}
    for path in sorted(root.rglob("*"), key=lambda item: item.as_posix().encode("utf-8")):
        relative = path.relative_to(root).as_posix()
        validate_relative(relative)
        parts = Path(relative).parts
        if (
            any(part.startswith(".") or part == "__pycache__" for part in parts)
            or path.suffix.lower() in {".pyc", ".pyo", ".zip"}
            or any(token in path.name.lower() for token in (".tmp", "_raw", "current_crop", "temporary"))
        ):
            raise VerificationError(f"Forbidden cache, temporary, hidden, or nested archive path: {relative}")
        if path.is_symlink():
            raise VerificationError(f"Symlink forbidden: {relative}")
        if path.is_dir():
            continue
        if not path.is_file() or not stat.S_ISREG(path.stat().st_mode):
            raise VerificationError(f"Non-regular file forbidden: {relative}")
        if path.stat().st_nlink != 1:
            raise VerificationError(f"Hard-linked file forbidden: {relative}")
        folded = relative.casefold()
        if folded in seen and seen[folded] != relative:
            raise VerificationError(f"Case-fold path collision: {seen[folded]!r}, {relative!r}")
        seen[folded] = relative
        files.append(relative)
    return files


def inspect_png(path: Path, expected_size: tuple[int, int], require_dpi: bool) -> dict[str, Any]:
    with Image.open(path) as image:
        record = {
            "size_px": list(image.size),
            "mode": image.mode,
            "format": image.format,
            "icc_bytes": len(image.info.get("icc_profile", b"")),
            "dpi": list(image.info.get("dpi", ())),
        }
    if tuple(record["size_px"]) != expected_size or record["mode"] != "RGB" or record["format"] != "PNG" or record["icc_bytes"] < 1000:
        raise VerificationError(f"Invalid PNG structure: {path}: {record}")
    if require_dpi and (len(record["dpi"]) != 2 or any(abs(value - 600) > 0.2 for value in record["dpi"])):
        raise VerificationError(f"Invalid publication PNG DPI: {record['dpi']}")
    return record


def inspect_svg(path: Path) -> dict[str, Any]:
    root = ET.parse(path).getroot()
    tags = [element.tag.rsplit("}", 1)[-1] for element in root.iter()]
    external: list[str] = []
    for element in root.iter():
        for key, value in element.attrib.items():
            if key.endswith("href") and value and not value.startswith("#"):
                external.append(value)
    if tags.count("image") or tags.count("script") or tags.count("text") or external or not tags.count("title") or not tags.count("desc"):
        raise VerificationError(f"Release SVG is not self-contained/path-based: {path}")
    if root.attrib.get("viewBox") != "0 0 518.740157 578.267717":
        raise VerificationError(f"Unexpected SVG viewBox: {root.attrib.get('viewBox')}")
    return {"viewBox": root.attrib.get("viewBox"), "path_elements": tags.count("path"), "has_title": True, "has_desc": True}


def inspect_pdf(path: Path) -> dict[str, Any]:
    result = subprocess.run(["pdfinfo", str(path)], check=False, capture_output=True, text=True)
    if result.returncode:
        raise VerificationError(f"pdfinfo rejected {path}: {result.stderr}")
    if "Pages:           1" not in result.stdout or "Page size:       518.74 x 578.268 pts" not in result.stdout:
        raise VerificationError(f"Unexpected PDF page structure: {result.stdout}")
    fonts = subprocess.run(["pdffonts", str(path)], check=False, capture_output=True, text=True)
    font_rows = [line for line in fonts.stdout.splitlines()[2:] if line.strip()]
    if fonts.returncode or not font_rows or any(len(line.split()) < 5 or line.split()[-5] != "yes" for line in font_rows):
        raise VerificationError("PDF fonts are absent or not all embedded")
    return {"page_size_mm": [183.0, 204.0], "fonts_embedded": True}


def verify_zip(zip_path: Path, root: Path, expected_files: list[str]) -> dict[str, Any]:
    expected_names = [f"{RELEASE_ID}/{relative}" for relative in expected_files]
    with zipfile.ZipFile(zip_path, "r") as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if archive.testzip() is not None:
            raise VerificationError("ZIP CRC failure")
        if names != sorted(names, key=lambda value: value.encode("utf-8")) or names != expected_names:
            raise VerificationError("ZIP member inventory/order mismatch")
        if archive.comment or any(info.is_dir() or info.flag_bits & 1 for info in infos):
            raise VerificationError("ZIP contains a directory member, comment, or encrypted member")
        folded: dict[str, str] = {}
        compressed_total = 0
        uncompressed_total = 0
        for info, expected in zip(infos, expected_files, strict=True):
            validate_relative(info.filename)
            previous = folded.setdefault(info.filename.casefold(), info.filename)
            if previous != info.filename:
                raise VerificationError(f"ZIP case-fold path collision: {previous}, {info.filename}")
            mode = info.external_attr >> 16
            if stat.S_IFMT(mode) != stat.S_IFREG or stat.S_IMODE(mode) != 0o644:
                raise VerificationError(f"Noncanonical ZIP member mode: {info.filename}: {oct(mode)}")
            if (
                info.create_system != 3
                or info.date_time != (2026, 8, 23, 0, 0, 0)
                or info.compress_type != zipfile.ZIP_DEFLATED
                or info.extra
                or info.comment
                or info.flag_bits not in {0, 0x800}
                or info.file_size != (root / expected).stat().st_size
            ):
                raise VerificationError(f"Noncanonical ZIP member metadata: {info.filename}")
            compressed_total += info.compress_size
            uncompressed_total += info.file_size
            if info.file_size / max(1, info.compress_size) > 200:
                raise VerificationError(f"Excessive ZIP member expansion ratio: {info.filename}")
            digest = hashlib.sha256(archive.read(info)).hexdigest()
            if digest != sha256(root / expected):
                raise VerificationError(f"ZIP member bytes differ from release: {info.filename}")
        expansion_ratio = uncompressed_total / max(1, compressed_total)
        if expansion_ratio > 100:
            raise VerificationError(f"Excessive aggregate ZIP expansion ratio: {expansion_ratio}")
    return {
        "bytes": zip_path.stat().st_size,
        "sha256": sha256(zip_path),
        "member_count": len(expected_names),
        "compressed_member_bytes": compressed_total,
        "uncompressed_member_bytes": uncompressed_total,
        "expansion_ratio": expansion_ratio,
        "fixed_dos_datetime": [2026, 8, 23, 0, 0, 0],
        "compression": "deflate",
    }


def verify_release(root: Path, zip_path: Path | None = None) -> dict[str, Any]:
    if root.name != RELEASE_ID:
        raise VerificationError(f"Release root must be named {RELEASE_ID!r}")
    manifest_path = root / MANIFEST_NAME
    manifest = load_json(manifest_path)
    if manifest.get("release_id") != RELEASE_ID or manifest.get("manifest_policy", {}).get("self_excluding") is not True:
        raise VerificationError("Manifest identity/policy mismatch")
    actual_files = walk_files(root)
    listed_files = [validate_relative(entry["path"]) for entry in manifest.get("entries", [])]
    expected_actual = sorted(listed_files + [MANIFEST_NAME], key=lambda value: value.encode("utf-8"))
    if actual_files != expected_actual or len(listed_files) != len(set(listed_files)):
        raise VerificationError("Manifest is not an exact self-excluding release inventory")
    role_paths: dict[str, str] = {}
    for entry in manifest["entries"]:
        path = root / entry["path"]
        role = str(entry["role"])
        if role in EXPECTED_ROLE_PATHS:
            if role in role_paths:
                raise VerificationError(f"Duplicate required manifest role {role!r}: {role_paths[role]!r}, {entry['path']!r}")
            role_paths[role] = entry["path"]
        if path.stat().st_size != entry["bytes"] or sha256(path) != entry["sha256"]:
            raise VerificationError(f"Manifest byte/hash mismatch: {entry['path']}")
        if role in EXPECTED_ROLE_PATHS and entry["path"] != EXPECTED_ROLE_PATHS[role]:
            raise VerificationError(f"Role-to-path mismatch for {role}: {entry['path']} != {EXPECTED_ROLE_PATHS[role]}")
        if path.suffix.lower() in {".png", ".pdf", ".svg"} and "dimensions" not in entry:
            raise VerificationError(f"Manifest lacks structural metadata for {entry['path']}")
    missing_roles = sorted(set(EXPECTED_ROLE_PATHS) - set(role_paths))
    if missing_roles:
        raise VerificationError(f"Missing required release roles: {missing_roles}")

    assets = root / "assets"
    inspect_png(assets / f"{BASE}_web.png", (2400, 2675), False)
    inspect_png(assets / f"{BASE}_600dpi.png", (4322, 4818), True)
    inspect_svg(assets / f"{BASE}.svg")
    inspect_pdf(assets / f"{BASE}.pdf")
    for panel in "abcde":
        mobile = assets / f"{BASE}_mobile_panel_{panel}.png"
        with Image.open(mobile) as image:
            if image.format != "PNG" or image.mode != "RGB" or image.width not in {1200, 1600} or len(image.info.get("icc_profile", b"")) < 1000:
                raise VerificationError(f"Invalid responsive panel asset: {mobile}")
    audit = load_json(root / "audit" / f"{BASE}_audit.json")
    if audit.get("status") != "pass" or any(section.get("status") != "pass" for section in audit.get("sections", {}).values()):
        raise VerificationError("Packaged audit is not a complete pass")
    if not (root / "documentation" / "website_copy.md").is_file():
        raise VerificationError("Caption/accessibility copy is missing")

    audit_hash_map = {
        "layout": root / "audit" / "CGT_FIGURE_004_layout_registry.json",
        "pdf": assets / f"{BASE}.pdf",
        "svg": assets / f"{BASE}.svg",
        "editable_svg": root / "audit" / f"{BASE}_editable_text_QA.svg",
        "publication_png": assets / f"{BASE}_600dpi.png",
        "web_png": assets / f"{BASE}_web.png",
        **{f"mobile_panel_{panel}": assets / f"{BASE}_mobile_panel_{panel}.png" for panel in "abcde"},
    }
    if set(audit.get("artifact_hashes", {})) != set(audit_hash_map):
        raise VerificationError("Audit artifact-hash inventory mismatch")
    for label, path in audit_hash_map.items():
        if audit["artifact_hashes"][label] != sha256(path):
            raise VerificationError(f"Packaged artifact differs from audited bytes: {label}")

    render_metadata_path = root / "audit" / "CGT_FIGURE_004_render_metadata.json"
    render_metadata = load_json(render_metadata_path)
    for relative, expected_hash in render_metadata.get("source_hashes", {}).items():
        source_path = root / "source" / validate_relative(relative)
        if not source_path.is_file() or sha256(source_path) != expected_hash:
            raise VerificationError(f"Packaged renderer input differs from render metadata: {relative}")
    renderer_path = root / "code" / "render_cgt_figure_004.py"
    if render_metadata.get("renderer", {}).get("sha256") != sha256(renderer_path):
        raise VerificationError("Packaged renderer differs from render metadata")
    output_by_name = {path.name: path for path in audit_hash_map.values()}
    for filename, expected_hash in render_metadata.get("output_hashes", {}).items():
        if filename not in output_by_name or sha256(output_by_name[filename]) != expected_hash:
            raise VerificationError(f"Packaged render output differs from render metadata: {filename}")
    for panel, record in render_metadata.get("responsive_panel_outputs", {}).items():
        path = assets / record["filename"]
        if panel not in set("abcde") or not path.is_file() or sha256(path) != record["sha256"]:
            raise VerificationError(f"Responsive render metadata mismatch: panel {panel}")
        with Image.open(path) as image:
            observed_size = list(image.size)
        if observed_size != record["size_px"]:
            raise VerificationError(f"Responsive render metadata mismatch: panel {panel}")

    result: dict[str, Any] = {
        "status": "pass",
        "release_id": RELEASE_ID,
        "manifest_sha256": sha256(manifest_path),
        "manifest_bytes": manifest_path.stat().st_size,
        "listed_file_count": len(listed_files),
    }
    if zip_path is not None:
        result["zip"] = verify_zip(zip_path, root, actual_files)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--zip", type=Path)
    args = parser.parse_args()
    try:
        result = verify_release(args.root.resolve(), args.zip.resolve() if args.zip else None)
    except Exception as exc:
        sys.stderr.buffer.write(canonical_json({"status": "fail", "error": str(exc)}))
        return 1
    sys.stdout.buffer.write(canonical_json(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
