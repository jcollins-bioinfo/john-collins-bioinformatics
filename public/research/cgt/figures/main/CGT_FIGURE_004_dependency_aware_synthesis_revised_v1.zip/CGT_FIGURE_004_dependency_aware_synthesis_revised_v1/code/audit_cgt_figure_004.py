#!/usr/bin/env python3
"""Strict geometry, format, numerical, and accessibility audit for CGT Figure 4."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import re
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from PIL import Image
from scipy.ndimage import gaussian_filter


MM_TO_PT = 72.0 / 25.4
WIDTH_MM = 183.0
HEIGHT_MM = 204.0
WIDTH_PT = WIDTH_MM * MM_TO_PT
HEIGHT_PT = HEIGHT_MM * MM_TO_PT
PUB_DPI = 600
PUB_SIZE = (int(WIDTH_MM / 25.4 * PUB_DPI), int(HEIGHT_MM / 25.4 * PUB_DPI))
WEB_SIZE = (2400, round(2400 * HEIGHT_MM / WIDTH_MM))
MIN_FONT_PT = 6.0
SAFE_CANVAS_PT = 10.0
PANEL_TOLERANCE_PT = 0.75
TEXT_OVERLAP_TOLERANCE_PT = 0.2
INTERPANEL_CLEARANCE_PT = 4.0
RESPONSIVE_CROPS = {
    "a": (1600, 126.0 / (WIDTH_PT - 38.0)),
    "b": (1600, 178.0 / (WIDTH_PT - 38.0)),
    "c": (1200, 150.0 / 180.0),
    "d": (1600, 150.0 / (WIDTH_PT - 202.0)),
    "e": (1600, 90.0 / (WIDTH_PT - 38.0)),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    temp = Path(tempfile.gettempdir()) / "cgt_figure_004_audit_xdg"
    for variable, child in [("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_DATA_HOME", "data")]:
        target = temp / child
        target.mkdir(parents=True, exist_ok=True)
        env[variable] = str(target)
    result = subprocess.run(command, check=False, capture_output=True, text=True, env=env)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed ({result.returncode}): {' '.join(command)}\n{result.stdout}\n{result.stderr}")
    return result


def bbox_overlap(first: list[float], second: list[float]) -> tuple[float, float]:
    return min(first[2], second[2]) - max(first[0], second[0]), min(first[3], second[3]) - max(first[1], second[1])


def bbox_distance(first: list[float], second: list[float]) -> float:
    dx = max(first[0] - second[2], second[0] - first[2], 0.0)
    dy = max(first[1] - second[3], second[1] - first[3], 0.0)
    return math.hypot(dx, dy)


def contains(outer: list[float], inner: list[float], clearance: float) -> bool:
    return (
        inner[0] >= outer[0] + clearance - 0.15
        and inner[1] >= outer[1] + clearance - 0.15
        and inner[2] <= outer[2] - clearance + 0.15
        and inner[3] <= outer[3] - clearance + 0.15
    )


def geometry_audit(layout_path: Path) -> dict[str, Any]:
    layout = json.loads(layout_path.read_text(encoding="utf-8"))
    entries = {entry["semantic_id"]: entry for entry in layout["entries"]}
    texts = [entry for entry in entries.values() if entry["kind"] == "text"]
    failures: list[dict[str, Any]] = []

    bbox_errors = [entry["semantic_id"] for entry in entries.values() if "bbox_pt" not in entry]
    if bbox_errors:
        failures.append({"gate": "bbox_generation", "items": bbox_errors})

    minimum_font = min(float(entry["font_size_pt"]) for entry in texts)
    if minimum_font < MIN_FONT_PT - 1e-9:
        failures.append({"gate": "minimum_font", "observed": minimum_font, "required": MIN_FONT_PT})

    canvas_violations = []
    for entry in entries.values():
        bbox = entry.get("bbox_pt")
        if not bbox:
            continue
        margins = [bbox[0], bbox[1], WIDTH_PT - bbox[2], HEIGHT_PT - bbox[3]]
        if min(margins) < -0.05:
            canvas_violations.append({"semantic_id": entry["semantic_id"], "margins_pt": margins})
    if canvas_violations:
        failures.append({"gate": "canvas_containment", "items": canvas_violations})

    safe_text_violations = []
    for entry in texts:
        bbox = entry["bbox_pt"]
        margins = [bbox[0], bbox[1], WIDTH_PT - bbox[2], HEIGHT_PT - bbox[3]]
        if min(margins) < SAFE_CANVAS_PT:
            safe_text_violations.append({"semantic_id": entry["semantic_id"], "minimum_margin_pt": min(margins)})
    if safe_text_violations:
        failures.append({"gate": "text_safe_canvas_band", "items": safe_text_violations})

    panel_violations = []
    for entry in entries.values():
        bbox = entry.get("bbox_pt")
        if not bbox:
            continue
        x, y, w, h = layout["panels_pt"][entry["panel"]]
        panel_bbox = [x, y, x + w, y + h]
        if not contains(panel_bbox, bbox, -PANEL_TOLERANCE_PT):
            panel_violations.append({"semantic_id": entry["semantic_id"], "bbox_pt": bbox, "panel_bbox_pt": panel_bbox})
    if panel_violations:
        failures.append({"gate": "panel_containment", "items": panel_violations})

    container_violations = []
    for entry in texts:
        container_id = entry.get("container")
        if not container_id:
            continue
        container = entries[container_id]
        clearance = float(entry.get("required_clearance_pt") or 0.0)
        if not contains(container["bbox_pt"], entry["bbox_pt"], clearance):
            container_violations.append(
                {
                    "semantic_id": entry["semantic_id"],
                    "container": container_id,
                    "clearance_pt": clearance,
                    "text_bbox_pt": entry["bbox_pt"],
                    "container_bbox_pt": container["bbox_pt"],
                }
            )
    if container_violations:
        failures.append({"gate": "text_container_clearance", "items": container_violations})

    text_overlaps = []
    for left, right in itertools.combinations(texts, 2):
        ix, iy = bbox_overlap(left["bbox_pt"], right["bbox_pt"])
        if ix <= TEXT_OVERLAP_TOLERANCE_PT or iy <= TEXT_OVERLAP_TOLERANCE_PT:
            continue
        # No text-text overlap is semantically intentional in this design.
        text_overlaps.append({"left": left["semantic_id"], "right": right["semantic_id"], "intersection_pt": [ix, iy]})
    if text_overlaps:
        failures.append({"gate": "text_text_overlap", "items": text_overlaps})

    # Labels may touch their own data marker via a leader line, but no other
    # marker or barrier may be occluded by text.
    graphics = [entry for entry in entries.values() if entry["kind"] in {"marker", "marker_group", "barrier", "arrow"}]
    text_graphic_overlaps = []
    for text_entry in texts:
        related = set(text_entry.get("related", []))
        for graphic in graphics:
            if graphic["semantic_id"] in related:
                continue
            ix, iy = bbox_overlap(text_entry["bbox_pt"], graphic["bbox_pt"])
            if ix > 0.25 and iy > 0.25:
                text_graphic_overlaps.append({"text": text_entry["semantic_id"], "graphic": graphic["semantic_id"], "intersection_pt": [ix, iy]})
    if text_graphic_overlaps:
        failures.append({"gate": "text_graphic_overlap", "items": text_graphic_overlaps})

    interpanel = []
    for left, right in itertools.combinations(texts, 2):
        if left["panel"] == right["panel"]:
            continue
        distance = bbox_distance(left["bbox_pt"], right["bbox_pt"])
        if distance < INTERPANEL_CLEARANCE_PT:
            interpanel.append({"left": left["semantic_id"], "right": right["semantic_id"], "distance_pt": distance})
    if interpanel:
        failures.append({"gate": "interpanel_text_clearance", "items": interpanel})

    panel_letters = sorted(entry["text"] for entry in texts if re.fullmatch(r"panel_[a-e]_letter", entry["semantic_id"]))
    if panel_letters != list("abcde"):
        failures.append({"gate": "panel_letters", "observed": panel_letters, "expected": list("abcde")})

    title_clearances = {}
    for panel in "abcde":
        letter = entries[f"panel_{panel}_letter"]["bbox_pt"]
        title = entries[f"panel_{panel}_title"]["bbox_pt"]
        title_clearances[panel] = bbox_distance(letter, title)
    if min(title_clearances.values()) < 5.0:
        failures.append({"gate": "panel_letter_title_clearance", "values_pt": title_clearances, "required": 5.0})

    near_coincident = {
        "beta_2": entries["panel_c_beta_marker_2"].get("metadata", {}),
        "beta_4_6": entries["panel_c_beta_marker_4"].get("metadata", {}),
        "rho_2": entries["panel_c_rho_marker_2"].get("metadata", {}),
        "rho_4_6": entries["panel_c_rho_marker_4"].get("metadata", {}),
    }
    nested_ok = all(record.get("near_coincident_encoding") is True for record in near_coincident.values())
    nested_ok = nested_ok and near_coincident["beta_2"].get("shape") == "D" and near_coincident["rho_2"].get("shape") == "D"
    nested_ok = nested_ok and near_coincident["beta_4_6"].get("shape") == "o" and near_coincident["rho_4_6"].get("shape") == "o"
    nested_ok = nested_ok and float(near_coincident["beta_4_6"].get("marker_size_pt", 0)) > float(near_coincident["beta_2"].get("marker_size_pt", 0))
    nested_ok = nested_ok and float(near_coincident["rho_4_6"].get("marker_size_pt", 0)) > float(near_coincident["rho_2"].get("marker_size_pt", 0))
    if not nested_ok:
        failures.append({"gate": "near_coincident_nested_shape_encoding", "records": near_coincident})

    rendered_text = "\n".join(entry.get("text", "") for entry in texts)
    prohibited = [
        "50:50",
        "fitness relevance",
        "coessentiality",
        "strong predictive",
        "strong local",
        "universality index",
        "Within context",
        "Universal causal law: hypothesis",
    ]
    present = [value for value in prohibited if value.casefold() in rendered_text.casefold()]
    if present:
        failures.append({"gate": "prohibited_constructs_absent", "present": present})

    return {
        "status": "pass" if not failures else "fail",
        "minimum_font_size_pt": minimum_font,
        "required_minimum_font_size_pt": MIN_FONT_PT,
        "minimum_canvas_text_margin_pt": min(
            min(entry["bbox_pt"][0], entry["bbox_pt"][1], WIDTH_PT - entry["bbox_pt"][2], HEIGHT_PT - entry["bbox_pt"][3])
            for entry in texts
        ),
        "panel_letter_title_clearance_pt": title_clearances,
        "failures": failures,
        "semantic_counts": {
            "all": len(entries),
            "text": len(texts),
            "containers": sum(entry["kind"] == "container" for entry in entries.values()),
            "graphics": len(graphics),
        },
    }


def png_audit(publication: Path, web: Path) -> dict[str, Any]:
    records = {}
    failures = []
    for label, path, expected in [("publication", publication, PUB_SIZE), ("web", web, WEB_SIZE)]:
        with Image.open(path) as image:
            record = {
                "size_px": list(image.size),
                "mode": image.mode,
                "format": image.format,
                "dpi": list(image.info.get("dpi", ())),
                "icc_bytes": len(image.info.get("icc_profile", b"")),
                "sha256": sha256(path),
                "file_size_bytes": path.stat().st_size,
            }
        records[label] = record
        if tuple(record["size_px"]) != expected or record["format"] != "PNG" or record["mode"] != "RGB" or record["icc_bytes"] < 1000:
            failures.append({"label": label, "record": record, "expected_size": list(expected)})
    publication_dpi = records["publication"]["dpi"]
    if len(publication_dpi) != 2 or any(abs(value - PUB_DPI) > 0.2 for value in publication_dpi):
        failures.append({"label": "publication_dpi", "observed": publication_dpi, "expected": PUB_DPI})
    return {"status": "pass" if not failures else "fail", "records": records, "failures": failures}


def responsive_png_audit(output_dir: Path, base: str) -> dict[str, Any]:
    failures = []
    records = {}
    for panel, (expected_width, expected_ratio) in RESPONSIVE_CROPS.items():
        path = output_dir / f"{base}_mobile_panel_{panel}.png"
        if not path.is_file():
            failures.append({"panel": panel, "missing": True})
            continue
        with Image.open(path) as image:
            record = {
                "filename": path.name,
                "size_px": list(image.size),
                "mode": image.mode,
                "format": image.format,
                "icc_bytes": len(image.info.get("icc_profile", b"")),
                "sha256": sha256(path),
                "file_size_bytes": path.stat().st_size,
            }
        records[panel] = record
        observed_ratio = record["size_px"][1] / record["size_px"][0]
        if (
            record["size_px"][0] != expected_width
            or abs(observed_ratio - expected_ratio) > 0.01
            or record["format"] != "PNG"
            or record["mode"] != "RGB"
            or record["icc_bytes"] < 1000
        ):
            failures.append({"panel": panel, "record": record, "expected_width": expected_width, "expected_ratio": expected_ratio})
    return {"status": "pass" if not failures else "fail", "records": records, "failures": failures}


def svg_audit(release_svg: Path, editable_svg: Path) -> dict[str, Any]:
    failures = []

    def inspect(path: Path) -> dict[str, Any]:
        root = ET.parse(path).getroot()
        tags = [element.tag.rsplit("}", 1)[-1] for element in root.iter()]
        external = []
        for element in root.iter():
            for key, value in element.attrib.items():
                if key.endswith("href") and value and not value.startswith("#"):
                    external.append(value)
        return {
            "width": root.attrib.get("width"),
            "height": root.attrib.get("height"),
            "viewBox": root.attrib.get("viewBox"),
            "text_elements": tags.count("text"),
            "image_elements": tags.count("image"),
            "script_elements": tags.count("script"),
            "external_references": external,
            "has_title": "title" in tags,
            "has_desc": "desc" in tags,
            "sha256": sha256(path),
            "file_size_bytes": path.stat().st_size,
        }

    release = inspect(release_svg)
    editable = inspect(editable_svg)
    expected_width = f"{WIDTH_PT:.6f}pt"
    expected_height = f"{HEIGHT_PT:.6f}pt"
    # Matplotlib serializes the exact point dimensions to six decimals.
    if release["image_elements"] or release["script_elements"] or release["external_references"] or release["text_elements"] != 0 or not release["has_title"] or not release["has_desc"]:
        failures.append({"release_structure": release})
    if editable["text_elements"] <= 0 or editable["image_elements"] or editable["script_elements"] or editable["external_references"] or not editable["has_title"] or not editable["has_desc"]:
        failures.append({"editable_structure": editable})
    return {"status": "pass" if not failures else "fail", "release": release, "editable": editable, "expected_dimensions_pt": [expected_width, expected_height], "failures": failures}


def pdf_audit(pdf: Path, qa_dir: Path) -> dict[str, Any]:
    info = run(["pdfinfo", str(pdf)]).stdout
    fonts = run(["pdffonts", str(pdf)]).stdout
    text_path = qa_dir / "CGT_FIGURE_004_pdf_text.txt"
    run(["pdftotext", "-layout", str(pdf), str(text_path)])
    extracted = text_path.read_text(encoding="utf-8", errors="replace")
    match = re.search(r"Page size:\s+([0-9.]+) x ([0-9.]+) pts", info)
    page_size = [float(match.group(1)), float(match.group(2))] if match else []
    font_rows = [line for line in fonts.splitlines()[2:] if line.strip()]
    embedded = all(len(line.split()) >= 5 and line.split()[-5] == "yes" for line in font_rows)
    required_phrases = [
        "Evidence register and permitted claim scope",
        "Study-conditioned candidate summaries",
        "Raw-metric atlas",
        "Generalization boundaries",
        "Scoped model and decisive falsifiers",
        "Universal axes, mechanism, and causal law",
    ]
    missing = [phrase for phrase in required_phrases if phrase not in extracted]
    failures = []
    if len(page_size) != 2 or abs(page_size[0] - WIDTH_PT) > 0.2 or abs(page_size[1] - HEIGHT_PT) > 0.2:
        failures.append({"page_size_pt": page_size, "expected": [WIDTH_PT, HEIGHT_PT]})
    if not embedded or not font_rows:
        failures.append({"embedded_fonts": embedded, "font_rows": font_rows})
    if missing:
        failures.append({"missing_text_phrases": missing})
    return {
        "status": "pass" if not failures else "fail",
        "page_size_pt": page_size,
        "font_rows": font_rows,
        "all_fonts_embedded": embedded,
        "missing_required_phrases": missing,
        "sha256": sha256(pdf),
        "file_size_bytes": pdf.stat().st_size,
        "failures": failures,
    }


def compare_images(reference: np.ndarray, candidate: np.ndarray) -> dict[str, float]:
    if reference.shape != candidate.shape:
        raise ValueError(f"Image shape mismatch: {reference.shape} vs {candidate.shape}")
    ref = reference.astype(np.float32) / 255.0
    cand = candidate.astype(np.float32) / 255.0
    mae = float(np.mean(np.abs(ref - cand)))
    blurred_ref = gaussian_filter(ref, sigma=(0.8, 0.8, 0.0))
    blurred_cand = gaussian_filter(cand, sigma=(0.8, 0.8, 0.0))
    blurred_mae = float(np.mean(np.abs(blurred_ref - blurred_cand)))
    ref_gray = np.mean(ref, axis=2)
    cand_gray = np.mean(cand, axis=2)
    ref_fg = ref_gray < 0.97
    cand_fg = cand_gray < 0.97
    union = np.logical_or(ref_fg, cand_fg).sum()
    iou = float(np.logical_and(ref_fg, cand_fg).sum() / union) if union else 1.0
    return {"mae": mae, "blurred_mae": blurred_mae, "foreground_iou": iou}


def cross_format_audit(pdf: Path, svg: Path, publication_png: Path, qa_dir: Path) -> dict[str, Any]:
    render_dir = qa_dir / "cross_format"
    render_dir.mkdir(parents=True, exist_ok=True)
    pdf_prefix = render_dir / "pdf_render"
    run(["pdftoppm", "-f", "1", "-singlefile", "-r", "300", "-png", str(pdf), str(pdf_prefix)])
    pdf_png = pdf_prefix.with_suffix(".png")
    svg_png = render_dir / "svg_render.png"
    run(["inkscape", str(svg), "--export-background=white", "--export-background-opacity=1", "--export-dpi=300", f"--export-filename={svg_png}"])
    with Image.open(publication_png) as image:
        reference = image.convert("RGB").resize((PUB_SIZE[0] // 2, PUB_SIZE[1] // 2), Image.Resampling.LANCZOS)
        reference_path = render_dir / "png_reference_300dpi.png"
        reference.save(reference_path, format="PNG", compress_level=9)
        reference_array = np.asarray(reference)
    comparisons = {}
    failures = []
    for label, path in [("pdf", pdf_png), ("svg", svg_png)]:
        with Image.open(path) as image:
            candidate = image.convert("RGB")
            if candidate.size != reference.size:
                candidate = candidate.resize(reference.size, Image.Resampling.LANCZOS)
            metrics = compare_images(reference_array, np.asarray(candidate))
        comparisons[label] = {**metrics, "render_path": path.relative_to(qa_dir).as_posix(), "render_sha256": sha256(path)}
        # PDF rasterizers use different antialiasing kernels from Agg.  A
        # 2.2% blurred-pixel tolerance remains strict while avoiding a false
        # failure on otherwise identical vector geometry.
        if metrics["blurred_mae"] > 0.022 or metrics["foreground_iou"] < 0.80:
            failures.append({"label": label, "metrics": metrics})
    return {"status": "pass" if not failures else "fail", "comparisons": comparisons, "failures": failures}


def scientific_audit(source_root: Path) -> dict[str, Any]:
    axis = pd.read_csv(source_root / "upstream" / "CGT_FIGURE_003_axis_evidence_revised.csv").sort_values("axis_order")
    robust = pd.read_csv(source_root / "upstream" / "CGT_FIGURE_002_Fig2f_robustness_revised.csv")
    fitness = pd.read_csv(source_root / "data" / "panel_d_fitness_replicates.csv")
    primary = robust.query("scheme == 'context'")
    f10 = axis[axis["axis_group"].isin(["chromatin_cytokine_mixed_F10", "lysosome_vacuole_ECM_F10"])]
    means = fitness.groupby("holdout")["value"].mean().to_dict()
    counts = fitness.groupby("holdout")["value"].count().to_dict()
    expected_axis = pd.DataFrame(
        [
            ["cytokine_JAK_STAT", 12.649556457442332, 0.0230289612442947, 0.291459977599043, 54.70399048013701, 15.989204346113153, 1.0],
            ["chromatin_epigenetic_F3_F15", 2.8570625286364586, 0.0291433720698778, 0.0204380319000126, 14.453307426269353, 0.0, 0.875],
            ["translation_ribosome_F12", 1.8518441747419447, 0.2485384811465163, 0.1560621399471362, 9.895405766057197, 21.098516298516543, 1.0],
            ["chromatin_cytokine_mixed_F10", 2.920190746921328, 0.0350931841529187, 0.134724483169892, 39.00414693883913, 21.53228550397331, 1.0],
            ["OXPHOS_respiration_F7", -3.540332110524896, 0.1005308527445166, 0.4412730039105584, 8.911222549485025, 11.143398275987423, 1.0],
            ["lysosome_vacuole_ECM_F10", 2.920190746921328, 0.0350931841529187, 0.134724483169892, 5.332190474384037, 4.328996088284147, 1.0],
            ["rRNA_ribosome_biogenesis_F11", 1.0478154565597313, 0.0389629647789583, 0.0323797650116311, 4.257053115298666, 3.2678910888296633, 1.0],
            ["SREBP_cholesterol_F5_F6", -2.254468376961656, 0.0372890955790998, 0.0444751736040125, 6.088098040902619, 5.077200706103071, 1.0],
            ["T_cell_antigen_receptor_F1", -2.5637699157070277, 0.0275309192301862, 0.0373876940207966, 3.1211926524442277, 3.6311028746314724, 0.6428571428571429],
        ],
        columns=["axis_group", "max_universality_index", "max_abs_ridge_beta", "max_abs_highconf_essentiality_rho", "ora_neglog10q", "rank_neglog10q", "max_study_proxy_share"],
    )
    observed_axis = axis[expected_axis.columns].reset_index(drop=True)
    axis_labels_exact = observed_axis["axis_group"].tolist() == expected_axis["axis_group"].tolist()
    axis_values_exact = bool(
        np.allclose(
            observed_axis.drop(columns="axis_group").to_numpy(float),
            expected_axis.drop(columns="axis_group").to_numpy(float),
            rtol=0.0,
            atol=1e-12,
        )
    )
    expected_residual = {
        "Leave dataset out": (0.5631954310094618, 0.3689688213908715, 0.7947583642010102, 34, 1092),
        "Exclude same-study proxy": (0.03499856479421135, -0.03730190469774627, 0.09315800786933376, 22, 507),
        "Leave context out": (0.07936776249079315, 0.048007139979823456, 0.12777730814694307, 7, 496),
    }
    residual_exact = True
    for holdout, expected in expected_residual.items():
        row = primary.loc[primary["holdout"] == holdout].iloc[0]
        observed = (float(row["mean"]), float(row["ci_low"]), float(row["ci_high"]), int(row["n_groups"]), int(row["n_rows"]))
        residual_exact = residual_exact and all(math.isclose(float(left), float(right), rel_tol=0.0, abs_tol=1e-12) for left, right in zip(observed, expected, strict=True))
    expected_fitness = {
        "Gene": (0.6223154520996811, 5),
        "Program family": (0.12680130020167518, 7),
        "Dataset": (0.09192061809717747, 5),
        "Context": (-0.05478337575664824, 4),
        "Study proxy": (-0.1422406281767974, 5),
    }
    fitness_exact = all(
        math.isclose(float(means[label]), expected_mean, rel_tol=0.0, abs_tol=1e-12) and int(counts[label]) == expected_count
        for label, (expected_mean, expected_count) in expected_fitness.items()
    )
    scope = pd.read_csv(source_root / "data" / "panel_e_scope.csv").sort_values("order")
    checks = {
        "nine_candidate_groups": len(axis) == 9,
        "all_candidate_labels_exact": axis_labels_exact,
        "all_candidate_numeric_cells_exact": axis_values_exact,
        "separate_corrected_ora_rank": bool((axis["ora_neglog10q"] >= 0).all() and (axis["rank_neglog10q"] >= 0).all()),
        "f10_recurrence_not_jittered": f10["max_universality_index"].nunique() == 1 and math.isclose(float(f10["max_universality_index"].iloc[0]), 2.920190746921328, abs_tol=1e-12),
        "study_share_range": math.isclose(float(axis["max_study_proxy_share"].min()), 0.6428571428571429, abs_tol=1e-12) and math.isclose(float(axis["max_study_proxy_share"].max()), 1.0, abs_tol=1e-12),
        "residual_three_designs": len(primary) == 3 and set(primary["holdout"]) == {"Leave dataset out", "Exclude same-study proxy", "Leave context out"},
        "all_residual_values_intervals_and_denominators_exact": residual_exact,
        "updated_leave_dataset_ci": math.isclose(float(primary.loc[primary["holdout"] == "Leave dataset out", "ci_low"].iloc[0]), 0.3689688213908715, abs_tol=1e-12),
        "updated_study_proxy_ci": math.isclose(float(primary.loc[primary["holdout"] == "Exclude same-study proxy", "ci_low"].iloc[0]), -0.03730190469774627, abs_tol=1e-12),
        "gene_fold_mean": math.isclose(float(means["Gene"]), 0.6223154520996811, abs_tol=1e-12),
        "program_family_mean": math.isclose(float(means["Program family"]), 0.12680130020167518, abs_tol=1e-12),
        "study_proxy_mean": math.isclose(float(means["Study proxy"]), -0.1422406281767974, abs_tol=1e-12),
        "all_fitness_means_and_finite_counts_exact": fitness_exact,
        "exactly_seven_study_shares_equal_one": int(axis["max_study_proxy_share"].eq(1.0).sum()) == 7,
        "scope_order_and_status_exact": scope[["order", "status"]].values.tolist() == [[1, "observed"], [2, "boundary"], [3, "predictive"], [4, "not_established"]],
        "scope_nonclaim_language_exact": str(scope.iloc[-1]["summary"]) == "No prospective mechanism or intervention test",
    }
    return {
        "status": "pass" if all(checks.values()) else "fail",
        "checks": checks,
        "fitness_means": means,
        "fitness_finite_counts": counts,
        "dominant_study_share_count_equal_one": int(axis["max_study_proxy_share"].eq(1.0).sum()),
        "f10_shared_values": f10[["max_universality_index", "max_abs_ridge_beta", "max_abs_highconf_essentiality_rho"]].to_dict(orient="records"),
        "prohibited_constructs_removed": ["50:50 composite fitness relevance", "bubble area pathway support", "coessentiality lift without q", "unreported recurrence jitter", "within-context duplicate row", "fitted-looking causal equations"],
    }


def accessibility_variants(publication_png: Path, qa_dir: Path) -> dict[str, Any]:
    target = qa_dir / "accessibility"
    target.mkdir(parents=True, exist_ok=True)
    with Image.open(publication_png) as image:
        rgb = np.asarray(image.convert("RGB"), dtype=np.float32) / 255.0
    matrices = {
        "protanopia": np.array([[0.56667, 0.43333, 0.0], [0.55833, 0.44167, 0.0], [0.0, 0.24167, 0.75833]]),
        "deuteranopia": np.array([[0.625, 0.375, 0.0], [0.70, 0.30, 0.0], [0.0, 0.30, 0.70]]),
        "tritanopia": np.array([[0.95, 0.05, 0.0], [0.0, 0.43333, 0.56667], [0.0, 0.475, 0.525]]),
    }
    records = {}
    gray = np.clip(np.dot(rgb[..., :3], [0.2126, 0.7152, 0.0722]), 0.0, 1.0)
    gray_path = target / "CGT_FIGURE_004_grayscale.png"
    Image.fromarray(np.uint8(np.round(gray * 255)), mode="L").save(gray_path, format="PNG", compress_level=9)
    records["grayscale"] = {"path": gray_path.relative_to(qa_dir).as_posix(), "sha256": sha256(gray_path)}
    for label, matrix in matrices.items():
        transformed = np.clip(rgb @ matrix.T, 0.0, 1.0)
        path = target / f"CGT_FIGURE_004_{label}.png"
        Image.fromarray(np.uint8(np.round(transformed * 255)), mode="RGB").save(path, format="PNG", compress_level=9)
        records[label] = {"path": path.relative_to(qa_dir).as_posix(), "sha256": sha256(path)}
    return {"status": "pass", "variants": records, "redundant_encodings": ["status text plus color", "tier letter plus color", "raw replicate circles plus mean diamonds", "study-share printed value plus fill"]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--qa-dir", type=Path, required=True)
    args = parser.parse_args()
    source_root = args.source_root.resolve()
    output_dir = args.output_dir.resolve()
    qa_dir = args.qa_dir.resolve()
    base = "CGT_FIGURE_004_dependency_aware_synthesis_revised"

    paths = {
        "layout": qa_dir / "CGT_FIGURE_004_layout_registry.json",
        "pdf": output_dir / f"{base}.pdf",
        "svg": output_dir / f"{base}.svg",
        "editable_svg": qa_dir / f"{base}_editable_text_QA.svg",
        "publication_png": output_dir / f"{base}_600dpi.png",
        "web_png": output_dir / f"{base}_web.png",
        **{
            f"mobile_panel_{panel}": output_dir / f"{base}_mobile_panel_{panel}.png"
            for panel in "abcde"
        },
    }
    missing = [str(path) for path in paths.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Missing required render artifacts: {missing}")

    sections = {
        "scientific": scientific_audit(source_root),
        "geometry": geometry_audit(paths["layout"]),
        "png": png_audit(paths["publication_png"], paths["web_png"]),
        "responsive": responsive_png_audit(output_dir, base),
        "svg": svg_audit(paths["svg"], paths["editable_svg"]),
        "pdf": pdf_audit(paths["pdf"], qa_dir),
        "cross_format": cross_format_audit(paths["pdf"], paths["svg"], paths["publication_png"], qa_dir),
        "accessibility": accessibility_variants(paths["publication_png"], qa_dir),
    }
    overall = "pass" if all(section["status"] == "pass" for section in sections.values()) else "fail"
    payload = {
        "schema_version": "1.0",
        "figure_id": "CGT_FIGURE_004",
        "audit_date_utc": "2026-08-23T00:00:00Z",
        "status": overall,
        "sections": sections,
        "artifact_hashes": {label: sha256(path) for label, path in paths.items()},
    }
    audit_path = output_dir / f"{base}_audit.json"
    audit_path.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": overall, "audit_path": str(audit_path), "section_status": {key: value["status"] for key, value in sections.items()}}, indent=2))
    if overall != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
