#!/usr/bin/env python3
"""Create the self-excluding manifest and byte-deterministic Figure 4 ZIP."""

from __future__ import annotations

import argparse
import hashlib
import json
import mimetypes
import shutil
import stat
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from typing import Any

from PIL import Image

from verify_cgt_figure_004_release import (
    MANIFEST_NAME,
    RELEASE_ID,
    EXPECTED_ROLE_PATHS,
    VerificationError,
    canonical_json,
    sha256,
    validate_relative,
    verify_release,
    walk_files,
)


ROLE_BY_PATH = {path: role for role, path in EXPECTED_ROLE_PATHS.items()}


def infer_role(relative: str) -> str:
    if relative in ROLE_BY_PATH:
        return ROLE_BY_PATH[relative]
    if relative == "README.md":
        return "release_readme"
    if relative.startswith("source/upstream/"):
        return "frozen_upstream_table"
    if relative.startswith("source/data/"):
        return "frozen_renderer_input"
    if relative.startswith("audit/"):
        return "quality_assurance"
    if relative.startswith("documentation/"):
        return "release_documentation"
    if relative.startswith("code/"):
        return "reproduction_code"
    return "supporting_artifact"


def mime(path: Path) -> str:
    pinned = {
        ".png": "image/png", ".pdf": "application/pdf", ".svg": "image/svg+xml",
        ".json": "application/json", ".csv": "text/csv", ".md": "text/markdown",
        ".py": "text/x-python", ".icc": "application/vnd.iccprofile", ".txt": "text/plain",
    }
    if path.suffix.lower() not in pinned:
        guessed = mimetypes.guess_type(path.name)[0]
        if not guessed:
            raise VerificationError(f"Unknown MIME type: {path}")
        return guessed
    return pinned[path.suffix.lower()]


def structural_metadata(path: Path) -> dict[str, Any] | None:
    """Return deterministic, manifest-level structure for public visual assets."""
    suffix = path.suffix.lower()
    if suffix == ".png":
        with Image.open(path) as image:
            icc = image.info.get("icc_profile", b"")
            dpi = image.info.get("dpi", ())
            return {
                "format": image.format,
                "mode": image.mode,
                "size_px": list(image.size),
                "dpi": [round(float(value), 6) for value in dpi],
                "icc_bytes": len(icc),
                "icc_sha256": hashlib.sha256(icc).hexdigest() if icc else None,
            }
    if suffix == ".svg":
        root = ET.parse(path).getroot()
        tags = [element.tag.rsplit("}", 1)[-1] for element in root.iter()]
        return {
            "format": "SVG",
            "view_box": root.attrib.get("viewBox"),
            "width": root.attrib.get("width"),
            "height": root.attrib.get("height"),
            "has_title": "title" in tags,
            "has_description": "desc" in tags,
            "text_elements": tags.count("text"),
            "image_elements": tags.count("image"),
        }
    if suffix == ".pdf":
        result = subprocess.run(["pdfinfo", str(path)], check=False, capture_output=True, text=True)
        if result.returncode:
            raise VerificationError(f"pdfinfo rejected {path}: {result.stderr}")
        page_size = next((line.split(":", 1)[1].strip() for line in result.stdout.splitlines() if line.startswith("Page size:")), None)
        pages = next((line.split(":", 1)[1].strip() for line in result.stdout.splitlines() if line.startswith("Pages:")), None)
        return {"format": "PDF", "pages": int(pages) if pages else None, "page_size": page_size}
    return None


def write_manifest(root: Path) -> Path:
    path = root / MANIFEST_NAME
    if path.exists():
        raise VerificationError(f"Refusing to overwrite manifest: {path}")
    entries = []
    for relative in walk_files(root):
        if relative == MANIFEST_NAME:
            continue
        source = root / relative
        entry = {
            "path": relative,
            "role": infer_role(relative),
            "bytes": source.stat().st_size,
            "sha256": sha256(source),
            "mime_type": mime(source),
        }
        structure = structural_metadata(source)
        if structure is not None:
            entry["dimensions"] = structure
        entries.append(entry)
    payload = {
        "schema_version": "1.0.0",
        "release_id": RELEASE_ID,
        "title": "Dependency-aware synthesis of current CGT analyses and their generalization boundaries",
        "manifest_policy": {
            "self_excluding": True,
            "manifest_path": MANIFEST_NAME,
            "listed_scope": "Every other regular file below the release root; the manifest itself is the sole exclusion.",
        },
        "entries": entries,
    }
    path.write_bytes(canonical_json(payload))
    return path


def build_once(root: Path, files: list[str], destination: Path) -> None:
    timestamp = (2026, 8, 23, 0, 0, 0)
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=False) as archive:
        archive.comment = b""
        for relative in files:
            validate_relative(relative)
            source = root / relative
            if source.stat().st_nlink != 1:
                raise VerificationError(f"Hard-linked release member forbidden: {relative}")
            info = zipfile.ZipInfo(f"{RELEASE_ID}/{relative}", timestamp)
            info.create_system = 3
            info.create_version = 20
            info.extract_version = 20
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            info._compresslevel = 9
            info.flag_bits = 0
            info.extra = b""
            info.comment = b""
            with source.open("rb") as source_handle, archive.open(info, "w", force_zip64=False) as target:
                shutil.copyfileobj(source_handle, target, length=1 << 20)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--zip", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    zip_path = args.zip.resolve()
    metadata_path = args.metadata.resolve()
    manifest_path = root / MANIFEST_NAME
    created_manifest = False
    created_zip = False
    created_metadata = False
    try:
        if root.name != RELEASE_ID or zip_path.exists() or metadata_path.exists():
            raise VerificationError("Invalid release root or output already exists")
        if len({root, zip_path, metadata_path}) != 3:
            raise VerificationError("Release root, ZIP, and metadata paths must be distinct")
        if root in zip_path.parents or root in metadata_path.parents:
            raise VerificationError("ZIP and external metadata must be outside the release root")
        zip_path.parent.mkdir(parents=True, exist_ok=True)
        metadata_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path = write_manifest(root)
        created_manifest = True
        verify_release(root)
        files = walk_files(root)
        with tempfile.TemporaryDirectory(prefix="cgt_figure_004_zip_", dir=str(zip_path.parent)) as temporary:
            first = Path(temporary) / "first.zip"
            second = Path(temporary) / "second.zip"
            build_once(root, files, first)
            build_once(root, files, second)
            if first.stat().st_size != second.stat().st_size or sha256(first) != sha256(second):
                raise VerificationError("Independent ZIP builds were not byte-identical")
            shutil.copyfile(first, zip_path)
            created_zip = True
        verification = verify_release(root, zip_path)
        metadata: dict[str, Any] = {
            "schema_version": "1.0.0",
            "status": "pass",
            "release_id": RELEASE_ID,
            "zip": verification["zip"],
            "manifest": {
                "bytes": manifest_path.stat().st_size,
                "sha256": sha256(manifest_path),
                "entry_count": len(load_entries := json.loads(manifest_path.read_text(encoding="utf-8"))["entries"]),
                "self_excluding": True,
            },
            "determinism": {
                "two_independent_builds_byte_identical": True,
                "fixed_zip_dos_datetime": [2026, 8, 23, 0, 0, 0],
                "member_mode": "0644",
                "compression": "deflate-9",
            },
        }
        metadata_path.write_bytes(canonical_json(metadata))
        created_metadata = True
    except Exception as exc:
        for path, created in ((metadata_path, created_metadata), (zip_path, created_zip), (manifest_path, created_manifest)):
            if created and path.is_file():
                path.unlink()
        sys.stderr.buffer.write(canonical_json({"status": "fail", "error": str(exc)}))
        return 1
    sys.stdout.buffer.write(canonical_json({
        "status": "pass", "zip": str(zip_path), "zip_bytes": zip_path.stat().st_size,
        "zip_sha256": sha256(zip_path), "metadata": str(metadata_path),
    }))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
