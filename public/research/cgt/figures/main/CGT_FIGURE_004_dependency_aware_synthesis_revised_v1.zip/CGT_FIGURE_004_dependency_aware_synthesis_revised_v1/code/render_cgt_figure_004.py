#!/usr/bin/env python3
"""Deterministic renderer for the audited revision of CGT Figure 4.

Figure 4 is explicitly a synthesis of the frozen, revised Figure 1-3
artifacts.  This renderer does not refit a model, rerun enrichment, or create
an aggregate evidence score.  It replaces the original composite with a
claim-scope register, corrected candidate-summary matrix, raw-metric views,
generalization-boundary plots, and a scope-constrained model.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import html
import json
import math
import os
import platform
from pathlib import Path
from typing import Any, Iterable

os.environ.setdefault("MPLCONFIGDIR", "/tmp/cgt_figure_004_mplconfig")
os.environ.setdefault("SOURCE_DATE_EPOCH", "1787443200")
os.environ.setdefault("TZ", "UTC")
os.environ.setdefault("LC_ALL", "C.UTF-8")

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, Normalize, TwoSlopeNorm, to_rgb
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle
from PIL import Image


MM_TO_PT = 72.0 / 25.4
WIDTH_MM = 183.0
HEIGHT_MM = 204.0
WIDTH_PT = WIDTH_MM * MM_TO_PT
HEIGHT_PT = HEIGHT_MM * MM_TO_PT
PUB_DPI = 600
# Matplotlib rasterizes a fixed physical canvas by truncating fractional
# pixels. Record that exact behaviour rather than rounding up by one pixel.
PUB_SIZE = (int(WIDTH_MM / 25.4 * PUB_DPI), int(HEIGHT_MM / 25.4 * PUB_DPI))
WEB_WIDTH_PX = 2400
WEB_SIZE = (WEB_WIDTH_PX, round(WEB_WIDTH_PX * HEIGHT_MM / WIDTH_MM))
FIXED_DATE = dt.datetime(2026, 8, 23, tzinfo=dt.timezone.utc)

FONT_REGULAR = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
FONT_BOLD = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
FONT_HASHES = {
    "regular": "ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280",
    "bold": "5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895",
}

COLORS = {
    "ink": "#17232D",
    "muted": "#586873",
    "grid": "#DCE3E7",
    "rule": "#BFC9CF",
    "white": "#FFFFFF",
    "paper": "#FFFFFF",
    "light": "#F4F7F8",
    "navy": "#215A78",
    "navy_dark": "#173F56",
    "blue": "#2C7FB8",
    "teal": "#258F83",
    "purple": "#6D5A8E",
    "orange": "#C96D18",
    "orange_dark": "#8B4A10",
    "orange_light": "#FBEFDF",
    "grey": "#6F7B83",
    "grey_light": "#EEF2F4",
    "posthoc": "#7A638F",
    "conditional": "#258F83",
    "predictive": "#215A78",
}

PANEL_BOXES_PT = {
    "a": (24.0, 442.0, WIDTH_PT - 48.0, 116.0),
    "b": (24.0, 260.0, WIDTH_PT - 48.0, 168.0),
    "c": (24.0, 114.0, 170.0, 140.0),
    "d": (208.0, 114.0, WIDTH_PT - 232.0, 140.0),
    "e": (24.0, 20.0, WIDTH_PT - 48.0, 80.0),
}

# Website-only crops preserve the canonical composition while allowing panels
# c and d to be enlarged independently on narrow screens. Panels a, b, and e
# are intended to sit in an accessible horizontal-scroll wrapper at a minimum
# rendered width, never be squeezed to an unreadable phone width.
RESPONSIVE_CROPS_PT = {
    "a": (19.0, 437.0, WIDTH_PT - 38.0, 126.0, 1600),
    "b": (19.0, 255.0, WIDTH_PT - 38.0, 178.0, 1600),
    "c": (19.0, 109.0, 180.0, 150.0, 1200),
    "d": (197.0, 109.0, WIDTH_PT - 202.0, 150.0, 1600),
    "e": (19.0, 15.0, WIDTH_PT - 38.0, 90.0, 1600),
}

STATUS_LABEL = {
    "descriptive": "DESCRIPTIVE",
    "conditional": "CONDITIONAL",
    "predictive": "PREDICTIVE",
    "post_hoc": "POST HOC",
    "not_tested": "NOT TESTED",
}

STATUS_COLOR = {
    "descriptive": COLORS["navy"],
    "conditional": COLORS["teal"],
    "predictive": COLORS["navy_dark"],
    "post_hoc": COLORS["posthoc"],
    "not_tested": COLORS["grey"],
}

AXIS_LABELS = {
    "cytokine_JAK_STAT": "Cytokine / JAK–STAT",
    "chromatin_epigenetic_F3_F15": "Chromatin / epigenetic",
    "translation_ribosome_F12": "Translation / RQC",
    "chromatin_cytokine_mixed_F10": "Chromatin–cytokine",
    "OXPHOS_respiration_F7": "OXPHOS / TCA",
    "lysosome_vacuole_ECM_F10": "Lysosome / ECM",
    "rRNA_ribosome_biogenesis_F11": "rRNA biogenesis",
    "SREBP_cholesterol_F5_F6": "SREBP / cholesterol",
    "T_cell_antigen_receptor_F1": "Antigen-receptor / tolerance",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_fonts_and_profile(profile: Path) -> None:
    observed = {"regular": sha256(FONT_REGULAR), "bold": sha256(FONT_BOLD)}
    if observed != FONT_HASHES:
        raise RuntimeError(f"Pinned font hash mismatch: {observed}")
    if not profile.is_file() or profile.stat().st_size < 1000:
        raise RuntimeError(f"Missing or invalid sRGB profile: {profile}")


REGULAR = FontProperties(fname=str(FONT_REGULAR))
BOLD = FontProperties(fname=str(FONT_BOLD))


class Registry:
    """Semantic registry used by the strict geometry auditor."""

    def __init__(self, fig: mpl.figure.Figure) -> None:
        self.fig = fig
        self.entries: list[dict[str, Any]] = []
        self.artists: dict[str, Any] = {}
        self.panels = {key: [float(v) for v in box] for key, box in PANEL_BOXES_PT.items()}

    def add(
        self,
        semantic_id: str,
        artist: Any,
        *,
        kind: str,
        panel: str,
        container: str | None = None,
        clearance_pt: float | None = None,
        related: Iterable[str] = (),
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        if semantic_id in self.artists:
            raise ValueError(f"Duplicate semantic id: {semantic_id}")
        if hasattr(artist, "set_gid"):
            artist.set_gid(semantic_id)
        self.artists[semantic_id] = artist
        entry: dict[str, Any] = {
            "semantic_id": semantic_id,
            "kind": kind,
            "panel": panel,
            "container": container,
            "required_clearance_pt": clearance_pt,
            "related": list(related),
            "metadata": metadata or {},
        }
        if kind == "text":
            entry["text"] = str(artist.get_text())
            entry["font_size_pt"] = float(artist.get_fontsize())
        self.entries.append(entry)
        return artist

    def finalize(self, path: Path) -> None:
        self.fig.canvas.draw()
        renderer = self.fig.canvas.get_renderer()
        dpi = float(self.fig.dpi)
        by_id = {entry["semantic_id"]: entry for entry in self.entries}
        for semantic_id, artist in self.artists.items():
            entry = by_id[semantic_id]
            try:
                bbox = artist.get_window_extent(renderer)
                entry["bbox_pt"] = [float(value) * 72.0 / dpi for value in bbox.extents]
            except Exception as exc:  # pragma: no cover - fail-fast metadata
                entry["bbox_error"] = str(exc)
            entry["zorder"] = float(artist.get_zorder()) if hasattr(artist, "get_zorder") else None
            entry["clip_on"] = bool(artist.get_clip_on()) if hasattr(artist, "get_clip_on") else None
        payload = {
            "schema_version": "1.0",
            "figure_id": "CGT_FIGURE_004",
            "canvas": {
                "width_mm": WIDTH_MM,
                "height_mm": HEIGHT_MM,
                "width_pt": WIDTH_PT,
                "height_pt": HEIGHT_PT,
                "publication_dpi": PUB_DPI,
                "publication_size_px": list(PUB_SIZE),
                "web_size_px": list(WEB_SIZE),
            },
            "minimum_font_size_pt": min(
                entry["font_size_pt"] for entry in self.entries if entry["kind"] == "text"
            ),
            "panels_pt": self.panels,
            "entries": self.entries,
        }
        path.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def configure_matplotlib(*, svg_text_as_paths: bool) -> None:
    mpl.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.sans-serif": ["DejaVu Sans"],
            "font.size": 7.0,
            "axes.labelsize": 7.0,
            "axes.titlesize": 8.0,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "axes.linewidth": 0.6,
            "lines.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "path" if svg_text_as_paths else "none",
            "svg.hashsalt": "CGT_FIGURE_004_REVISED_V1",
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "text.color": COLORS["ink"],
            "axes.labelcolor": COLORS["ink"],
            "xtick.color": COLORS["ink"],
            "ytick.color": COLORS["ink"],
        }
    )


def fig_text(
    fig: plt.Figure,
    registry: Registry,
    x: float,
    y: float,
    value: str,
    *,
    semantic_id: str,
    panel: str,
    size: float = 7.0,
    weight: str = "normal",
    color: str = COLORS["ink"],
    ha: str = "left",
    va: str = "top",
    linespacing: float = 1.12,
    container: str | None = None,
    clearance_pt: float | None = None,
    related: Iterable[str] = (),
    zorder: float = 5.0,
) -> mpl.text.Text:
    artist = fig.text(
        x / WIDTH_PT,
        y / HEIGHT_PT,
        value,
        transform=fig.transFigure,
        fontsize=size,
        fontproperties=BOLD if weight in {"bold", "semibold"} else REGULAR,
        fontweight="bold" if weight in {"bold", "semibold"} else "normal",
        color=color,
        ha=ha,
        va=va,
        linespacing=linespacing,
        zorder=zorder,
    )
    return registry.add(
        semantic_id,
        artist,
        kind="text",
        panel=panel,
        container=container,
        clearance_pt=clearance_pt,
        related=related,
    )


def fig_rect(
    fig: plt.Figure,
    registry: Registry,
    x: float,
    y: float,
    w: float,
    h: float,
    *,
    semantic_id: str,
    panel: str,
    facecolor: str = COLORS["white"],
    edgecolor: str = COLORS["rule"],
    linewidth: float = 0.5,
    rounded: bool = False,
    zorder: float = 1.0,
) -> mpl.patches.Patch:
    if rounded:
        artist = FancyBboxPatch(
            (x / WIDTH_PT, y / HEIGHT_PT),
            w / WIDTH_PT,
            h / HEIGHT_PT,
            boxstyle="round,pad=0.003,rounding_size=0.008",
            transform=fig.transFigure,
            facecolor=facecolor,
            edgecolor=edgecolor,
            linewidth=linewidth,
            zorder=zorder,
        )
    else:
        artist = Rectangle(
            (x / WIDTH_PT, y / HEIGHT_PT),
            w / WIDTH_PT,
            h / HEIGHT_PT,
            transform=fig.transFigure,
            facecolor=facecolor,
            edgecolor=edgecolor,
            linewidth=linewidth,
            zorder=zorder,
        )
    fig.add_artist(artist)
    return registry.add(semantic_id, artist, kind="container", panel=panel)


def add_axes_pt(fig: plt.Figure, box: tuple[float, float, float, float], *, gid: str) -> plt.Axes:
    x, y, w, h = box
    ax = fig.add_axes([x / WIDTH_PT, y / HEIGHT_PT, w / WIDTH_PT, h / HEIGHT_PT])
    ax.set_gid(gid)
    return ax


def add_panel_header(
    fig: plt.Figure,
    registry: Registry,
    panel: str,
    title: str,
    subtitle: str = "",
) -> None:
    x, y, _, h = PANEL_BOXES_PT[panel]
    top = y + h
    fig_text(fig, registry, x, top, panel, semantic_id=f"panel_{panel}_letter", panel=panel, size=10.0, weight="bold")
    fig_text(fig, registry, x + 15.0, top - 0.2, title, semantic_id=f"panel_{panel}_title", panel=panel, size=8.6, weight="bold")
    if subtitle:
        fig_text(
            fig,
            registry,
            x + 15.0,
            top - 11.8,
            subtitle,
            semantic_id=f"panel_{panel}_subtitle",
            panel=panel,
            size=6.5,
            color=COLORS["muted"],
        )


def luminance(hex_color: str) -> float:
    values = []
    for channel in to_rgb(hex_color):
        values.append(channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4)
    return 0.2126 * values[0] + 0.7152 * values[1] + 0.0722 * values[2]


def contrast_ratio(first: str, second: str) -> float:
    left, right = sorted([luminance(first), luminance(second)], reverse=True)
    return (left + 0.05) / (right + 0.05)


def readable_text_color(background: str) -> str:
    white = contrast_ratio(COLORS["white"], background)
    ink = contrast_ratio(COLORS["ink"], background)
    return COLORS["white"] if white >= ink else COLORS["ink"]


def blend(first: str, second: str, amount: float) -> str:
    a = np.array(to_rgb(first))
    b = np.array(to_rgb(second))
    rgb = (1.0 - amount) * a + amount * b
    return "#" + "".join(f"{round(value * 255):02X}" for value in rgb)


def validate_inputs(source_root: Path) -> dict[str, pd.DataFrame]:
    paths = {
        "claim_scope": source_root / "data" / "panel_a_claim_scope.csv",
        "fitness": source_root / "data" / "panel_d_fitness_replicates.csv",
        "scope": source_root / "data" / "panel_e_scope.csv",
        "robustness": source_root / "upstream" / "CGT_FIGURE_002_Fig2f_robustness_revised.csv",
        "axis": source_root / "upstream" / "CGT_FIGURE_003_axis_evidence_revised.csv",
    }
    for path in paths.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    tables = {key: pd.read_csv(path) for key, path in paths.items()}

    claim = tables["claim_scope"]
    axis = tables["axis"].sort_values("axis_order").reset_index(drop=True)
    robust = tables["robustness"]
    fit = tables["fitness"]
    scope = tables["scope"]

    assertions = [
        (len(claim) == 5 and list(claim["order"]) == [1, 2, 3, 4, 5], "claim-scope rows"),
        (set(claim["status"]) == set(STATUS_LABEL), "claim-scope status vocabulary"),
        (len(axis) == 9 and list(axis["axis_order"]) == list(range(9)), "candidate-axis rows"),
        (axis["axis_group"].is_unique, "candidate-axis group uniqueness"),
        (len(robust) == 9, "revised Figure 2 robustness rows"),
        (len(robust.query("scheme == 'context'")) == 3, "primary context residual rows"),
        (len(fit) == 26 and fit["metric"].eq("regression_spearman").all(), "fitness replicates"),
        (fit.groupby("holdout").size().to_dict() == {"Context": 4, "Dataset": 5, "Gene": 5, "Program family": 7, "Study proxy": 5}, "fitness replicate counts"),
        (len(scope) == 4, "scope model rows"),
    ]
    for passed, label in assertions:
        if not passed:
            raise ValueError(f"Input validation failed: {label}")

    exact_checks = {
        "context_leave_dataset_mean": (float(robust.query("scheme == 'context' and holdout == 'Leave dataset out'")["mean"].iloc[0]), 0.5631954310094618),
        "context_exclude_study_mean": (float(robust.query("scheme == 'context' and holdout == 'Exclude same-study proxy'")["mean"].iloc[0]), 0.03499856479421135),
        "context_leave_context_mean": (float(robust.query("scheme == 'context' and holdout == 'Leave context out'")["mean"].iloc[0]), 0.07936776249079315),
        "gene_spearman_mean": (float(fit.query("holdout == 'Gene'")["value"].mean()), 0.6223154520996811),
        "f14_recurrence": (float(axis.loc[axis["axis_group"] == "cytokine_JAK_STAT", "max_universality_index"].iloc[0]), 12.649556457442332),
        "f10_duplicate_recurrence": (
            float(axis.loc[axis["axis_group"] == "chromatin_cytokine_mixed_F10", "max_universality_index"].iloc[0]),
            float(axis.loc[axis["axis_group"] == "lysosome_vacuole_ECM_F10", "max_universality_index"].iloc[0]),
        ),
    }
    for label, (observed, expected) in exact_checks.items():
        if not math.isclose(observed, expected, rel_tol=0.0, abs_tol=1e-12):
            raise ValueError(f"Exact source check failed for {label}: {observed} != {expected}")

    tables["axis"] = axis
    return tables


def draw_panel_a(fig: plt.Figure, registry: Registry, table: pd.DataFrame) -> None:
    panel = "a"
    x, y, w, h = PANEL_BOXES_PT[panel]
    add_panel_header(
        fig,
        registry,
        panel,
        "Evidence register and permitted claim scope",
        "Figure 4 integrates earlier analyses; rows are not independent replications and do not form a validation ladder.",
    )
    table_x = x + 15.0
    table_w = w - 15.0
    status_w, domain_w, summary_w = 57.0, 93.0, 142.0
    interpretation_w = table_w - status_w - domain_w - summary_w
    widths = [status_w, domain_w, summary_w, interpretation_w]
    starts = np.cumsum([table_x] + widths[:-1]).tolist()
    header_y = y + h - 31.0
    header_h = 12.0
    headers = ["STATUS", "EVIDENCE DOMAIN", "OBSERVED SUMMARY", "PERMITTED INTERPRETATION"]
    for index, (start, width, value) in enumerate(zip(starts, widths, headers, strict=True)):
        cid = f"panel_a_header_cell_{index}"
        fig_rect(fig, registry, start, header_y - header_h, width, header_h, semantic_id=cid, panel=panel, facecolor=COLORS["grey_light"], edgecolor=COLORS["rule"], linewidth=0.45)
        fig_text(fig, registry, start + 4.0, header_y - 3.2, value, semantic_id=f"panel_a_header_{index}", panel=panel, size=6.2, weight="bold", va="top", container=cid, clearance_pt=2.0)

    row_h = 14.2
    body_top = header_y - header_h
    domain_values = {
        "Family recurrence": "Family recurrence",
        "Same-label residual transfer": "Same-label residual\ntransfer",
        "Shared-endpoint fitness prediction": "Shared-endpoint fitness\nprediction",
        "Curated pathway coherence": "Curated pathway\ncoherence",
        "Causal mechanism": "Causal mechanism",
    }
    summary_values = {
        1: "248 modes · 43 datasets · 9 contexts\n16 unsupervised families",
        2: "Leave-dataset cosine 0.563\nstudy-proxy exclusion 0.035",
        3: "Mean fold ρ 0.622 (5 folds)\n1,229-gene benchmark",
        4: "9 displayed candidate annotations\nstudy share 0.643–1.000",
        5: "No prospective intervention or\nexternal-study mechanism test",
    }
    interpretation_values = {
        1: "Descriptive, run-relative structure;\nnot a transportability estimate",
        2: "Association inside the assembled pipeline;\nbroad transport is not established",
        3: "Predictive for the frozen gene benchmark;\ngrouped holdouts are unstable",
        4: "Post hoc, study-conditioned shorthand;\nnot independent biological replication",
        5: "Universal axes, mechanism, and causal law\nare not established",
    }
    for row_index, row in table.iterrows():
        row_y = body_top - (row_index + 1) * row_h
        fill = COLORS["white"] if row_index % 2 == 0 else COLORS["light"]
        cell_ids = []
        for col_index, (start, width) in enumerate(zip(starts, widths, strict=True)):
            cid = f"panel_a_row_{row_index}_cell_{col_index}"
            fig_rect(fig, registry, start, row_y, width, row_h, semantic_id=cid, panel=panel, facecolor=fill, edgecolor=COLORS["grid"], linewidth=0.35)
            cell_ids.append(cid)
        status = str(row["status"])
        chip_x = starts[0] + 4.0
        chip_y = row_y + 3.0
        chip_w = widths[0] - 8.0
        chip_h = row_h - 6.0
        chip_id = f"panel_a_status_chip_{row_index}"
        fig_rect(fig, registry, chip_x, chip_y, chip_w, chip_h, semantic_id=chip_id, panel=panel, facecolor=STATUS_COLOR[status], edgecolor=STATUS_COLOR[status], linewidth=0.0, rounded=True, zorder=2)
        fig_text(fig, registry, chip_x + chip_w / 2, chip_y + chip_h / 2, STATUS_LABEL[status], semantic_id=f"panel_a_status_{row_index}", panel=panel, size=6.0, weight="bold", color=COLORS["white"], ha="center", va="center", container=chip_id, clearance_pt=0.5, zorder=3)
        order = int(row["order"])
        fig_text(fig, registry, starts[1] + 4.0, row_y + row_h / 2, domain_values[str(row["evidence_domain"])], semantic_id=f"panel_a_domain_{row_index}", panel=panel, size=6.2, weight="bold", va="center", linespacing=1.0, container=cell_ids[1], clearance_pt=0.5)
        fig_text(fig, registry, starts[2] + 4.0, row_y + row_h / 2, summary_values[order], semantic_id=f"panel_a_summary_{row_index}", panel=panel, size=6.15, va="center", linespacing=1.0, container=cell_ids[2], clearance_pt=0.5)
        fig_text(fig, registry, starts[3] + 4.0, row_y + row_h / 2, interpretation_values[order], semantic_id=f"panel_a_interpretation_{row_index}", panel=panel, size=6.15, va="center", linespacing=1.0, container=cell_ids[3], clearance_pt=0.5)


def draw_panel_b(fig: plt.Figure, registry: Registry, table: pd.DataFrame) -> None:
    panel = "b"
    x, y, w, h = PANEL_BOXES_PT[panel]
    add_panel_header(
        fig,
        registry,
        panel,
        "Study-conditioned candidate summaries",
        "Raw maxima from revised Figure 3; shading is scaled separately within each column and does not define a combined score.",
    )

    table_x = x + 15.0
    widths = [16.0, 111.0, 24.0, 50.0, 49.0, 49.0, 48.0, 48.0, w - 15.0 - 16.0 - 111.0 - 24.0 - 50.0 - 49.0 - 49.0 - 48.0 - 48.0]
    starts = np.cumsum([table_x] + widths[:-1]).tolist()
    group_y = y + h - 30.0
    header_y = group_y - 10.0
    header_h = 17.0
    body_top = header_y - header_h
    row_h = 11.25

    # Dependency labels over paired columns.
    fig_text(fig, registry, starts[4] + (widths[4] + widths[5]) / 2, group_y - 1.0, "same residual coordinates", semantic_id="panel_b_group_coordinates", panel=panel, size=6.0, weight="bold", color=COLORS["teal"], ha="center")
    fig_text(fig, registry, starts[6] + (widths[6] + widths[7]) / 2, group_y - 1.0, "same DepMap endpoint", semantic_id="panel_b_group_endpoint", panel=panel, size=6.0, weight="bold", color=COLORS["purple"], ha="center")

    headers = ["#", "CANDIDATE LABEL", "TIER*", "RECURRENCE\n$R_f$", "ORA\n−log₁₀(q)", "RANK\n−log₁₀(q)", "MAX\n|β|", "MAX\n|ρ|", "MAX STUDY\nSHARE"]
    for col_index, (start, width, value) in enumerate(zip(starts, widths, headers, strict=True)):
        cid = f"panel_b_header_cell_{col_index}"
        fig_rect(fig, registry, start, body_top, width, header_h, semantic_id=cid, panel=panel, facecolor=COLORS["grey_light"], edgecolor=COLORS["rule"], linewidth=0.4)
        fig_text(fig, registry, start + width / 2, body_top + header_h / 2, value, semantic_id=f"panel_b_header_{col_index}", panel=panel, size=6.0, weight="bold", ha="center", va="center", linespacing=0.98, container=cid, clearance_pt=0.8)

    dependency_divider = Line2D(
        [starts[6] / WIDTH_PT, starts[6] / WIDTH_PT],
        [(group_y - 8.0) / HEIGHT_PT, (group_y + 7.0) / HEIGHT_PT],
        transform=fig.transFigure,
        color=COLORS["rule"],
        linewidth=0.55,
        zorder=4,
    )
    fig.add_artist(dependency_divider)
    registry.add("panel_b_dependency_group_divider", dependency_divider, kind="divider", panel=panel)

    numeric_columns = [
        "max_universality_index",
        "ora_neglog10q",
        "rank_neglog10q",
        "max_abs_ridge_beta",
        "max_abs_highconf_essentiality_rho",
        "max_study_proxy_share",
    ]
    norm_map: dict[str, mpl.colors.Normalize] = {
        "max_universality_index": TwoSlopeNorm(vmin=-13.0, vcenter=0.0, vmax=13.0),
        "ora_neglog10q": Normalize(vmin=0.0, vmax=float(table["ora_neglog10q"].max())),
        "rank_neglog10q": Normalize(vmin=0.0, vmax=float(table["rank_neglog10q"].max())),
        "max_abs_ridge_beta": Normalize(vmin=0.0, vmax=float(table["max_abs_ridge_beta"].max())),
        "max_abs_highconf_essentiality_rho": Normalize(vmin=0.0, vmax=float(table["max_abs_highconf_essentiality_rho"].max())),
        "max_study_proxy_share": Normalize(vmin=0.0, vmax=1.0),
    }
    recurrence_cmap = LinearSegmentedColormap.from_list("recurrence", [COLORS["grey"], COLORS["white"], COLORS["navy_dark"]])
    sequential_cmap = LinearSegmentedColormap.from_list("seq", [COLORS["white"], "#C7DEEA", COLORS["navy_dark"]])
    endpoint_cmap = LinearSegmentedColormap.from_list("endpoint", [COLORS["white"], "#D8CEE5", COLORS["purple"]])
    study_cmap = LinearSegmentedColormap.from_list("study", [COLORS["white"], "#F4CF9D", COLORS["orange_dark"]])

    def cell_fill(column: str, value: float) -> str:
        norm = norm_map[column]
        if column == "max_universality_index":
            rgba = recurrence_cmap(norm(value))
        elif column in {"max_abs_ridge_beta", "max_abs_highconf_essentiality_rho"}:
            rgba = endpoint_cmap(norm(value))
        elif column == "max_study_proxy_share":
            rgba = study_cmap(norm(value))
        else:
            rgba = sequential_cmap(norm(value))
        return mpl.colors.to_hex(rgba, keep_alpha=False)

    def format_value(column: str, value: float) -> str:
        if column == "max_universality_index":
            return f"{value:.2f}"
        if column in {"ora_neglog10q", "rank_neglog10q"}:
            return "NR" if column == "rank_neglog10q" and math.isclose(value, 0.0, abs_tol=1e-15) else f"{value:.1f}"
        if column == "max_study_proxy_share":
            return f"{value:.3f}"
        return f"{value:.3f}"

    for row_index, row in table.iterrows():
        row_y = body_top - (row_index + 1) * row_h
        base_fill = COLORS["white"] if row_index % 2 == 0 else COLORS["light"]
        # Number, label, and manual display tier.
        nonnumeric = [str(row_index + 1), AXIS_LABELS[str(row["axis_group"])], "H" if str(row["axis_use_tier"]) == "headline" else "S"]
        for col_index, value in enumerate(nonnumeric):
            cid = f"panel_b_row_{row_index}_cell_{col_index}"
            fig_rect(fig, registry, starts[col_index], row_y, widths[col_index], row_h, semantic_id=cid, panel=panel, facecolor=base_fill, edgecolor=COLORS["grid"], linewidth=0.3)
            if col_index == 1:
                fig_text(fig, registry, starts[col_index] + 3.0, row_y + row_h / 2, value, semantic_id=f"panel_b_label_{row_index}", panel=panel, size=6.2, weight="bold" if row["axis_use_tier"] == "headline" else "normal", va="center", container=cid, clearance_pt=1.8)
            else:
                tier_color = COLORS["navy"] if value == "H" else COLORS["teal"]
                fig_text(fig, registry, starts[col_index] + widths[col_index] / 2, row_y + row_h / 2, value, semantic_id=f"panel_b_nonnumeric_{row_index}_{col_index}", panel=panel, size=6.2, weight="bold", color=tier_color if col_index == 2 else COLORS["ink"], ha="center", va="center", container=cid, clearance_pt=1.5)
        for offset, column in enumerate(numeric_columns, start=3):
            value = float(row[column])
            fill = cell_fill(column, value)
            cid = f"panel_b_row_{row_index}_cell_{offset}"
            fig_rect(fig, registry, starts[offset], row_y, widths[offset], row_h, semantic_id=cid, panel=panel, facecolor=fill, edgecolor=COLORS["white"], linewidth=0.45)
            fig_text(fig, registry, starts[offset] + widths[offset] / 2, row_y + row_h / 2, format_value(column, value), semantic_id=f"panel_b_value_{row_index}_{offset}", panel=panel, size=6.15, weight="bold" if row["axis_use_tier"] == "headline" else "normal", color=readable_text_color(fill), ha="center", va="center", container=cid, clearance_pt=1.5)

    foot_y = body_top - len(table) * row_h - 3.0
    fig_text(fig, registry, table_x, foot_y, "*Manual tier: H, headline; S, supporting.  NR, no retained rank result—not zero.  Metrics are dependent; unlike units are not commensurate.", semantic_id="panel_b_footnote", panel=panel, size=6.0, color=COLORS["muted"], va="top")


def style_axis(ax: plt.Axes, *, grid_axis: str = "") -> None:
    ax.tick_params(axis="both", labelsize=6.3, width=0.55, length=2.3, pad=2.0, colors=COLORS["ink"])
    for spine in ax.spines.values():
        spine.set_linewidth(0.55)
        spine.set_color(COLORS["ink"])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if grid_axis:
        ax.grid(axis=grid_axis, color=COLORS["grid"], linewidth=0.5, zorder=0)
    ax.set_axisbelow(True)


def register_axis_text(registry: Registry, ax: plt.Axes, *, panel: str, prefix: str) -> None:
    objects = []
    if ax.xaxis.label.get_text():
        objects.append((f"{prefix}_xlabel", ax.xaxis.label))
    if ax.yaxis.label.get_text():
        objects.append((f"{prefix}_ylabel", ax.yaxis.label))
    for index, label in enumerate(ax.get_xticklabels()):
        if label.get_text():
            objects.append((f"{prefix}_xtick_{index}", label))
    for index, label in enumerate(ax.get_yticklabels()):
        if label.get_text():
            objects.append((f"{prefix}_ytick_{index}", label))
    for semantic_id, artist in objects:
        if semantic_id not in registry.artists:
            registry.add(semantic_id, artist, kind="text", panel=panel)


def draw_panel_c(fig: plt.Figure, registry: Registry, table: pd.DataFrame) -> None:
    panel = "c"
    x, y, w, h = PANEL_BOXES_PT[panel]
    add_panel_header(
        fig,
        registry,
        panel,
        "Raw-metric atlas",
        "No composite, area, or jitter.\n4/6 coincide; 2 overlaps only in β.\nβ and ρ reuse one endpoint.",
    )
    top_ax = add_axes_pt(fig, (x + 31.0, y + 65.0, w - 40.0, 36.0), gid="panel_c_beta_axis")
    bottom_ax = add_axes_pt(fig, (x + 31.0, y + 22.0, w - 40.0, 36.0), gid="panel_c_rho_axis")

    x_values = table["max_universality_index"].to_numpy(float)
    beta = table["max_abs_ridge_beta"].to_numpy(float)
    rho = table["max_abs_highconf_essentiality_rho"].to_numpy(float)
    tiers = table["axis_use_tier"].astype(str).tolist()
    numbers = list(range(1, len(table) + 1))

    # Exact duplicate F10 summaries are represented once, not moved apart.
    display_indices = [0, 1, 2, 3, 4, 6, 7, 8]
    duplicate_number = {3: "4/6"}
    beta_offsets = {
        0: (-2, 7), 1: (22, -2), 2: (6, 6), 3: (10, 10),
        4: (7, 10), 6: (-10, 14), 7: (9, 10), 8: (-13, 4),
    }
    rho_offsets = {
        0: (-2, 7), 1: (22, -2), 2: (-11, 9), 3: (10, 11),
        4: (6, -8), 6: (5, 17), 7: (11, 10), 8: (-11, 10),
    }

    for axis_name, ax, values, offsets, ylim in [
        ("beta", top_ax, beta, beta_offsets, (-0.02, 0.27)),
        ("rho", bottom_ax, rho, rho_offsets, (-0.02, 0.48)),
    ]:
        ax.axvline(0.0, color=COLORS["rule"], linestyle=(0, (2, 2)), linewidth=0.6, zorder=1)
        for index in display_indices:
            headline = tiers[index] == "headline"
            marker_shape = "D" if index == 1 else "o"
            marker_size = 4.6 if index == 1 else (8.5 if index == 3 else 5.8)
            marker = ax.plot(
                [x_values[index]],
                [values[index]],
                marker=marker_shape,
                markersize=marker_size,
                markerfacecolor=COLORS["navy"] if headline else COLORS["white"],
                markeredgecolor=COLORS["navy_dark"],
                markeredgewidth=0.9 if headline else 0.7,
                linestyle="none",
                # Keep the headline marker visible when it is almost
                # coincident with the supporting row 4/6 marker.
                zorder=6 if index == 1 else (5 if headline else 4),
            )[0]
            marker_id = f"panel_c_{axis_name}_marker_{numbers[index]}"
            registry.add(
                marker_id,
                marker,
                kind="marker",
                panel=panel,
                metadata={
                    "x": float(x_values[index]),
                    "y": float(values[index]),
                    "shape": marker_shape,
                    "marker_size_pt": marker_size,
                    "near_coincident_encoding": index in {1, 3},
                },
            )
            label = duplicate_number.get(index, str(numbers[index]))
            dx, dy = offsets[index]
            annotation = ax.annotate(
                label,
                (x_values[index], values[index]),
                xytext=(dx, dy),
                textcoords="offset points",
                fontsize=6.0,
                fontproperties=BOLD,
                color=COLORS["ink"],
                ha="center",
                va="center",
                arrowprops={"arrowstyle": "-", "color": COLORS["grey"], "linewidth": 0.45, "shrinkA": 2.0, "shrinkB": 2.0} if index == 1 else None,
                zorder=6,
            )
            related_markers = [marker_id]
            if index == 1 and axis_name == "beta":
                # The leader necessarily begins inside the almost coincident
                # open 4/6 symbol; this is the intended exact-coordinate key.
                related_markers.append("panel_c_beta_marker_4")
            registry.add(f"panel_c_{axis_name}_label_{label.replace('/', '_')}", annotation, kind="text", panel=panel, related=related_markers)
        ax.set_xlim(-4.8, 13.7)
        ax.set_ylim(*ylim)
        ax.set_xticks([-4, 0, 4, 8, 12])
        if axis_name == "beta":
            ax.set_xticklabels([])
            ax.set_yticks([0.0, 0.1, 0.2])
            ax.set_ylabel("max |β|", fontsize=6.5, labelpad=2.5)
        else:
            ax.set_yticks([0.0, 0.2, 0.4])
            ax.set_xlabel(r"run-relative recurrence score $R_f$", fontsize=6.4, labelpad=2.0)
            ax.set_ylabel("max |ρ|", fontsize=6.5, labelpad=2.5)
        style_axis(ax, grid_axis="both")
        register_axis_text(registry, ax, panel=panel, prefix=f"panel_c_{axis_name}")

def draw_panel_d(fig: plt.Figure, registry: Registry, robust: pd.DataFrame, fitness: pd.DataFrame) -> None:
    panel = "d"
    x, y, w, h = PANEL_BOXES_PT[panel]
    add_panel_header(fig, registry, panel, "Generalization boundaries", "Different estimands and resampling units;\ntracks are not quantitatively pooled.")

    residual_ax = add_axes_pt(fig, (x + 68.0, y + 21.0, 82.0, 68.0), gid="panel_d_residual_axis")
    fitness_ax = add_axes_pt(fig, (x + 178.0, y + 21.0, w - 186.0, 68.0), gid="panel_d_fitness_axis")

    primary = robust.query("scheme == 'context'").copy()
    order = ["Leave dataset out", "Exclude same-study proxy", "Leave context out"]
    primary["holdout"] = pd.Categorical(primary["holdout"], categories=order, ordered=True)
    primary = primary.sort_values("holdout").reset_index(drop=True)
    y_positions = np.arange(len(primary))[::-1]
    for index, row in primary.iterrows():
        mean = float(row["mean"])
        low = float(row["ci_low"])
        high = float(row["ci_high"])
        ypos = float(y_positions[index])
        line = residual_ax.plot([low, high], [ypos, ypos], color=COLORS["teal"], linewidth=1.1, solid_capstyle="round", zorder=2)[0]
        registry.add(f"panel_d_residual_interval_{index}", line, kind="interval", panel=panel, metadata={"low": low, "high": high})
        marker = residual_ax.plot([mean], [ypos], marker="D", markersize=4.2, color=COLORS["teal"], linestyle="none", zorder=3)[0]
        registry.add(f"panel_d_residual_mean_{index}", marker, kind="marker", panel=panel)
        annotation = residual_ax.annotate(f"{mean:.3f}", (mean, ypos), xytext=(0, 6), textcoords="offset points", ha="center", va="bottom", fontsize=6.0, fontproperties=BOLD, color=COLORS["ink"], zorder=5)
        registry.add(f"panel_d_residual_value_{index}", annotation, kind="text", panel=panel, related=[f"panel_d_residual_mean_{index}"])
    residual_ax.axvline(0.0, color=COLORS["grey"], linestyle=(0, (2, 2)), linewidth=0.6, zorder=1)
    residual_ax.set_xlim(-0.08, 0.84)
    residual_ax.set_ylim(-0.60, 3.00)
    residual_ax.set_xticks([0.0, 0.4, 0.8])
    residual_ax.set_yticks(y_positions)
    residual_ax.set_yticklabels(["Leave dataset\n(34)", "Exclude same-study\nproxy (22)", "Leave context\n(7)"])
    residual_ax.set_xlabel("mean cosine", fontsize=6.4, labelpad=2.0)
    residual_ax.set_title("Residual direction\n95% cluster CI; clusters (n)", fontsize=6.4, fontweight="bold", pad=2.5)
    style_axis(residual_ax, grid_axis="x")
    register_axis_text(registry, residual_ax, panel=panel, prefix="panel_d_residual")
    registry.add("panel_d_residual_title", residual_ax.title, kind="text", panel=panel)

    holdout_order = ["Gene", "Program family", "Dataset", "Context", "Study proxy"]
    rng = np.random.default_rng(1201)
    y_positions_fit = np.arange(len(holdout_order))[::-1]
    for index, holdout in enumerate(holdout_order):
        values = fitness.loc[fitness["holdout"] == holdout, "value"].to_numpy(float)
        ypos = float(y_positions_fit[index])
        jitter = np.linspace(-0.15, 0.15, len(values))
        # Deterministic order avoids implying random uncertainty.
        values = np.sort(values)
        for point_index, (value, point_jitter) in enumerate(zip(values, jitter, strict=True)):
            point = fitness_ax.plot(
                [value], [ypos + point_jitter], marker="o", markersize=2.3,
                markerfacecolor=COLORS["grey_light"], markeredgecolor=COLORS["grey"],
                markeredgewidth=0.45, linestyle="none", zorder=2,
            )[0]
            registry.add(
                f"panel_d_fitness_replicate_{index}_{point_index}", point,
                kind="marker", panel=panel, metadata={"value": float(value)},
            )
        mean = float(values.mean())
        marker = fitness_ax.plot([mean], [ypos], marker="D", markersize=4.2, color=COLORS["purple"], linestyle="none", zorder=3)[0]
        registry.add(f"panel_d_fitness_mean_{index}", marker, kind="marker", panel=panel, metadata={"mean": mean})
    fitness_ax.axvline(0.0, color=COLORS["grey"], linestyle=(0, (2, 2)), linewidth=0.6, zorder=1)
    fitness_ax.set_xlim(-0.60, 0.72)
    fitness_ax.set_ylim(-0.70, 5.30)
    fitness_ax.set_xticks([-0.5, 0.0, 0.5])
    fitness_ax.set_yticks(y_positions_fit)
    fitness_ax.set_yticklabels(["Gene (5)", "Program family (7)", "Dataset (5)", "Context (4)", "Study proxy (5)"])
    fitness_ax.set_xlabel("Spearman ρ", fontsize=6.4, labelpad=2.0)
    fitness_ax.set_title("Fitness association\nraw replicates + mean; n in ( )", fontsize=6.4, fontweight="bold", pad=2.5)
    style_axis(fitness_ax, grid_axis="x")
    register_axis_text(registry, fitness_ax, panel=panel, prefix="panel_d_fitness")
    registry.add("panel_d_fitness_title", fitness_ax.title, kind="text", panel=panel)


def draw_panel_e(fig: plt.Figure, registry: Registry, table: pd.DataFrame) -> None:
    panel = "e"
    x, y, w, h = PANEL_BOXES_PT[panel]
    add_panel_header(fig, registry, panel, "Scoped model and decisive falsifiers")
    left = x + 15.0
    card_y = y + 18.0
    card_h = 42.0
    gap = 14.0
    card_w = (w - 30.0 - 3 * gap) / 4.0
    card_styles = [
        ("#EDF5F9", COLORS["navy"]),
        ("#EAF6F3", COLORS["teal"]),
        ("#F1EDF6", COLORS["purple"]),
        (COLORS["orange_light"], COLORS["orange"]),
    ]
    titles = ["Residual\ncoordinates", "Study/context\nconditioning", "Shared-endpoint\nprediction", "Causal law"]
    bodies = [
        "Recur in related settings;\npreprocessing-dependent",
        "Transfer attenuates and\ncandidate labels concentrate",
        "Held-out genes predict;\ngrouped estimates unstable",
        "No prospective mechanism\nor intervention test",
    ]
    for index in range(4):
        card_x = left + index * (card_w + gap)
        fill, border = card_styles[index]
        cid = f"panel_e_card_{index}"
        fig_rect(fig, registry, card_x, card_y, card_w, card_h, semantic_id=cid, panel=panel, facecolor=fill, edgecolor=border, linewidth=0.85, rounded=True, zorder=2)
        fig_text(fig, registry, card_x + 5.0, card_y + card_h - 5.0, titles[index], semantic_id=f"panel_e_title_{index}", panel=panel, size=6.4, weight="bold", color=border if index != 3 else COLORS["orange_dark"], linespacing=0.98, container=cid, clearance_pt=3.0, zorder=3)
        fig_text(fig, registry, card_x + 5.0, card_y + 4.0, bodies[index], semantic_id=f"panel_e_body_{index}", panel=panel, size=6.0, color=COLORS["ink"], va="bottom", linespacing=1.0, container=cid, clearance_pt=3.0, zorder=3)
        if index < 2:
            arrow = FancyArrowPatch(
                ((card_x + card_w + 2.0) / WIDTH_PT, (card_y + card_h / 2) / HEIGHT_PT),
                ((card_x + card_w + gap - 2.0) / WIDTH_PT, (card_y + card_h / 2) / HEIGHT_PT),
                transform=fig.transFigure,
                arrowstyle="-|>",
                mutation_scale=7.0,
                linewidth=0.65,
                color=COLORS["grey"],
                zorder=3,
            )
            fig.add_artist(arrow)
            registry.add(f"panel_e_arrow_{index}", arrow, kind="arrow", panel=panel)
        elif index == 2:
            barrier_x = card_x + card_w + gap / 2
            barrier = Line2D(
                [barrier_x / WIDTH_PT, barrier_x / WIDTH_PT],
                [(card_y + 2.0) / HEIGHT_PT, (card_y + card_h - 2.0) / HEIGHT_PT],
                transform=fig.transFigure,
                color=COLORS["orange"],
                linewidth=1.4,
                zorder=3,
            )
            fig.add_artist(barrier)
            registry.add("panel_e_stop_barrier", barrier, kind="barrier", panel=panel)
            fig_text(fig, registry, barrier_x, card_y + card_h + 2.0, "STOP", semantic_id="panel_e_stop_label", panel=panel, size=6.0, weight="bold", color=COLORS["orange_dark"], ha="center", va="bottom", related=["panel_e_stop_barrier"], zorder=4)
    fig_text(
        fig,
        registry,
        left,
        y + 1.0,
        "Required for broader claims: fold-fitted preprocessing · verified study IDs · independent-study recurrence\ndeclared contrast basis · study-block uncertainty · prospective mechanism/intervention tests",
        semantic_id="panel_e_falsifiers",
        panel=panel,
        size=6.0,
        weight="bold",
        color=COLORS["orange_dark"],
        va="bottom",
    )


def build_figure(source_root: Path, *, svg_text_as_paths: bool) -> tuple[plt.Figure, Registry, dict[str, pd.DataFrame]]:
    configure_matplotlib(svg_text_as_paths=svg_text_as_paths)
    tables = validate_inputs(source_root)
    fig = plt.figure(figsize=(WIDTH_MM / 25.4, HEIGHT_MM / 25.4), dpi=100, facecolor=COLORS["paper"])
    registry = Registry(fig)
    draw_panel_a(fig, registry, tables["claim_scope"])
    draw_panel_b(fig, registry, tables["axis"])
    draw_panel_c(fig, registry, tables["axis"])
    draw_panel_d(fig, registry, tables["robustness"], tables["fitness"])
    draw_panel_e(fig, registry, tables["scope"])
    return fig, registry, tables


def write_png_with_profile(fig: plt.Figure, path: Path, profile_path: Path, *, dpi: int) -> None:
    render_temp = path.with_suffix(".rendering.png")
    profiled_temp = path.with_suffix(".profiled.png")
    fig.savefig(render_temp, dpi=dpi, bbox_inches=None, pad_inches=0, facecolor="white", pil_kwargs={"compress_level": 9})
    with Image.open(render_temp) as image:
        image.load()
        rgb = image.convert("RGB")
        try:
            rgb.save(profiled_temp, format="PNG", compress_level=9, optimize=False, icc_profile=profile_path.read_bytes(), dpi=(dpi, dpi))
        finally:
            rgb.close()
    with Image.open(profiled_temp) as verification:
        verification.verify()
    profiled_temp.replace(path)
    render_temp.unlink()


def write_downscale(source: Path, destination: Path, size: tuple[int, int], profile_path: Path) -> None:
    with Image.open(source) as image:
        resized = image.convert("RGB").resize(size, Image.Resampling.LANCZOS)
        resized.save(destination, format="PNG", compress_level=9, optimize=False, icc_profile=profile_path.read_bytes())


def write_responsive_crop(
    source: Path,
    destination: Path,
    crop_box_pt: tuple[float, float, float, float],
    output_width: int,
    profile_path: Path,
) -> tuple[int, int]:
    """Crop a panel group from the canonical raster and rescale deterministically."""
    x, y, width, height = crop_box_pt
    with Image.open(source) as image:
        rgb = image.convert("RGB")
        scale_x = rgb.width / WIDTH_PT
        scale_y = rgb.height / HEIGHT_PT
        left = max(0, math.floor(x * scale_x))
        right = min(rgb.width, math.ceil((x + width) * scale_x))
        top = max(0, math.floor((HEIGHT_PT - (y + height)) * scale_y))
        bottom = min(rgb.height, math.ceil((HEIGHT_PT - y) * scale_y))
        cropped = rgb.crop((left, top, right, bottom))
        output_height = round(output_width * cropped.height / cropped.width)
        resized = cropped.resize((output_width, output_height), Image.Resampling.LANCZOS)
        resized.save(
            destination,
            format="PNG",
            compress_level=9,
            optimize=False,
            icc_profile=profile_path.read_bytes(),
        )
    return output_width, output_height


def add_svg_accessibility(path: Path, title: str, description: str) -> None:
    """Add explicit SVG title/description without touching plotted geometry."""
    value = path.read_text(encoding="utf-8")
    start = value.find("<svg")
    if start < 0:
        raise RuntimeError(f"SVG root missing: {path}")
    end = value.find(">", start)
    if end < 0:
        raise RuntimeError(f"SVG root is malformed: {path}")
    root = value[start : end + 1]
    if "aria-labelledby=" not in root:
        root = root[:-1] + ' role="img" aria-labelledby="cgt-fig4-title cgt-fig4-desc">'
    injection = (
        f'\n <title id="cgt-fig4-title">{html.escape(title)}</title>'
        f'\n <desc id="cgt-fig4-desc">{html.escape(description)}</desc>'
    )
    value = value[:start] + root + injection + value[end + 1 :]
    path.write_text(value, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--qa-dir", type=Path, required=True)
    args = parser.parse_args()
    source_root = args.source_root.resolve()
    output_dir = args.output_dir.resolve()
    qa_dir = args.qa_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    qa_dir.mkdir(parents=True, exist_ok=True)
    profile = source_root / "assets" / "sRGB.icc"
    validate_fonts_and_profile(profile)

    base = "CGT_FIGURE_004_dependency_aware_synthesis_revised"
    fig, registry, tables = build_figure(source_root, svg_text_as_paths=True)
    layout_path = qa_dir / "CGT_FIGURE_004_layout_registry.json"
    registry.finalize(layout_path)

    metadata = {
        "Title": "CGT Figure 4 | Dependency-aware synthesis and generalization boundaries",
        "Author": "John Patrick Collins",
        "Subject": "Audited synthesis of CGT Figures 1-3",
        "Keywords": "CGT; residual coordinates; generalization; evidence synthesis",
        "Creator": "Deterministic CGT Figure 4 renderer",
        "CreationDate": FIXED_DATE,
        "ModDate": FIXED_DATE,
    }
    pdf_path = output_dir / f"{base}.pdf"
    svg_path = output_dir / f"{base}.svg"
    pub_png = output_dir / f"{base}_600dpi.png"
    web_png = output_dir / f"{base}_web.png"
    editable_svg = qa_dir / f"{base}_editable_text_QA.svg"

    fig.savefig(pdf_path, format="pdf", dpi=PUB_DPI, bbox_inches=None, pad_inches=0, metadata=metadata)
    fig.savefig(svg_path, format="svg", dpi=PUB_DPI, bbox_inches=None, pad_inches=0, metadata={"Date": "2026-08-23", "Creator": metadata["Creator"], "Title": metadata["Title"], "Description": metadata["Subject"]})
    svg_accessible_title = "Figure 4: Dependency-aware synthesis of current CGT analyses and their generalization boundaries"
    svg_accessible_description = (
        "Five-panel synthesis of claim scope, nine study-conditioned candidate annotations, raw recurrence-versus-endpoint summaries, "
        "residual-transfer and grouped-fitness generalization boundaries, and a stop barrier before any causal-law claim."
    )
    add_svg_accessibility(svg_path, svg_accessible_title, svg_accessible_description)
    write_png_with_profile(fig, pub_png, profile, dpi=PUB_DPI)
    write_downscale(pub_png, web_png, WEB_SIZE, profile)
    plt.close(fig)

    # Editable-text SVG exists for text inspection only; the release SVG uses
    # font-independent paths to prevent browser substitution.
    fig_text_svg, _, _ = build_figure(source_root, svg_text_as_paths=False)
    fig_text_svg.savefig(editable_svg, format="svg", dpi=PUB_DPI, bbox_inches=None, pad_inches=0, metadata={"Date": "2026-08-23", "Creator": metadata["Creator"], "Title": metadata["Title"], "Description": metadata["Subject"]})
    plt.close(fig_text_svg)
    add_svg_accessibility(editable_svg, svg_accessible_title, svg_accessible_description)

    responsive_outputs: dict[str, dict[str, Any]] = {}
    for panel, (crop_x, crop_y, crop_w, crop_h, output_width) in RESPONSIVE_CROPS_PT.items():
        path = output_dir / f"{base}_mobile_panel_{panel}.png"
        size = write_responsive_crop(
            pub_png,
            path,
            (crop_x, crop_y, crop_w, crop_h),
            int(output_width),
            profile,
        )
        responsive_outputs[panel] = {
            "filename": path.name,
            "size_px": list(size),
            "sha256": sha256(path),
        }

    for width in [1600, 1200, 800, 480]:
        height = round(width * HEIGHT_MM / WIDTH_MM)
        write_downscale(pub_png, qa_dir / f"CGT_FIGURE_004_downscale_{width}px.png", (width, height), profile)

    tracked_source_files = [
        source_root / "assets" / "sRGB.icc",
        source_root / "data" / "panel_a_claim_scope.csv",
        source_root / "data" / "panel_d_fitness_replicates.csv",
        source_root / "data" / "panel_e_scope.csv",
        source_root / "upstream" / "CGT_FIGURE_002_Fig2f_robustness_revised.csv",
        source_root / "upstream" / "CGT_FIGURE_003_axis_evidence_revised.csv",
    ]
    source_hashes = {
        path.relative_to(source_root).as_posix(): sha256(path)
        for path in tracked_source_files
    }
    metadata_payload = {
        "schema_version": "1.0",
        "figure_id": "CGT_FIGURE_004",
        "render_date_utc": "2026-08-23T00:00:00Z",
        "canvas_mm": [WIDTH_MM, HEIGHT_MM],
        "publication_dpi": PUB_DPI,
        "publication_size_px": list(PUB_SIZE),
        "web_size_px": list(WEB_SIZE),
        "source_hashes": source_hashes,
        "renderer": {
            "filename": Path(__file__).name,
            "sha256": sha256(Path(__file__).resolve()),
        },
        "software_versions": {
            "python": platform.python_version(),
            "matplotlib": mpl.__version__,
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "pillow": Image.__version__,
        },
        "output_hashes": {
            path.name: sha256(path)
            for path in [pdf_path, svg_path, pub_png, web_png, editable_svg, layout_path]
        },
        "responsive_panel_outputs": responsive_outputs,
        "data_counts": {
            "claim_scope_rows": int(len(tables["claim_scope"])),
            "candidate_rows": int(len(tables["axis"])),
            "residual_boundary_rows": 3,
            "fitness_replicates": int(len(tables["fitness"])),
        },
    }
    (qa_dir / "CGT_FIGURE_004_render_metadata.json").write_text(json.dumps(metadata_payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
