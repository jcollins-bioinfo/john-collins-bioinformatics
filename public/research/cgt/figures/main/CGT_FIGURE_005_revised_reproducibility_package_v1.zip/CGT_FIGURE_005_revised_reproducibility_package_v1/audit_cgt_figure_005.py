#!/usr/bin/env python3
"""Strict scientific, geometric, format, and accessibility audit for Figure 5."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from PIL import Image
from pypdf import PdfReader


WIDTH_MM = 183.0
HEIGHT_MM = 238.0
WIDTH_PT = WIDTH_MM * 72.0 / 25.4
HEIGHT_PT = HEIGHT_MM * 72.0 / 25.4
PUB_DPI = 600
PUB_SIZE = (int(WIDTH_MM / 25.4 * PUB_DPI), int(HEIGHT_MM / 25.4 * PUB_DPI))
WEB_SIZE = (2400, round(2400 * HEIGHT_MM / WIDTH_MM))
BASE = "CGT_FIGURE_005_tcga_cancer_type_structure_revised"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_parquet_portably(path: Path) -> pd.DataFrame:
    try:
        return pd.read_parquet(path)
    except ImportError:
        try:
            import duckdb  # type: ignore
        except ImportError as exc:
            raise RuntimeError("Parquet audit requires pyarrow, fastparquet, or duckdb") from exc
        escaped = str(path.resolve()).replace("'", "''")
        return duckdb.sql(f"SELECT * FROM read_parquet('{escaped}')").df()


def check(condition: bool, label: str, failures: list[str]) -> None:
    if not condition:
        failures.append(label)


def bbox_intersection(left: list[float], right: list[float]) -> tuple[float, float, float]:
    width = max(0.0, min(left[2], right[2]) - max(left[0], right[0]))
    height = max(0.0, min(left[3], right[3]) - max(left[1], right[1]))
    return width, height, width * height


def geometry_audit(layout_path: Path, failures: list[str]) -> dict[str, Any]:
    layout = json.loads(layout_path.read_text(encoding="utf-8"))
    canvas = layout["canvas"]
    check(math.isclose(canvas["width_mm"], WIDTH_MM, abs_tol=1e-9), "layout width is not 183 mm", failures)
    check(math.isclose(canvas["height_mm"], HEIGHT_MM, abs_tol=1e-9), "layout height is not 238 mm", failures)
    check(layout["minimum_font_size_pt"] >= 6.0 - 1e-9, "font smaller than 6 pt", failures)
    entries = [entry for entry in layout["entries"] if entry.get("bbox_pt")]
    boundary_violations: list[str] = []
    for entry in entries:
        x0, y0, x1, y1 = entry["bbox_pt"]
        if x0 < -0.2 or y0 < -0.2 or x1 > WIDTH_PT + 0.2 or y1 > HEIGHT_PT + 0.2:
            boundary_violations.append(entry["semantic_id"])
    check(not boundary_violations, f"out-of-canvas elements: {boundary_violations}", failures)

    texts = [entry for entry in entries if entry["kind"] == "text" and entry.get("text", "").strip()]
    overlaps: list[dict[str, Any]] = []
    for index, left in enumerate(texts):
        for right in texts[index + 1 :]:
            width, height, area = bbox_intersection(left["bbox_pt"], right["bbox_pt"])
            if width > 0.12 and height > 0.12 and area > 0.20:
                overlaps.append(
                    {
                        "left": left["semantic_id"],
                        "left_text": left.get("text"),
                        "right": right["semantic_id"],
                        "right_text": right.get("text"),
                        "area_pt2": area,
                    }
                )
    check(not overlaps, f"text overlaps: {overlaps[:12]}", failures)

    by_id = {entry["semantic_id"]: entry for entry in entries}
    clearance_failures: list[dict[str, Any]] = []
    for entry in texts:
        container_id = entry.get("container")
        required = entry.get("required_clearance_pt")
        if not container_id or required is None or container_id not in by_id:
            continue
        text_box = entry["bbox_pt"]
        container_box = by_id[container_id]["bbox_pt"]
        clearances = [
            text_box[0] - container_box[0],
            container_box[2] - text_box[2],
            text_box[1] - container_box[1],
            container_box[3] - text_box[3],
        ]
        if min(clearances) < float(required) - 0.12:
            clearance_failures.append({"text": entry["semantic_id"], "container": container_id, "minimum": min(clearances), "required": required})
    check(not clearance_failures, f"container-clearance failures: {clearance_failures}", failures)

    # Centroid labels must remain wholly outside the tumor viewport and be
    # monotonically packed with no label-label overlap on either side.
    plot = [18.0 + 91.0, 400.0 + 10.0, 18.0 + (WIDTH_PT - 36.0) - 91.0, 400.0 + 120.0]
    centroid_labels = [entry for entry in texts if entry["semantic_id"].startswith("panel_c_") and "_label_" in entry["semantic_id"]]
    centroid_intrusions = []
    for entry in centroid_labels:
        _, _, area = bbox_intersection(entry["bbox_pt"], plot)
        if area > 0:
            centroid_intrusions.append(entry["semantic_id"])
    check(len(centroid_labels) == 33, f"expected 33 centroid labels, found {len(centroid_labels)}", failures)
    check(not centroid_intrusions, f"centroid labels intrude into tumor viewport: {centroid_intrusions}", failures)
    for side in ["left", "right"]:
        side_labels = sorted(
            [entry for entry in centroid_labels if f"panel_c_{side}_" in entry["semantic_id"]],
            key=lambda entry: entry["bbox_pt"][1],
        )
        for left, right in zip(side_labels, side_labels[1:]):
            gap = right["bbox_pt"][1] - left["bbox_pt"][3]
            check(gap >= -0.12, f"{side} centroid-label vertical collision ({gap:.3f} pt)", failures)

    return {
        "minimum_font_size_pt": layout["minimum_font_size_pt"],
        "boundary_violation_count": len(boundary_violations),
        "text_overlap_count": len(overlaps),
        "container_clearance_failure_count": len(clearance_failures),
        "centroid_label_count": len(centroid_labels),
        "centroid_viewport_intrusion_count": len(centroid_intrusions),
    }


def scientific_audit(source_root: Path, failures: list[str]) -> dict[str, Any]:
    data = source_root / "data"
    provenance = source_root / "provenance"
    labels = pd.read_csv(data / "Fig5_axis_labels.csv")
    axis_ids = labels["axis_id"].astype(str).tolist()
    check(len(axis_ids) == 15 and len(set(axis_ids)) == 15, "axis registry is not 15 unique scores", failures)
    displayed = labels["displayed"].astype(str).str.lower().eq("true")
    check(int(displayed.sum()) == 12, "named display universe is not 12 scores", failures)

    raw = read_parquet_portably(data / "upstream_raw_axis_matrix_qc.parquet")
    loo = read_parquet_portably(data / "Fig5_loo_global_residual_axis_matrix.parquet")
    metadata = pd.read_csv(data / "upstream_sample_metadata_corrected.csv")
    retained = metadata.loc[metadata["passes_expression_qc"].astype(str).str.lower().eq("true")].copy()
    check(len(metadata) == 9359 and len(retained) == 9302, "QC denominators are not 9,359 -> 9,302", failures)
    check(int((~metadata["passes_expression_qc"].astype(str).str.lower().eq("true")).sum()) == 57, "excluded count is not 57", failures)
    expected_pass = metadata["sample_median_axis_gene_expression"].astype(float) >= 2.5
    observed_pass = metadata["passes_expression_qc"].astype(str).str.lower().eq("true")
    check(bool((expected_pass == observed_pass).all()), "QC flag is not exactly median expression >= 2.5", failures)
    check(raw.shape == (9302, 16) and loo.shape == (9302, 16), "raw/LOO matrices are not 9,302 x (15 + ID)", failures)
    check(raw["sample_id"].is_unique and loo["sample_id"].is_unique, "sample IDs are not unique", failures)
    check(raw["sample_id"].tolist() == loo["sample_id"].tolist(), "raw/LOO sample order differs", failures)
    retained_by_id = retained.set_index("sample_id").loc[raw["sample_id"]]
    check(retained_by_id["corrected_cancer_type"].nunique() == 33, "retained cancer-type count is not 33", failures)

    raw_values = raw[axis_ids].to_numpy(float)
    loo_values = loo[axis_ids].to_numpy(float)
    median_expression = retained_by_id["sample_median_axis_gene_expression"].to_numpy(float)
    z_median = (median_expression - median_expression.mean()) / median_expression.std(ddof=0)
    reconstructed = np.empty_like(raw_values)
    coefficients = []
    model_r2 = []
    for column in range(len(axis_ids)):
        other_mean = np.delete(raw_values, column, axis=1).mean(axis=1)
        z_other = (other_mean - other_mean.mean()) / other_mean.std(ddof=0)
        design = np.column_stack([np.ones(len(raw_values)), z_other, z_median])
        beta, *_ = np.linalg.lstsq(design, raw_values[:, column], rcond=None)
        fitted = design @ beta
        residual = raw_values[:, column] - fitted
        reconstructed[:, column] = residual
        coefficients.append(beta)
        total = np.square(raw_values[:, column] - raw_values[:, column].mean()).sum()
        model_r2.append(1.0 - np.square(residual).sum() / total)
    maximum_residual_delta = float(np.max(np.abs(reconstructed - loo_values)))
    check(maximum_residual_delta < 1e-12, f"LOO-axis residual reconstruction delta {maximum_residual_delta}", failures)
    qc = pd.read_csv(data / "Fig5_loo_residual_model_qc.csv").set_index("axis_id").loc[axis_ids]
    coefficients_array = np.asarray(coefficients)
    maximum_coefficient_delta = float(
        max(
            np.max(np.abs(coefficients_array[:, 1] - qc["coef_leave_one_axis_global_mean"].to_numpy(float))),
            np.max(np.abs(coefficients_array[:, 2] - qc["coef_sample_median_expression"].to_numpy(float))),
        )
    )
    maximum_model_r2_delta = float(np.max(np.abs(np.asarray(model_r2) - qc["loo_global_component_r2"].to_numpy(float))))
    check(maximum_coefficient_delta < 1e-12, f"residual coefficient delta {maximum_coefficient_delta}", failures)
    check(maximum_model_r2_delta < 1e-12, f"residual model R2 delta {maximum_model_r2_delta}", failures)

    # Exact all-score correlation summaries.
    raw_corr = pd.DataFrame(raw_values).corr(method="spearman").to_numpy()
    centered_values = raw_values - raw_values.mean(axis=1, keepdims=True)
    centered_corr = pd.DataFrame(centered_values).corr(method="spearman").to_numpy()
    loo_corr = pd.DataFrame(loo_values).corr(method="spearman").to_numpy()
    mask = ~np.eye(15, dtype=bool)
    correlations = {
        "raw": float(np.abs(raw_corr[mask]).mean()),
        "centered": float(np.abs(centered_corr[mask]).mean()),
        "loo_global_residual": float(np.abs(loo_corr[mask]).mean()),
    }
    expected_correlations = {"raw": 0.7534773693712723, "centered": 0.2794281841664304, "loo_global_residual": 0.26541949924810754}
    for key, expected in expected_correlations.items():
        check(math.isclose(correlations[key], expected, abs_tol=1e-12), f"{key} mean |rho| changed", failures)
    frozen_corr = pd.read_csv(data / "Fig5f_all15_residual_axis_correlation.csv").set_index("axis_id").loc[axis_ids, axis_ids].to_numpy(float)
    check(float(np.max(np.abs(frozen_corr - loo_corr))) < 1e-12, "all-15 frozen correlation matrix changed", failures)

    # Recompute correlation-matrix PCA ratios without relying on sklearn.
    pca_ratios: dict[str, float] = {}
    for name, matrix in [("raw", raw_values), ("centered", centered_values), ("loo", loo_values)]:
        standardized = (matrix - matrix.mean(axis=0)) / matrix.std(axis=0, ddof=0)
        covariance = np.cov(standardized, rowvar=False, ddof=1)
        eigenvalues = np.linalg.eigvalsh(covariance)[::-1]
        pca_ratios[name] = float(eigenvalues[0] / eigenvalues.sum())
    expected_pca = {"raw": 0.8303963669221571, "centered": 0.33153269137209834, "loo": 0.3222381186685812}
    for key, expected in expected_pca.items():
        check(math.isclose(pca_ratios[key], expected, abs_tol=1e-12), f"{key} standardized PCA PC1 changed", failures)

    # Centroids and sample-weighted in-sample eta-squared.
    scores = pd.read_csv(data / "Fig5_pca_scores.csv")
    centroids = pd.read_csv(data / "Fig5c_all33_centroids.csv").set_index("cancer_type_short").sort_index()
    reconstructed_centroids = scores.groupby("cancer_type_short").agg(loo_PC1_mean=("loo_PC1", "mean"), loo_PC2_mean=("loo_PC2", "mean"), n_samples=("sample_id", "size")).sort_index()
    centroid_delta = float(np.max(np.abs(centroids[["loo_PC1_mean", "loo_PC2_mean"]].to_numpy() - reconstructed_centroids[["loo_PC1_mean", "loo_PC2_mean"]].to_numpy())))
    check(centroid_delta < 1e-12 and int(reconstructed_centroids["n_samples"].sum()) == 9302, "all-33 centroids changed", failures)
    eta = pd.read_csv(data / "Fig5e_lineage_r2.csv").set_index("axis_id").loc[axis_ids]
    group = retained_by_id["corrected_cancer_type"].astype(str).to_numpy()

    def eta_squared(values: np.ndarray) -> float:
        overall = float(values.mean())
        between = 0.0
        for category in np.unique(group):
            subset = values[group == category]
            between += len(subset) * float(subset.mean() - overall) ** 2
        total = float(np.square(values - overall).sum())
        return between / total

    raw_eta = np.array([eta_squared(raw_values[:, i]) for i in range(15)])
    loo_eta = np.array([eta_squared(loo_values[:, i]) for i in range(15)])
    eta_delta = float(max(np.max(np.abs(raw_eta - eta["raw"].to_numpy(float))), np.max(np.abs(loo_eta - eta["loo_global_residual"].to_numpy(float)))))
    check(eta_delta < 1e-12, f"eta-squared reconstruction delta {eta_delta}", failures)

    heatmap = pd.read_csv(data / "Fig5d_heatmap_matrix.csv")
    heat_values = heatmap.drop(columns="cancer_type_short").to_numpy(float)
    heat_max = float(np.max(np.abs(heat_values)))
    check(heat_max <= 3.1, f"heatmap saturation at {heat_max}", failures)
    check(np.allclose(heat_values.mean(axis=1), 0.0, atol=1e-12), "heatmap row means are not zero", failures)
    check(np.allclose(heat_values.std(axis=1, ddof=1), 1.0, atol=1e-12), "heatmap rows do not use sample SD", failures)

    # Recover the reported 970-gene union and quantify score-set reuse.
    recovery = pd.read_csv(provenance / "upstream_axis_gene_recovery.csv")
    memberships = [gene for value in recovery["found_genes"] for gene in str(value).split(",") if gene]
    counts = pd.Series(memberships).value_counts()
    recovered_unique = int(counts.size)
    reused_unique = int((counts >= 2).sum())
    check(recovered_unique == 970, f"recovered unique-gene count is {recovered_unique}, not 970", failures)
    check(reused_unique == 595, f"reused-gene count is {reused_unique}, not 595", failures)

    return {
        "samples_input": int(len(metadata)),
        "samples_retained": int(len(retained)),
        "samples_excluded": int(len(metadata) - len(retained)),
        "cancer_types": int(retained_by_id["corrected_cancer_type"].nunique()),
        "score_sets": len(axis_ids),
        "named_display_score_sets": int(displayed.sum()),
        "unique_recovered_genes": recovered_unique,
        "genes_reused_in_two_or_more_score_sets": reused_unique,
        "fraction_reused": reused_unique / recovered_unique,
        "maximum_residual_reconstruction_delta": maximum_residual_delta,
        "maximum_residual_coefficient_delta": maximum_coefficient_delta,
        "maximum_residual_model_r2_delta": maximum_model_r2_delta,
        "residual_model_r2_range": [float(np.min(model_r2)), float(np.max(model_r2))],
        "mean_abs_offdiag_spearman": correlations,
        "standardized_pca_pc1_share": pca_ratios,
        "loo_pca_pc2_share": 0.1425076343751052,
        "maximum_centroid_delta": centroid_delta,
        "maximum_eta_squared_delta": eta_delta,
        "heatmap_max_abs_row_z": heat_max,
        "all15_max_abs_residual_spearman": float(np.max(np.abs(loo_corr[mask]))),
    }


def format_audit(output_dir: Path, qa_dir: Path, failures: list[str]) -> dict[str, Any]:
    pdf = output_dir / f"{BASE}.pdf"
    svg = output_dir / f"{BASE}.svg"
    png = output_dir / f"{BASE}_600dpi.png"
    web = output_dir / f"{BASE}_web.png"
    for path in [pdf, svg, png, web]:
        check(path.is_file() and path.stat().st_size > 0, f"missing output: {path.name}", failures)
    png_report: dict[str, Any] = {}
    for path, expected in [(png, PUB_SIZE), (web, WEB_SIZE)]:
        with Image.open(path) as image:
            image.load()
            check(image.size == expected, f"{path.name} size {image.size} != {expected}", failures)
            check(image.mode == "RGB", f"{path.name} is not RGB", failures)
            check(bool(image.info.get("icc_profile")), f"{path.name} lacks ICC profile", failures)
            png_report[path.name] = {"size_px": list(image.size), "mode": image.mode, "has_icc_profile": bool(image.info.get("icc_profile")), "sha256": sha256(path)}

    reader = PdfReader(str(pdf))
    check(len(reader.pages) == 1, "PDF is not one page", failures)
    page = reader.pages[0]
    width_pt = float(page.mediabox.width)
    height_pt = float(page.mediabox.height)
    check(abs(width_pt - WIDTH_PT) < 0.05 and abs(height_pt - HEIGHT_PT) < 0.05, f"PDF media box {width_pt} x {height_pt} pt", failures)
    fonts = subprocess.run(["pdffonts", str(pdf)], capture_output=True, text=True, check=True).stdout
    check("Type 3" not in fonts and "type 3" not in fonts.lower(), "PDF contains Type 3 fonts", failures)

    svg_text = svg.read_text(encoding="utf-8")
    root = ET.fromstring(svg_text)
    width_attr = root.attrib.get("width", "")
    height_attr = root.attrib.get("height", "")
    check(width_attr.endswith("pt") and height_attr.endswith("pt"), "SVG does not declare point dimensions", failures)
    if width_attr.endswith("pt") and height_attr.endswith("pt"):
        check(abs(float(width_attr[:-2]) - WIDTH_PT) < 0.05, f"SVG width {width_attr}", failures)
        check(abs(float(height_attr[:-2]) - HEIGHT_PT) < 0.05, f"SVG height {height_attr}", failures)
    check('role="img"' in svg_text and "cgt-fig5-title" in svg_text and "cgt-fig5-desc" in svg_text, "SVG accessibility title/description missing", failures)
    embedded_images = len(re.findall(r"<image\b", svg_text))
    check(embedded_images == 1, f"SVG should contain exactly one rasterized tumor cloud, found {embedded_images}", failures)

    # Render PDF and SVG independently and compare both to the canonical PNG.
    pdf_render_base = qa_dir / "CGT_FIGURE_005_pdf_render_1200"
    subprocess.run(["pdftoppm", "-png", "-singlefile", "-scale-to-x", "1200", "-scale-to-y", "-1", str(pdf), str(pdf_render_base)], check=True, capture_output=True)
    pdf_render = pdf_render_base.with_suffix(".png")
    svg_render = qa_dir / "CGT_FIGURE_005_svg_render_1200.png"
    subprocess.run(["inkscape", str(svg), "--export-type=png", f"--export-filename={svg_render}", "--export-width=1200", "--export-background=white"], check=True, capture_output=True)
    with Image.open(png) as image:
        reference = np.asarray(image.convert("RGB").resize((1200, round(1200 * HEIGHT_MM / WIDTH_MM)), Image.Resampling.LANCZOS), dtype=np.float32) / 255.0
    differences: dict[str, float] = {}
    for label, path in [("pdf", pdf_render), ("svg", svg_render)]:
        with Image.open(path) as image:
            candidate = np.asarray(image.convert("RGB").resize((reference.shape[1], reference.shape[0]), Image.Resampling.LANCZOS), dtype=np.float32) / 255.0
        mae = float(np.mean(np.abs(reference - candidate)))
        differences[label] = mae
        # Independent renderers differ slightly in antialiasing and in
        # compositing the deliberately rasterized, alpha-blended tumor cloud.
        # A 2.5% mean-channel tolerance remains stringent at 1,200 px while
        # avoiding a false failure from those renderer-specific edge pixels.
        check(mae < 0.025, f"{label}/PNG cross-format MAE is {mae}", failures)

    responsive: dict[str, Any] = {}
    for panel in "abcdef":
        path = output_dir / f"{BASE}_mobile_panel_{panel}.png"
        check(path.is_file() and path.stat().st_size > 0, f"missing responsive panel {panel}", failures)
        if path.is_file():
            with Image.open(path) as image:
                check(image.mode == "RGB" and bool(image.info.get("icc_profile")), f"responsive panel {panel} lacks RGB/ICC", failures)
                responsive[panel] = {"filename": path.name, "size_px": list(image.size), "sha256": sha256(path)}
    return {
        "publication_png": png_report,
        "pdf_page_pt": [width_pt, height_pt],
        "pdf_fonts": fonts.splitlines()[2:],
        "svg_dimensions": [width_attr, height_attr],
        "svg_embedded_image_count": embedded_images,
        "cross_format_mean_absolute_error": differences,
        "responsive_panels": responsive,
    }


def color_accessibility_audit(output_dir: Path, qa_dir: Path, failures: list[str]) -> dict[str, Any]:
    web = output_dir / f"{BASE}_web.png"
    with Image.open(web) as image:
        rgb = np.asarray(image.convert("RGB"), dtype=np.float32) / 255.0
    matrices = {
        "protanopia": np.array([[0.567, 0.433, 0.000], [0.558, 0.442, 0.000], [0.000, 0.242, 0.758]]),
        "deuteranopia": np.array([[0.625, 0.375, 0.000], [0.700, 0.300, 0.000], [0.000, 0.300, 0.700]]),
        "tritanopia": np.array([[0.950, 0.050, 0.000], [0.000, 0.433, 0.567], [0.000, 0.475, 0.525]]),
    }
    outputs: dict[str, str] = {}
    for name, matrix in matrices.items():
        simulated = np.clip(rgb @ matrix.T, 0, 1)
        path = qa_dir / f"CGT_FIGURE_005_{name}.png"
        Image.fromarray(np.round(simulated * 255).astype(np.uint8), mode="RGB").save(path, format="PNG", compress_level=9)
        outputs[name] = path.name
    grey = np.dot(rgb, np.array([0.2126, 0.7152, 0.0722], dtype=np.float32))
    grey_rgb = np.repeat(grey[..., None], 3, axis=2)
    grey_path = qa_dir / "CGT_FIGURE_005_grayscale.png"
    Image.fromarray(np.round(grey_rgb * 255).astype(np.uint8), mode="RGB").save(grey_path, format="PNG", compress_level=9)
    outputs["grayscale"] = grey_path.name

    def srgb_luminance(hex_value: str) -> float:
        values = np.array(to_rgb_local(hex_value), dtype=float)
        linear = np.where(values <= 0.04045, values / 12.92, ((values + 0.055) / 1.055) ** 2.4)
        return float(0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2])

    def ratio(a: str, b: str) -> float:
        high, low = sorted([srgb_luminance(a), srgb_luminance(b)], reverse=True)
        return (high + 0.05) / (low + 0.05)

    text_contrast = ratio("#17212B", "#FFFFFF")
    muted_contrast = ratio("#596672", "#FFFFFF")
    check(text_contrast >= 7.0 and muted_contrast >= 4.5, "text contrast below WCAG AA", failures)
    return {"simulation_files": outputs, "ink_on_white_contrast": text_contrast, "muted_on_white_contrast": muted_contrast, "non_color_encodings": ["marker shape", "open-versus-filled marker", "direct labels", "numeric score indices"]}


def to_rgb_local(hex_value: str) -> tuple[float, float, float]:
    value = hex_value.lstrip("#")
    return tuple(int(value[index : index + 2], 16) / 255.0 for index in (0, 2, 4))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--qa-dir", type=Path, required=True)
    parser.add_argument("--audit-output", type=Path, required=True)
    args = parser.parse_args()
    source_root = args.source_root.resolve()
    output_dir = args.output_dir.resolve()
    qa_dir = args.qa_dir.resolve()
    qa_dir.mkdir(parents=True, exist_ok=True)
    failures: list[str] = []
    report: dict[str, Any] = {
        "schema_version": "1.0",
        "figure_id": "CGT_FIGURE_005",
        "status": "running",
        "scientific": scientific_audit(source_root, failures),
        "geometry": geometry_audit(qa_dir / "CGT_FIGURE_005_layout_registry.json", failures),
        "formats": format_audit(output_dir, qa_dir, failures),
        "accessibility": color_accessibility_audit(output_dir, qa_dir, failures),
        "provenance": {
            "archived_notebook_sha256": "51dee19a0791dfada00fc021649eb19b87789edab728b7afec5be576c25c84f5",
            "later_drive_inventory_sha256": "72d1efabe3dd8c0447817dedae3d6004b47374065eb90f83f9179ad8d525fb81",
            "status": "disclosed_unreconciled_notebook_version_mismatch",
            "scope": "The revised figure is reproducible from frozen score matrices; the raw score-construction formula is not documented in the package.",
        },
    }
    report["failures"] = failures
    report["status"] = "pass" if not failures else "fail"
    audit_target = args.audit_output.resolve()
    report["output_hashes"] = {
        path.name: sha256(path)
        for path in sorted(output_dir.glob("*"))
        if path.is_file() and path.resolve() != audit_target
    }
    args.audit_output.parent.mkdir(parents=True, exist_ok=True)
    args.audit_output.write_text(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("Figure 5 audit failed:\n- " + "\n- ".join(failures))
    print(json.dumps({"status": "pass", "audit": str(args.audit_output), "checks": {"scientific": True, "geometry": True, "formats": True, "accessibility": True}}, indent=2))


if __name__ == "__main__":
    main()
