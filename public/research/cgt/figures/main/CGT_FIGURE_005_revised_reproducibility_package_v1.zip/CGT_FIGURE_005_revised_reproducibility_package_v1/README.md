# CGT Figure 5 revised release

This package contains the publication-grade revision of CGT Figure 5, its frozen post-QC score inputs, deterministic renderer, strict audit, website copy, and provenance boundary.

## Scientific scope

The figure describes cancer-type-associated variation in one harmonized TCGA bulk-expression cohort across previously defined CGT-derived candidate score sets. PCA and all displayed summaries are fitted or calculated within TCGA. The figure does not establish orthogonal axes, deconfounding, independent validation, tumor-cell-intrinsic programs, transportability, mechanism, or causality.

## Reproducibility boundary

The revised figure is exactly reproducible from the packaged raw and pooled residual score matrices. The upstream formula that maps TCGA expression plus registry membership to the frozen raw scores is not documented in the source archive, so raw-score reconstruction from expression alone is not claimed. `source/PROVENANCE.md` also records the unresolved hash mismatch between the archived notebook and a later Drive inventory.

## Rebuild

From the package root:

```bash
python render_cgt_figure_005.py \
  --source-root source \
  --output-dir rebuilt/output \
  --qa-dir rebuilt/qa
```

Then audit:

```bash
python audit_cgt_figure_005.py \
  --source-root source \
  --output-dir rebuilt/output \
  --qa-dir rebuilt/qa \
  --audit-output rebuilt/output/CGT_FIGURE_005_tcga_cancer_type_structure_revised_audit.json
```

Reading the frozen Parquet matrices requires one of `pyarrow`, `fastparquet`, or `duckdb`. The recorded environment used Python 3.12 with pandas, NumPy, Matplotlib, Pillow, pypdf, DuckDB, Poppler, Inkscape, and DejaVu Sans.

## Canonical outputs

- 183 × 238 mm publication PDF
- font-independent SVG with accessible title and description
- sRGB-tagged 600-dpi PNG
- 2,400-pixel sRGB web PNG
- six panel-level responsive PNGs
- machine-readable audit JSON
- website caption, alt text, and accessible description

The website itself is not modified by this release task.

