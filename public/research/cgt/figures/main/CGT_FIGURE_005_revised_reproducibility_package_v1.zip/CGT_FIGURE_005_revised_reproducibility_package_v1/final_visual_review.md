# Final visual review — revised CGT Figure 5

Date: 23 August 2026 (UTC)

## Human inspection completed

- Canonical 600-dpi RGB PNG at exact 183 × 238 mm
- 2,400-pixel web PNG
- PDF rendered independently at 1,200 pixels
- SVG rendered independently at 1,200 pixels
- Full-composite downscales at 1,600, 1,200, 800, and 480 pixels
- Six panel-level responsive crops
- Grayscale, protanopia, deuteranopia, and tritanopia simulations

## Findings

- No text clipping, text–text collision, title collision, or legend collision is visible.
- All 33 centroid labels are legible in side gutters and do not cover tumor observations.
- Centroid leaders are monotone within each gutter and do not cross.
- Panel b uses discrete categorical positions, so near-equal transformed values cannot collide.
- Panel d uses the full available width; all 33 rows and 12 columns remain readable.
- Panel e vertically dodges raw and residual markers, preserving nearly equal pairs.
- Panel f removes the duplicated upper triangle and uninformative diagonal.
- Heatmap values are not clipped: the shared scale spans ±3.1 and the maximum absolute source value is below that limit.
- Minimum text size is 6 pt. No interpretation relies on hue alone.
- The only raster layer in SVG is the 9,302-point tumor cloud; heatmap cells and color scales are vector.

Status: publication-layout review passed.

