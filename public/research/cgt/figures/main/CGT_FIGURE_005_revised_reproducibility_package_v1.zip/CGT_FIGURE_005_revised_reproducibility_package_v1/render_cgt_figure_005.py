#!/usr/bin/env python3
"""Deterministic, publication-grade renderer for revised CGT Figure 5.

This renderer starts from frozen TCGA score matrices and frozen display tables.
It does not refit the upstream CGT score construction.  The figure is explicitly
descriptive: PCA, residualization, centroids, and between-cancer-type summaries
are all fitted or calculated within the same TCGA cohort.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import html
import json
import math
import os
import platform
from pathlib import Path
from typing import Any, Iterable

os.environ.setdefault("MPLCONFIGDIR", "/tmp/cgt_figure_005_mplconfig")
os.environ.setdefault("SOURCE_DATE_EPOCH", "1787443200")
os.environ.setdefault("TZ", "UTC")
os.environ.setdefault("LC_ALL", "C.UTF-8")

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm, to_rgb
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Rectangle
from PIL import Image


MM_TO_PT = 72.0 / 25.4
WIDTH_MM = 183.0
HEIGHT_MM = 238.0
WIDTH_PT = WIDTH_MM * MM_TO_PT
HEIGHT_PT = HEIGHT_MM * MM_TO_PT
PUB_DPI = 600
PUB_SIZE = (int(WIDTH_MM / 25.4 * PUB_DPI), int(HEIGHT_MM / 25.4 * PUB_DPI))
WEB_WIDTH_PX = 2400
WEB_SIZE = (WEB_WIDTH_PX, round(WEB_WIDTH_PX * HEIGHT_MM / WIDTH_MM))
FIXED_DATE = dt.datetime(2026, 8, 23, tzinfo=dt.timezone.utc)

FONT_REGULAR = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
FONT_BOLD = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
FONT_HASHES = {
    "regular": "ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280",
    "bold": "5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895",
}
REGULAR = FontProperties(fname=str(FONT_REGULAR))
BOLD = FontProperties(fname=str(FONT_BOLD))

COLORS = {
    "ink": "#17212B",
    "muted": "#596672",
    "rule": "#C8D0D6",
    "grid": "#E4E8EC",
    "light": "#F4F7F8",
    "paper": "#FFFFFF",
    "raw": "#5B6470",
    "centered": "#009E73",
    "loo": "#0072B2",
    "cloud": "#7C858D",
    "negative": "#3B6FB6",
    "neutral": "#F7F7F3",
    "positive": "#C4512A",
    "limited": "#8A6E51",
}

PANEL_BOXES_PT = {
    "a": (18.0, 563.0, 155.0, 91.0),
    "b": (184.0, 563.0, WIDTH_PT - 202.0, 91.0),
    "c": (18.0, 400.0, WIDTH_PT - 36.0, 150.0),
    "d": (18.0, 175.0, WIDTH_PT - 36.0, 210.0),
    "e": (18.0, 15.0, 230.0, 145.0),
    "f": (260.0, 15.0, WIDTH_PT - 278.0, 145.0),
}

RESPONSIVE_CROPS_PT = {
    "a": (13.0, 558.0, 165.0, 101.0, 1200),
    "b": (179.0, 558.0, WIDTH_PT - 192.0, 101.0, 1800),
    "c": (13.0, 395.0, WIDTH_PT - 26.0, 160.0, 1800),
    "d": (13.0, 170.0, WIDTH_PT - 26.0, 220.0, 2000),
    "e": (13.0, 10.0, 240.0, 155.0, 1400),
    "f": (255.0, 10.0, WIDTH_PT - 268.0, 155.0, 1400),
}

SHORT_LABELS = {
    "OXPHOS_respiration_F7": "OXPHOS",
    "SREBP_cholesterol_F5_F6": "SREBP / cholesterol",
    "T_cell_antigen_receptor_F1": "T-cell / AgR",
    "chromatin_cytokine_mixed_F10": "Chromatin / cytokine",
    "chromatin_epigenetic_F3_F15": "Chromatin / epigenetic",
    "chromatin_like_exploratory": "Chromatin-like†",
    "chromatin_methyltransferase_F8": "Chromatin MTase",
    "cytokine_JAK_STAT": "Cytokine / JAK–STAT",
    "lysosome_vacuole_ECM_F10": "Lysosome / ECM",
    "mitochondrial_translation_F16": "Mito. translation",
    "mixed_interferon_chromatin_F9": "IFN / chromatin",
    "rRNA_ribosome_biogenesis_F11": "rRNA biogenesis",
    "translation_ribosome_F12": "Translation / RQC",
    "unresolved": "Unresolved†",
    "unresolved_mixed": "Unresolved mix†",
}

HEATMAP_ABBR = {
    "OXPHOS_respiration_F7": "OXPHOS",
    "SREBP_cholesterol_F5_F6": "SREBP",
    "T_cell_antigen_receptor_F1": "T-cell",
    "chromatin_cytokine_mixed_F10": "Chr./cyt.",
    "chromatin_epigenetic_F3_F15": "Chromatin",
    "chromatin_methyltransferase_F8": "Chr.-MT",
    "cytokine_JAK_STAT": "JAK–STAT",
    "lysosome_vacuole_ECM_F10": "Lys./ECM",
    "mitochondrial_translation_F16": "Mito-trans.",
    "mixed_interferon_chromatin_F9": "IFN/chr.",
    "rRNA_ribosome_biogenesis_F11": "rRNA",
    "translation_ribosome_F12": "Translation",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def configure_matplotlib(*, svg_text_as_paths: bool) -> None:
    mpl.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.sans-serif": ["DejaVu Sans"],
            "font.size": 7.0,
            "axes.labelsize": 7.0,
            "axes.titlesize": 8.0,
            "xtick.labelsize": 6.0,
            "ytick.labelsize": 6.0,
            "axes.linewidth": 0.55,
            "lines.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "path" if svg_text_as_paths else "none",
            "svg.hashsalt": "CGT_FIGURE_005_REVISED_V1",
            "savefig.facecolor": COLORS["paper"],
            "figure.facecolor": COLORS["paper"],
            "axes.facecolor": COLORS["paper"],
            "text.color": COLORS["ink"],
            "axes.labelcolor": COLORS["ink"],
            "xtick.color": COLORS["ink"],
            "ytick.color": COLORS["ink"],
        }
    )


class Registry:
    """Collect semantic geometry for strict layout auditing."""

    def __init__(self, fig: mpl.figure.Figure) -> None:
        self.fig = fig
        self.entries: list[dict[str, Any]] = []
        self.artists: dict[str, Any] = {}

    def add(
        self,
        semantic_id: str,
        artist: Any,
        *,
        kind: str,
        panel: str,
        container: str | None = None,
        clearance_pt: float | None = None,
        related: Iterable[str] = (),
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        if semantic_id in self.artists:
            raise ValueError(f"Duplicate semantic id: {semantic_id}")
        if hasattr(artist, "set_gid"):
            artist.set_gid(semantic_id)
        self.artists[semantic_id] = artist
        entry: dict[str, Any] = {
            "semantic_id": semantic_id,
            "kind": kind,
            "panel": panel,
            "container": container,
            "required_clearance_pt": clearance_pt,
            "related": list(related),
            "metadata": metadata or {},
        }
        if kind == "text":
            entry["text"] = str(artist.get_text())
            entry["font_size_pt"] = float(artist.get_fontsize())
        self.entries.append(entry)
        return artist

    def register_untracked_text(self) -> None:
        known = {id(value) for value in self.artists.values()}
        count = 0
        for artist in self.fig.findobj(mpl.text.Text):
            if id(artist) in known or not artist.get_visible() or not artist.get_text().strip():
                continue
            panel = "canvas"
            try:
                axes = artist.axes
                gid = axes.get_gid() if axes is not None else None
                if gid and gid.startswith("panel_"):
                    panel = gid.split("_")[1]
            except Exception:
                pass
            self.add(f"auto_text_{count:04d}", artist, kind="text", panel=panel)
            count += 1

    def finalize(self, path: Path) -> None:
        self.register_untracked_text()
        self.fig.canvas.draw()
        renderer = self.fig.canvas.get_renderer()
        dpi = float(self.fig.dpi)
        by_id = {entry["semantic_id"]: entry for entry in self.entries}
        for semantic_id, artist in self.artists.items():
            entry = by_id[semantic_id]
            bbox = artist.get_window_extent(renderer)
            entry["bbox_pt"] = [float(value) * 72.0 / dpi for value in bbox.extents]
            entry["zorder"] = float(artist.get_zorder()) if hasattr(artist, "get_zorder") else None
        payload = {
            "schema_version": "1.0",
            "figure_id": "CGT_FIGURE_005",
            "canvas": {
                "width_mm": WIDTH_MM,
                "height_mm": HEIGHT_MM,
                "width_pt": WIDTH_PT,
                "height_pt": HEIGHT_PT,
                "publication_dpi": PUB_DPI,
                "publication_size_px": list(PUB_SIZE),
                "web_size_px": list(WEB_SIZE),
            },
            "minimum_font_size_pt": min(
                entry["font_size_pt"] for entry in self.entries if entry["kind"] == "text"
            ),
            "panels_pt": {key: list(value) for key, value in PANEL_BOXES_PT.items()},
            "entries": self.entries,
        }
        path.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def fig_text(
    fig: plt.Figure,
    registry: Registry,
    x: float,
    y: float,
    value: str,
    *,
    semantic_id: str,
    panel: str,
    size: float = 7.0,
    weight: str = "normal",
    color: str = COLORS["ink"],
    ha: str = "left",
    va: str = "top",
    linespacing: float = 1.08,
    container: str | None = None,
    clearance_pt: float | None = None,
    related: Iterable[str] = (),
    zorder: float = 5.0,
) -> mpl.text.Text:
    artist = fig.text(
        x / WIDTH_PT,
        y / HEIGHT_PT,
        value,
        transform=fig.transFigure,
        fontsize=size,
        fontproperties=BOLD if weight == "bold" else REGULAR,
        fontweight="bold" if weight == "bold" else "normal",
        color=color,
        ha=ha,
        va=va,
        linespacing=linespacing,
        zorder=zorder,
    )
    return registry.add(
        semantic_id,
        artist,
        kind="text",
        panel=panel,
        container=container,
        clearance_pt=clearance_pt,
        related=related,
    )


def fig_rect(
    fig: plt.Figure,
    registry: Registry,
    x: float,
    y: float,
    w: float,
    h: float,
    *,
    semantic_id: str,
    panel: str,
    facecolor: str = COLORS["paper"],
    edgecolor: str = COLORS["rule"],
    linewidth: float = 0.55,
    rounded: bool = False,
    zorder: float = 1.0,
) -> mpl.patches.Patch:
    if rounded:
        artist = FancyBboxPatch(
            (x / WIDTH_PT, y / HEIGHT_PT),
            w / WIDTH_PT,
            h / HEIGHT_PT,
            boxstyle="round,pad=0.0025,rounding_size=0.006",
            transform=fig.transFigure,
            facecolor=facecolor,
            edgecolor=edgecolor,
            linewidth=linewidth,
            zorder=zorder,
        )
    else:
        artist = Rectangle(
            (x / WIDTH_PT, y / HEIGHT_PT),
            w / WIDTH_PT,
            h / HEIGHT_PT,
            transform=fig.transFigure,
            facecolor=facecolor,
            edgecolor=edgecolor,
            linewidth=linewidth,
            zorder=zorder,
        )
    fig.add_artist(artist)
    return registry.add(semantic_id, artist, kind="container", panel=panel)


def add_axes_pt(fig: plt.Figure, box: tuple[float, float, float, float], *, gid: str) -> plt.Axes:
    x, y, w, h = box
    ax = fig.add_axes([x / WIDTH_PT, y / HEIGHT_PT, w / WIDTH_PT, h / HEIGHT_PT])
    ax.set_gid(gid)
    return ax


def add_panel_header(fig: plt.Figure, registry: Registry, panel: str, title: str, subtitle: str = "") -> None:
    x, y, _, h = PANEL_BOXES_PT[panel]
    top = y + h
    fig_text(fig, registry, x, top, panel, semantic_id=f"panel_{panel}_letter", panel=panel, size=9.0, weight="bold")
    fig_text(fig, registry, x + 14.0, top - 0.1, title, semantic_id=f"panel_{panel}_title", panel=panel, size=8.2, weight="bold")
    if subtitle:
        fig_text(fig, registry, x + 14.0, top - 11.0, subtitle, semantic_id=f"panel_{panel}_subtitle", panel=panel, size=6.0, color=COLORS["muted"])


def validate_fonts_and_profile(profile: Path) -> None:
    observed = {"regular": sha256(FONT_REGULAR), "bold": sha256(FONT_BOLD)}
    if observed != FONT_HASHES:
        raise RuntimeError(f"Pinned font hash mismatch: {observed}")
    if not profile.is_file() or profile.stat().st_size < 1000:
        raise RuntimeError(f"Missing or invalid sRGB profile: {profile}")


def validate_inputs(source_root: Path) -> dict[str, pd.DataFrame]:
    data = source_root / "data"
    names = {
        "metrics": "Fig5a_input_metrics.csv",
        "comparison": "Fig5b_matrix_comparison.csv",
        "variance": "Fig5_pca_variance.csv",
        "scores": "Fig5_pca_scores.csv",
        "centroids": "Fig5c_all33_centroids.csv",
        "heatmap": "Fig5d_heatmap_matrix.csv",
        "eta2": "Fig5e_lineage_r2.csv",
        "labels": "Fig5_axis_labels.csv",
        "correlation": "Fig5f_all15_residual_axis_correlation.csv",
        "corr_summary": "Fig5f_all15_correlation_summary.csv",
    }
    paths = {key: data / value for key, value in names.items()}
    for path in paths.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    tables = {key: pd.read_csv(path) for key, path in paths.items()}

    metrics = tables["metrics"].iloc[0]
    if tuple(int(metrics[key]) for key in ["n_tumors", "n_cancer_types", "n_axes", "n_display_axes", "n_genes"]) != (9302, 33, 15, 12, 970):
        raise ValueError("Input metric denominators changed")
    comparison = tables["comparison"].set_index("matrix")
    expected_corr = {"raw": 0.7534773693712723, "centered": 0.2794281841664304, "loo_global_residual": 0.26541949924810754}
    for key, expected in expected_corr.items():
        if not math.isclose(float(comparison.loc[key, "mean_abs_axis_correlation"]), expected, abs_tol=1e-12):
            raise ValueError(f"Correlation summary changed: {key}")
    variance = tables["variance"]
    pc1 = variance.query("component_number == 1").set_index("matrix")["explained_variance_ratio"]
    expected_pc1 = {"raw": 0.8303963669221571, "centered": 0.33153269137209834, "loo": 0.3222381186685812}
    for key, expected in expected_pc1.items():
        if not math.isclose(float(pc1[key]), expected, abs_tol=1e-12):
            raise ValueError(f"PC1 summary changed: {key}")
    labels = tables["labels"]
    if len(labels) != 15 or not labels["axis_id"].is_unique or int(labels["displayed"].astype(str).str.lower().eq("true").sum()) != 12:
        raise ValueError("The 15/12 score-set registry changed")
    scores = tables["scores"]
    if len(scores) != 9302 or scores["cancer_type_short"].nunique() != 33:
        raise ValueError("PCA score denominator changed")
    centroids = tables["centroids"]
    if len(centroids) != 33 or int(centroids["n_samples"].sum()) != 9302:
        raise ValueError("All-33 centroid reconstruction changed")
    heatmap = tables["heatmap"]
    heat_axes = [column for column in heatmap if column != "cancer_type_short"]
    if heatmap.shape != (33, 13) or set(heat_axes) != set(labels.loc[labels["displayed"].astype(str).str.lower().eq("true"), "axis_id"]):
        raise ValueError("Heatmap 33 x 12 universe changed")
    values = heatmap[heat_axes].to_numpy(float)
    if not np.allclose(values.mean(axis=1), 0.0, atol=1e-12) or not np.allclose(values.std(axis=1, ddof=1), 1.0, atol=1e-12):
        raise ValueError("Heatmap rows are no longer sample-z-standardized")
    eta2 = tables["eta2"]
    if len(eta2) != 15 or set(eta2["axis_id"]) != set(labels["axis_id"]):
        raise ValueError("Eta-squared universe changed")
    corr = tables["correlation"].set_index("axis_id")
    axis_ids = labels["axis_id"].tolist()
    corr = corr.loc[axis_ids, axis_ids]
    if not np.allclose(corr, corr.T, atol=1e-12) or not np.allclose(np.diag(corr), 1.0, atol=1e-12):
        raise ValueError("All-15 residual correlation matrix is invalid")
    tables["correlation"] = corr
    tables["axis_order"] = eta2.sort_values("raw", ascending=False)["axis_id"].reset_index(drop=True).to_frame()
    return tables


def draw_panel_a(fig: plt.Figure, registry: Registry) -> None:
    add_panel_header(fig, registry, "a", "TCGA cohort after QC", "9,359 input; 57 excluded")
    x, y, w, _ = PANEL_BOXES_PT["a"]
    gap = 5.0
    card_w = (w - gap) / 2.0
    card_h = 25.0
    cards = [
        ("9,302", "retained samples"),
        ("33", "cancer types"),
        ("15", "candidate scores"),
        ("970", "unique genes"),
    ]
    for index, (value, label) in enumerate(cards):
        col, row = index % 2, index // 2
        cx = x + col * (card_w + gap)
        cy = y + 4.0 + (1 - row) * (card_h + 5.0)
        cid = f"panel_a_card_{index}"
        fig_rect(fig, registry, cx, cy, card_w, card_h, semantic_id=cid, panel="a", facecolor=COLORS["light"], rounded=True)
        fig_text(fig, registry, cx + 5.0, cy + card_h - 3.5, value, semantic_id=f"panel_a_value_{index}", panel="a", size=9.0, weight="bold", color=COLORS["loo"], container=cid, clearance_pt=3.0)
        fig_text(fig, registry, cx + 5.0, cy + 4.0, label, semantic_id=f"panel_a_label_{index}", panel="a", size=6.0, weight="bold", va="bottom", container=cid, clearance_pt=3.0)


def draw_panel_b(fig: plt.Figure, registry: Registry, tables: dict[str, pd.DataFrame]) -> None:
    add_panel_header(fig, registry, "b", "Within-cohort transforms reduce shared dependence", "standardized-axis PCA and all 105 unique score pairs")
    x, y, w, _ = PANEL_BOXES_PT["b"]
    comparison = tables["comparison"].set_index("matrix")
    variance = tables["variance"].query("component_number == 1").set_index("matrix")
    comparison_order = ["raw", "centered", "loo_global_residual"]
    variance_order = ["raw", "centered", "loo"]
    labels = ["Raw", "Centered", "LOO-axis residual"]
    colors = [COLORS["raw"], COLORS["centered"], COLORS["loo"]]
    metrics = [
        ("PC1 share", [float(variance.loc[key, "explained_variance_ratio"]) for key in variance_order]),
        ("Mean |Spearman ρ|", [float(comparison.loc[key, "mean_abs_axis_correlation"]) for key in comparison_order]),
    ]
    facet_gap = 17.0
    facet_w = (w - facet_gap) / 2.0
    for facet, (title, values) in enumerate(metrics):
        ax = add_axes_pt(fig, (x + facet * (facet_w + facet_gap), y + 9.0, facet_w, 52.0), gid=f"panel_b_facet_{facet}")
        ax.set_ylim(0, 0.92)
        ax.set_xlim(-0.55, 2.55)
        ax.spines[["left", "right", "top"]].set_visible(False)
        ax.spines["bottom"].set_color(COLORS["rule"])
        ax.set_yticks([0, 0.5, 1.0])
        ax.set_yticklabels(["0", ".5", "1"])
        ax.set_xticks(range(3), labels)
        ax.tick_params(axis="x", length=0, pad=2)
        ax.tick_params(axis="y", length=2, pad=1)
        ax.grid(axis="y", color=COLORS["grid"], linewidth=0.45, zorder=0)
        ax.set_title(title, loc="left", fontsize=6.4, fontweight="bold", pad=2.5)
        for idx, (value, color) in enumerate(zip(values, colors)):
            ax.vlines(idx, 0, value, color=color, linewidth=1.1, zorder=2)
            marker = "o" if idx == 0 else ("s" if idx == 1 else "D")
            face = "white" if idx < 2 else color
            ax.scatter([idx], [value], s=24, marker=marker, facecolor=face, edgecolor=color, linewidth=0.9, zorder=3)
            ax.text(idx, value + 0.055, f"{100 * value:.1f}%", ha="center", va="bottom", fontsize=6.0, fontweight="bold", color=color)


def draw_panel_c(fig: plt.Figure, registry: Registry, tables: dict[str, pd.DataFrame]) -> None:
    add_panel_header(fig, registry, "c", "TCGA-fitted PCA of pooled LOO-axis residual scores", "all 9,302 samples and all 33 cancer-type centroids; PC direction is sign-arbitrary")
    x, y, w, _ = PANEL_BOXES_PT["c"]
    plot_box = (x + 91.0, y + 10.0, w - 182.0, 110.0)
    ax = add_axes_pt(fig, plot_box, gid="panel_c_plot")
    scores = tables["scores"]
    centroids = tables["centroids"].sort_values("loo_PC1_mean").reset_index(drop=True)
    ax.scatter(scores["loo_PC1"], scores["loo_PC2"], s=2.0, c=COLORS["cloud"], alpha=0.16, linewidths=0, rasterized=True, zorder=1)
    ax.scatter(centroids["loo_PC1_mean"], centroids["loo_PC2_mean"], s=17, c=COLORS["loo"], edgecolors="white", linewidths=0.55, zorder=4)
    ax.axhline(0, color=COLORS["grid"], linewidth=0.45, zorder=0)
    ax.axvline(0, color=COLORS["grid"], linewidth=0.45, zorder=0)
    ax.set_xlim(-8.2, 8.0)
    ax.set_ylim(-8.2, 5.2)
    ax.set_xlabel("PC1 (32.2%)", labelpad=1)
    ax.set_ylabel("")
    ax.text(0.015, 0.975, "PC2 (14.3%)", transform=ax.transAxes, ha="left", va="top", fontsize=6.0, fontweight="bold", color=COLORS["muted"])
    ax.tick_params(length=2, pad=1)
    ax.spines[["top", "right"]].set_visible(False)

    # Place every centroid label outside the tumor viewport. Splitting by x-rank
    # gives 17 left and 16 right labels. Sorting by PC2 and monotonically packing
    # each gutter makes leader crossings impossible within either side.
    fig.canvas.draw()
    left = centroids.iloc[:17].sort_values("loo_PC2_mean").reset_index(drop=True)
    right = centroids.iloc[17:].sort_values("loo_PC2_mean").reset_index(drop=True)
    gutter_y = np.linspace(plot_box[1] + 2.2, plot_box[1] + plot_box[3] - 2.2, 17)
    for side, group in [("left", left), ("right", right)]:
        positions = gutter_y if side == "left" else np.linspace(plot_box[1] + 2.2, plot_box[1] + plot_box[3] - 2.2, len(group))
        label_x = plot_box[0] - 28.0 if side == "left" else plot_box[0] + plot_box[2] + 28.0
        elbow_x = plot_box[0] - 2.0 if side == "left" else plot_box[0] + plot_box[2] + 2.0
        ha = "right" if side == "left" else "left"
        for idx, (row, label_y) in enumerate(zip(group.itertuples(index=False), positions)):
            pixel = ax.transData.transform((row.loo_PC1_mean, row.loo_PC2_mean))
            point_x = float(pixel[0]) * 72.0 / fig.dpi
            point_y = float(pixel[1]) * 72.0 / fig.dpi
            line = Line2D(
                [point_x / WIDTH_PT, elbow_x / WIDTH_PT, label_x / WIDTH_PT],
                [point_y / HEIGHT_PT, point_y / HEIGHT_PT, label_y / HEIGHT_PT],
                transform=fig.transFigure,
                color=COLORS["rule"],
                linewidth=0.42,
                zorder=2,
            )
            fig.add_artist(line)
            registry.add(f"panel_c_{side}_leader_{idx}", line, kind="leader", panel="c", metadata={"side": side, "rank": idx})
            fig_text(
                fig,
                registry,
                label_x,
                label_y,
                f"{row.cancer_type_short}  {int(row.n_samples):,}",
                semantic_id=f"panel_c_{side}_label_{idx}",
                panel="c",
                size=6.0,
                ha=ha,
                va="center",
                related=[f"panel_c_{side}_leader_{idx}"],
            )


def draw_panel_d(fig: plt.Figure, registry: Registry, tables: dict[str, pd.DataFrame]) -> None:
    add_panel_header(fig, registry, "d", "Within-cancer-type relative mean profiles", "row z-scores across 12 named scores (sample SD); rows alphabetical; colors are not comparable across rows")
    x, y, w, _ = PANEL_BOXES_PT["d"]
    eta2 = tables["eta2"].set_index("axis_id")
    display = tables["labels"].loc[tables["labels"]["displayed"].astype(str).str.lower().eq("true"), "axis_id"].tolist()
    order = [axis for axis in eta2.sort_values("raw", ascending=False).index if axis in display]
    heat = tables["heatmap"].set_index("cancer_type_short").loc[:, order].sort_index()
    centroids = tables["centroids"].set_index("cancer_type_short")
    types = heat.index.tolist()
    blocks = [types[:17], types[17:]]
    cmap = LinearSegmentedColormap.from_list("cgt_diverging", [COLORS["negative"], COLORS["neutral"], COLORS["positive"]], N=256)
    norm = TwoSlopeNorm(vmin=-3.1, vcenter=0.0, vmax=3.1)
    block_gap = 23.0
    block_w = (w - block_gap) / 2.0
    images = []
    for block_idx, rows in enumerate(blocks):
        bx = x + block_idx * (block_w + block_gap)
        ax = add_axes_pt(fig, (bx + 34.0, y + 51.0, block_w - 34.0, 124.0), gid=f"panel_d_heatmap_{block_idx}")
        values = heat.loc[rows].to_numpy(float)
        image = ax.pcolormesh(
            np.arange(len(order) + 1),
            np.arange(len(rows) + 1),
            values,
            cmap=cmap,
            norm=norm,
            shading="flat",
            rasterized=False,
        )
        images.append(image)
        ax.set_xlim(0, len(order))
        ax.set_ylim(len(rows), 0)
        ax.set_xticks(np.arange(len(order)) + 0.5, [str(order.index(axis) + 1) for axis in order])
        ax.xaxis.tick_top()
        ax.tick_params(axis="x", length=0, pad=1)
        ax.set_yticks(np.arange(len(rows)) + 0.5, [f"{code}  {int(centroids.loc[code, 'n_samples']):,}" for code in rows])
        ax.tick_params(axis="y", length=0, pad=2)
        for spine in ax.spines.values():
            spine.set_color(COLORS["rule"])
            spine.set_linewidth(0.5)
        ax.set_xticks(np.arange(0, len(order) + 1), minor=True)
        ax.set_yticks(np.arange(0, len(rows) + 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=0.28)
        ax.tick_params(which="minor", bottom=False, left=False)

    # A compact, two-line score key keeps each responsive crop self-contained.
    numbered = [f"{idx + 1} {HEATMAP_ABBR[axis]}" for idx, axis in enumerate(order)]
    fig_text(fig, registry, x + 34.0, y + 41.0, "  ·  ".join(numbered[:6]), semantic_id="panel_d_key_1", panel="d", size=6.0, color=COLORS["muted"])
    fig_text(fig, registry, x + 34.0, y + 31.0, "  ·  ".join(numbered[6:]), semantic_id="panel_d_key_2", panel="d", size=6.0, color=COLORS["muted"])
    cax = add_axes_pt(fig, (x + w - 113.0, y + 12.0, 102.0, 5.0), gid="panel_d_colorbar")
    color_values = np.linspace(-3.1, 3.1, 64).reshape(1, -1)
    cax.pcolormesh(np.linspace(-3.1, 3.1, 65), [0, 1], color_values, cmap=cmap, norm=norm, shading="flat", rasterized=False)
    cax.set_xlim(-3.1, 3.1)
    cax.set_ylim(0, 1)
    cax.set_yticks([])
    cax.set_xticks([-3.1, 0, 3.1], ["−3.1", "0", "+3.1"])
    cax.tick_params(length=2, pad=1)
    for spine in cax.spines.values():
        spine.set_linewidth(0.45)
    fig_text(fig, registry, x + w - 119.0, y + 19.0, "within-row z", semantic_id="panel_d_colorbar_label", panel="d", size=6.0, color=COLORS["muted"], ha="right", va="bottom")


def draw_panel_e(fig: plt.Figure, registry: Registry, tables: dict[str, pd.DataFrame]) -> None:
    add_panel_header(fig, registry, "e", "In-sample cancer-type variance fraction")
    x, y, w, _ = PANEL_BOXES_PT["e"]
    eta2 = tables["eta2"].set_index("axis_id")
    order = eta2.sort_values("raw", ascending=False).index.tolist()
    ax = add_axes_pt(fig, (x + 90.0, y + 14.0, w - 96.0, 106.0), gid="panel_e_plot")
    y_positions = np.arange(len(order))[::-1]
    ax.set_xlim(0.20, 0.60)
    ax.set_ylim(-0.75, len(order) - 0.25)
    ax.set_xticks([0.2, 0.3, 0.4, 0.5, 0.6])
    ax.set_xlabel("η²in (sample-weighted)", labelpad=1)
    ax.set_yticks(y_positions, [f"{idx + 1:02d}  {SHORT_LABELS[axis]}" for idx, axis in enumerate(order)])
    ax.tick_params(axis="y", length=0, pad=2)
    ax.tick_params(axis="x", length=2, pad=1)
    ax.grid(axis="x", color=COLORS["grid"], linewidth=0.45, zorder=0)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color(COLORS["rule"])
    for pos, axis in zip(y_positions, order):
        raw = float(eta2.loc[axis, "raw"])
        loo = float(eta2.loc[axis, "loo_global_residual"])
        ax.plot([raw, loo], [pos + 0.12, pos - 0.12], color=COLORS["rule"], linewidth=0.55, zorder=1)
        ax.scatter([raw], [pos + 0.12], s=14, marker="o", facecolor="white", edgecolor=COLORS["raw"], linewidth=0.8, zorder=3)
        ax.scatter([loo], [pos - 0.12], s=14, marker="D", facecolor=COLORS["loo"], edgecolor="white", linewidth=0.4, zorder=3)
    handles = [
        Line2D([], [], marker="o", markerfacecolor="white", markeredgecolor=COLORS["raw"], linestyle="none", label="Raw"),
        Line2D([], [], marker="D", markerfacecolor=COLORS["loo"], markeredgecolor="white", linestyle="none", label="LOO-axis residual"),
    ]
    ax.legend(handles=handles, loc="lower right", bbox_to_anchor=(1.0, 1.015), frameon=False, fontsize=6.0, ncol=2, handletextpad=0.3, columnspacing=0.8, borderaxespad=0)
    fig_text(fig, registry, x + 1.0, y + 2.0, "† source label not shown in d", semantic_id="panel_e_scope_note", panel="e", size=6.0, color=COLORS["muted"], va="bottom")


def draw_panel_f(fig: plt.Figure, registry: Registry, tables: dict[str, pd.DataFrame]) -> None:
    add_panel_header(fig, registry, "f", "Residual score dependence remains", "all 15 scores in e order; lower triangle only")
    x, y, w, _ = PANEL_BOXES_PT["f"]
    eta2 = tables["eta2"].set_index("axis_id")
    order = eta2.sort_values("raw", ascending=False).index.tolist()
    corr = tables["correlation"].loc[order, order].to_numpy(float)
    mask = np.triu(np.ones_like(corr, dtype=bool), k=0)
    shown = np.ma.array(corr, mask=mask)
    cmap = LinearSegmentedColormap.from_list("cgt_corr", [COLORS["negative"], COLORS["neutral"], COLORS["positive"]], N=256)
    cmap.set_bad("white")
    ax = add_axes_pt(fig, (x + 26.0, y + 14.0, 101.0, 101.0), gid="panel_f_heatmap")
    image = ax.pcolormesh(
        np.arange(16),
        np.arange(16),
        shown,
        vmin=-1,
        vmax=1,
        cmap=cmap,
        shading="flat",
        rasterized=False,
    )
    numbers = [str(index + 1) for index in range(15)]
    ax.set_xlim(0, 15)
    ax.set_ylim(15, 0)
    ax.set_xticks(np.arange(0, 15, 2) + 0.5, numbers[::2])
    ax.set_yticks(np.arange(15) + 0.5, numbers)
    ax.xaxis.tick_top()
    ax.tick_params(length=0, pad=1)
    for spine in ax.spines.values():
        spine.set_color(COLORS["rule"])
        spine.set_linewidth(0.5)
    ax.set_xticks(np.arange(0, 16, 1), minor=True)
    ax.set_yticks(np.arange(0, 16, 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=0.25)
    ax.tick_params(which="minor", bottom=False, left=False)
    summary = tables["corr_summary"].iloc[0]
    note_x = x + 137.0
    fig_text(fig, registry, note_x, y + 109.0, "All-score summary", semantic_id="panel_f_note_title", panel="f", size=6.2, weight="bold")
    fig_text(fig, registry, note_x, y + 96.0, f"mean |ρ|  {float(summary.mean_abs_offdiag_spearman):.3f}", semantic_id="panel_f_mean", panel="f", size=6.0)
    fig_text(fig, registry, note_x, y + 85.0, f"max |ρ|   {float(summary.max_abs_offdiag_spearman):.3f}", semantic_id="panel_f_max", panel="f", size=6.0)
    pair_1 = order.index(str(summary.max_abs_pair_axis_1)) + 1
    pair_2 = order.index(str(summary.max_abs_pair_axis_2)) + 1
    fig_text(fig, registry, note_x, y + 74.0, f"pair         {pair_1} ↔ {pair_2}", semantic_id="panel_f_pair", panel="f", size=6.0)
    fig_text(fig, registry, note_x, y + 55.0, "Residualization\ndoes not make scores\northogonal or\nindependent.", semantic_id="panel_f_scope", panel="f", size=6.0, weight="bold", color=COLORS["positive"], linespacing=1.05)
    cax = add_axes_pt(fig, (note_x, y + 10.0, w - 147.0, 5.0), gid="panel_f_colorbar")
    corr_color_values = np.linspace(-1, 1, 64).reshape(1, -1)
    cax.pcolormesh(np.linspace(-1, 1, 65), [0, 1], corr_color_values, cmap=cmap, vmin=-1, vmax=1, shading="flat", rasterized=False)
    cax.set_xlim(-1, 1)
    cax.set_ylim(0, 1)
    cax.set_yticks([])
    cax.set_xticks([-1, 0, 1], ["−1", "0", "+1"])
    cax.tick_params(length=2, pad=1)
    for spine in cax.spines.values():
        spine.set_linewidth(0.45)


def build_figure(source_root: Path, *, svg_text_as_paths: bool) -> tuple[plt.Figure, Registry, dict[str, pd.DataFrame]]:
    configure_matplotlib(svg_text_as_paths=svg_text_as_paths)
    tables = validate_inputs(source_root)
    fig = plt.figure(figsize=(WIDTH_MM / 25.4, HEIGHT_MM / 25.4), dpi=100, facecolor=COLORS["paper"])
    registry = Registry(fig)
    draw_panel_a(fig, registry)
    draw_panel_b(fig, registry, tables)
    draw_panel_c(fig, registry, tables)
    draw_panel_d(fig, registry, tables)
    draw_panel_e(fig, registry, tables)
    draw_panel_f(fig, registry, tables)
    return fig, registry, tables


def write_png_with_profile(fig: plt.Figure, path: Path, profile_path: Path, *, dpi: int) -> None:
    render_temp = path.with_suffix(".rendering.png")
    profiled_temp = path.with_suffix(".profiled.png")
    fig.savefig(render_temp, dpi=dpi, bbox_inches=None, pad_inches=0, facecolor="white", pil_kwargs={"compress_level": 9})
    with Image.open(render_temp) as image:
        rgb = image.convert("RGB")
        rgb.save(profiled_temp, format="PNG", compress_level=9, optimize=False, icc_profile=profile_path.read_bytes(), dpi=(dpi, dpi))
    with Image.open(profiled_temp) as verification:
        verification.verify()
    profiled_temp.replace(path)
    render_temp.unlink()


def write_downscale(source: Path, destination: Path, size: tuple[int, int], profile_path: Path) -> None:
    with Image.open(source) as image:
        resized = image.convert("RGB").resize(size, Image.Resampling.LANCZOS)
        resized.save(destination, format="PNG", compress_level=9, optimize=False, icc_profile=profile_path.read_bytes())


def write_responsive_crop(source: Path, destination: Path, crop_box_pt: tuple[float, float, float, float], output_width: int, profile_path: Path) -> tuple[int, int]:
    x, y, width, height = crop_box_pt
    with Image.open(source) as image:
        rgb = image.convert("RGB")
        scale_x = rgb.width / WIDTH_PT
        scale_y = rgb.height / HEIGHT_PT
        left = max(0, math.floor(x * scale_x))
        right = min(rgb.width, math.ceil((x + width) * scale_x))
        top = max(0, math.floor((HEIGHT_PT - (y + height)) * scale_y))
        bottom = min(rgb.height, math.ceil((HEIGHT_PT - y) * scale_y))
        cropped = rgb.crop((left, top, right, bottom))
        output_height = round(output_width * cropped.height / cropped.width)
        resized = cropped.resize((output_width, output_height), Image.Resampling.LANCZOS)
        resized.save(destination, format="PNG", compress_level=9, optimize=False, icc_profile=profile_path.read_bytes())
    return output_width, output_height


def add_svg_accessibility(path: Path, title: str, description: str) -> None:
    value = path.read_text(encoding="utf-8")
    start = value.find("<svg")
    end = value.find(">", start)
    if start < 0 or end < 0:
        raise RuntimeError(f"Malformed SVG root: {path}")
    root = value[start : end + 1]
    if "aria-labelledby=" not in root:
        root = root[:-1] + ' role="img" aria-labelledby="cgt-fig5-title cgt-fig5-desc">'
    injection = f'\n <title id="cgt-fig5-title">{html.escape(title)}</title>\n <desc id="cgt-fig5-desc">{html.escape(description)}</desc>'
    path.write_text(value[:start] + root + injection + value[end + 1 :], encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--qa-dir", type=Path, required=True)
    args = parser.parse_args()
    source_root = args.source_root.resolve()
    output_dir = args.output_dir.resolve()
    qa_dir = args.qa_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    qa_dir.mkdir(parents=True, exist_ok=True)
    profile = source_root / "assets" / "sRGB.icc"
    validate_fonts_and_profile(profile)

    base = "CGT_FIGURE_005_tcga_cancer_type_structure_revised"
    fig, registry, tables = build_figure(source_root, svg_text_as_paths=True)
    layout_path = qa_dir / "CGT_FIGURE_005_layout_registry.json"
    registry.finalize(layout_path)
    metadata = {
        "Title": "CGT Figure 5 | Cancer-type-associated variation in TCGA bulk expression",
        "Author": "John Patrick Collins",
        "Subject": "Descriptive TCGA analysis using previously defined CGT-derived candidate score sets",
        "Keywords": "CGT; TCGA; bulk expression; cancer type; candidate scores",
        "Creator": "Deterministic CGT Figure 5 renderer",
        "CreationDate": FIXED_DATE,
        "ModDate": FIXED_DATE,
    }
    pdf_path = output_dir / f"{base}.pdf"
    svg_path = output_dir / f"{base}.svg"
    pub_png = output_dir / f"{base}_600dpi.png"
    web_png = output_dir / f"{base}_web.png"
    editable_svg = qa_dir / f"{base}_editable_text_QA.svg"
    fig.savefig(pdf_path, format="pdf", dpi=PUB_DPI, bbox_inches=None, pad_inches=0, metadata=metadata)
    fig.savefig(svg_path, format="svg", dpi=PUB_DPI, bbox_inches=None, pad_inches=0, metadata={"Date": "2026-08-23", "Creator": metadata["Creator"], "Title": metadata["Title"], "Description": metadata["Subject"]})
    accessible_title = "Figure 5: Cancer-type-associated variation in TCGA bulk expression across previously defined CGT candidate score sets"
    accessible_description = "Six panels report cohort QC, within-cohort score transformations, a TCGA-fitted PCA with all 33 cancer-type centroids, relative cancer-type score profiles, in-sample between-cancer-type variance fractions, and remaining residual score dependence."
    add_svg_accessibility(svg_path, accessible_title, accessible_description)
    write_png_with_profile(fig, pub_png, profile, dpi=PUB_DPI)
    write_downscale(pub_png, web_png, WEB_SIZE, profile)
    plt.close(fig)

    fig_editable, _, _ = build_figure(source_root, svg_text_as_paths=False)
    fig_editable.savefig(editable_svg, format="svg", dpi=PUB_DPI, bbox_inches=None, pad_inches=0, metadata={"Date": "2026-08-23", "Creator": metadata["Creator"], "Title": metadata["Title"], "Description": metadata["Subject"]})
    plt.close(fig_editable)
    add_svg_accessibility(editable_svg, accessible_title, accessible_description)

    responsive_outputs: dict[str, dict[str, Any]] = {}
    for panel, (crop_x, crop_y, crop_w, crop_h, output_width) in RESPONSIVE_CROPS_PT.items():
        path = output_dir / f"{base}_mobile_panel_{panel}.png"
        size = write_responsive_crop(pub_png, path, (crop_x, crop_y, crop_w, crop_h), int(output_width), profile)
        responsive_outputs[panel] = {"filename": path.name, "size_px": list(size), "sha256": sha256(path)}

    for width in [1600, 1200, 800, 480]:
        height = round(width * HEIGHT_MM / WIDTH_MM)
        write_downscale(pub_png, qa_dir / f"CGT_FIGURE_005_downscale_{width}px.png", (width, height), profile)

    tracked = sorted(path for path in source_root.rglob("*") if path.is_file())
    metadata_payload = {
        "schema_version": "1.0",
        "figure_id": "CGT_FIGURE_005",
        "render_date_utc": "2026-08-23T00:00:00Z",
        "canvas_mm": [WIDTH_MM, HEIGHT_MM],
        "publication_dpi": PUB_DPI,
        "publication_size_px": list(PUB_SIZE),
        "web_size_px": list(WEB_SIZE),
        "source_hashes": {path.relative_to(source_root).as_posix(): sha256(path) for path in tracked},
        "renderer": {"filename": Path(__file__).name, "sha256": sha256(Path(__file__).resolve())},
        "software_versions": {"python": platform.python_version(), "matplotlib": mpl.__version__, "numpy": np.__version__, "pandas": pd.__version__, "pillow": Image.__version__},
        "output_hashes": {path.name: sha256(path) for path in [pdf_path, svg_path, pub_png, web_png, editable_svg, layout_path]},
        "responsive_panel_outputs": responsive_outputs,
        "data_counts": {"samples": 9302, "cancer_types": 33, "score_sets": 15, "named_heatmap_scores": 12, "reported_unique_genes": 970},
    }
    (qa_dir / "CGT_FIGURE_005_render_metadata.json").write_text(json.dumps(metadata_payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
