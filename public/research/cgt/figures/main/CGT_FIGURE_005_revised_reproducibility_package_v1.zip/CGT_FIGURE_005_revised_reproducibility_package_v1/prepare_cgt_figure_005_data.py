#!/usr/bin/env python3
"""Derive transparent display tables from frozen CGT Figure 5 sources.

The script does not refit the CGT scoring model.  It performs two exact,
display-only operations from already frozen outputs:

1. recover all 33 cancer-type centroids from the frozen LOO-PCA score table,
   replacing the source figure's undocumented 24-types-plus-Other grouping;
2. calculate the all-15-axis Spearman matrix from the frozen LOO-adjusted
   score matrix, replacing the source figure's 12-axis display subset.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def read_parquet_portably(path: Path) -> pd.DataFrame:
    """Read Parquet with pandas when available, otherwise DuckDB."""
    try:
        return pd.read_parquet(path)
    except ImportError:
        try:
            import duckdb  # type: ignore
        except ImportError as exc:  # pragma: no cover - environment dependent
            raise RuntimeError(
                "Reading the frozen Parquet source requires pyarrow, "
                "fastparquet, or duckdb."
            ) from exc
        escaped = str(path.resolve()).replace("'", "''")
        return duckdb.sql(f"SELECT * FROM read_parquet('{escaped}')").df()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pca-scores", type=Path, required=True)
    parser.add_argument("--loo-matrix", type=Path, required=True)
    parser.add_argument("--axis-labels", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    pca = pd.read_csv(args.pca_scores)
    required = {
        "sample_id",
        "corrected_cancer_type",
        "cancer_type_short",
        "loo_PC1",
        "loo_PC2",
    }
    missing = sorted(required - set(pca.columns))
    if missing:
        raise ValueError(f"PCA score table is missing columns: {missing}")
    if len(pca) != 9302 or pca["cancer_type_short"].nunique() != 33:
        raise ValueError("Frozen PCA score denominators do not match 9,302 / 33")

    centroids = (
        pca.groupby(["cancer_type_short", "corrected_cancer_type"], sort=True)
        .agg(
            loo_PC1_mean=("loo_PC1", "mean"),
            loo_PC2_mean=("loo_PC2", "mean"),
            n_samples=("sample_id", "size"),
        )
        .reset_index()
    )
    centroids["radius"] = np.hypot(
        centroids["loo_PC1_mean"], centroids["loo_PC2_mean"]
    )
    if len(centroids) != 33 or int(centroids["n_samples"].sum()) != 9302:
        raise ValueError("All-type centroid reconstruction failed")
    centroids.to_csv(args.output_dir / "Fig5c_all33_centroids.csv", index=False)

    labels = pd.read_csv(args.axis_labels)
    if labels["axis_id"].duplicated().any() or len(labels) != 15:
        raise ValueError("Axis label registry must contain 15 unique axes")
    loo = read_parquet_portably(args.loo_matrix)
    if "sample_id" not in loo.columns:
        raise ValueError("LOO matrix does not contain sample_id")
    axis_ids = labels["axis_id"].astype(str).tolist()
    missing_axes = sorted(set(axis_ids) - set(loo.columns))
    if missing_axes:
        raise ValueError(f"LOO matrix is missing axes: {missing_axes}")
    if len(loo) != 9302:
        raise ValueError("LOO matrix row count is not 9,302")
    correlation = loo[axis_ids].corr(method="spearman")
    correlation.index.name = "axis_id"
    correlation.reset_index().to_csv(
        args.output_dir / "Fig5f_all15_residual_axis_correlation.csv", index=False
    )

    mask = ~np.eye(correlation.shape[0], dtype=bool)
    offdiag = correlation.where(mask).stack().astype(float)
    maximum_pair = offdiag.abs().idxmax()
    summary = pd.DataFrame(
        [
            {
                "n_samples": len(loo),
                "n_axes": len(axis_ids),
                "mean_abs_offdiag_spearman": float(offdiag.abs().mean()),
                "max_abs_offdiag_spearman": float(offdiag.abs().max()),
                "max_abs_pair_axis_1": maximum_pair[0],
                "max_abs_pair_axis_2": maximum_pair[1],
                "max_abs_pair_signed_spearman": float(
                    correlation.loc[maximum_pair[0], maximum_pair[1]]
                ),
            }
        ]
    )
    summary.to_csv(args.output_dir / "Fig5f_all15_correlation_summary.csv", index=False)


if __name__ == "__main__":
    main()
