# Revised Figure 5 methods

## Scope

The revised renderer starts from the frozen, post-QC raw and pooled leave-one-axis-out score matrices. It does not regenerate the upstream raw scores from TCGA expression. The raw-score mapping formula is not documented in the frozen Figure 5 package and is therefore an explicit provenance limitation.

## Cohort and QC

The frozen metadata contain 9,359 TCGA tumor-derived samples. `passes_expression_qc` is exactly equivalent to `sample_median_axis_gene_expression >= 2.5`. Applying this threshold retains 9,302 samples with unique sample and patient identifiers across 33 corrected cancer-type labels.

## Score-set registry

Fifteen candidate score definitions are imported from the upstream registry. Their recovered gene lists contain 1,876 memberships and 970 unique genes. A total of 595 unique genes occur in two or more candidate score sets. The source registry identifies 12 score labels as named/displayed, one as exploratory, and two as unresolved.

## Pooled leave-one-axis-out residualization

For each score column \(j\), define \(g_{i,-j}\) as the mean of the other 14 raw scores for sample \(i\), and \(m_i\) as that sample's median expression across retained score genes. Fit once across all 9,302 samples:

\[
s_{ij}=\beta_{0j}+\beta_{1j}z(g_{i,-j})+\beta_{2j}z(m_i)+\varepsilon_{ij}.
\]

The revised figure uses \(\varepsilon_{ij}\). This is leave-one-axis-out covariate construction, not leave-one-sample-out, leave-one-cancer-type-out, cross-validation, or external validation. Exact reconstruction from the frozen raw matrix agrees with the frozen residual matrix to a maximum absolute difference below \(2\times10^{-15}\).

## Panel calculations

- Panel b: each matrix is separately column-standardized before PCA. Mean absolute Spearman correlation is calculated over the 105 unique off-diagonal pairs among all 15 scores.
- Panel c: PCA is fitted on all 9,302 rows and all 15 standardized pooled residual scores. All 33 cancer-type centroids are arithmetic means in the fitted PC1–PC2 coordinates.
- Panel d: for the 12 named score sets, pooled residuals are averaged within each cancer type; each 12-value cancer-type row is then centered and standardized with the sample standard deviation (`ddof=1`). Rows are alphabetical. Columns inherit panel e's descending raw \(\eta^2_{\mathrm{in}}\) order.
- Panel e: \(\eta^2_{\mathrm{in}}\) is the sample-weighted between-cancer-type sum of squares divided by the pooled total sum of squares. All 15 scores are shown. No uncertainty or resampling is performed.
- Panel f: Spearman correlations are calculated across all 9,302 samples for all 15 pooled residual scores. Only the lower triangle is displayed.

## Rendering

The canonical canvas is exactly 183 × 238 mm. DejaVu Sans Regular and Bold are SHA-256 pinned. PDF uses embedded TrueType fonts; SVG text is converted to paths. Heatmap cells and color scales are vector primitives. Only the 9,302-point tumor cloud is rasterized at the 600-dpi export resolution. Raster exports are RGB and tagged with the bundled sRGB ICC profile.

