**Figure 5 | TCGA tumors projected into independently defined CGT axis
space.** **a,** Corrected TCGA/Xena projection inputs after expression-QC
filtering. **b,** Raw bulk-tumor CGT axis scores contain a dominant shared
component, shown by PC1 variance and mean absolute inter-axis Spearman
correlation. Sample-centered and leave-one-axis-out global-residualized
scoring reduce this shared component. **c,** TCGA tumors projected into
residualized CGT axis principal-component space. Grey points are
individual tumors; colored centroids are cancer types. **d,** Corrected
cancer-type mean residualized CGT axis scores, row-z-scored to emphasize
relative axis programs within cancer type. **e,** Fraction of axis
variance explained by corrected cancer type before and after
leave-one-axis-out global residualization. **f,** Spearman correlation
matrix among residualized displayed CGT axes. TCGA is interpreted as an
orthogonal tumor-state projection layer, not as a CGT discovery source or
causal validation.
