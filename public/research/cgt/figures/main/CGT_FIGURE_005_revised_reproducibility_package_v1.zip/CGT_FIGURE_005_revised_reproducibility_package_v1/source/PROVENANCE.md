# Revised Figure 5 provenance

## Frozen inputs

The release hashes every frozen input in `source/data` and `source/provenance`. The quantitative audit requires exact 9,302-row sample identity/order across the raw score matrix, pooled residual matrix, PCA table, and retained metadata; 15 score columns; 33 cancer types; and a 12-score named display subset.

## Notebook-version mismatch

The archived notebook extracted from `CGT_FIGURE_005.zip` is 72,768 bytes with SHA-256:

`51dee19a0791dfada00fc021649eb19b87789edab728b7afec5be576c25c84f5`

A later verified Drive inventory recorded a 355,190-byte file with the same notebook name and SHA-256:

`72d1efabe3dd8c0447817dedae3d6004b47374065eb90f83f9179ad8d525fb81`

The later file was not recoverable from the currently accessible Drive index, so executable-code equivalence could not be established. The archive is preserved but is not described as the canonical source notebook.

## Reproducibility boundary

The revised figure is reproducible from the frozen raw/residual score matrices and audited tables. The package does not document the exact upstream formula used to map TCGA expression and registry membership to raw score values; reconstruction from expression and the registry alone is therefore not claimed.

## Original assets

The current website PNG, PDF, and SVG are preserved byte-for-byte outside the revised output directory. The revised renderer never overwrites them. The website is not modified by this analysis task; integration is delegated to a checksum-pinned repository task.

