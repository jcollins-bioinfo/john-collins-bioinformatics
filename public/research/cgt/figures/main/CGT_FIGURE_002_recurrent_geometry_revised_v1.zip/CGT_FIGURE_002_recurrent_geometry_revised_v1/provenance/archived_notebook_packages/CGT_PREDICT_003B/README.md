# CGT-PREDICT-003B

Residual Perturbation Prediction after Context/Dataset Mean Removal.

This notebook follows CGT-PREDICT-003.

Purpose:
PREDICT-003 showed that raw family-coordinate prediction is dominated by dataset/context means. PREDICT-003B tests whether perturbation-specific predictive signal remains after subtracting context or dataset baselines.

Core question:
Can perturbation identity predict residual CGT family-coordinate structure beyond context/dataset effects?

Outputs include residual coordinate tables, leave-dataset-out residual transfer benchmarks, same-study proxy exclusion, leave-context-out residual transfer, shuffled-label controls, variance decomposition, and a summary figure.
