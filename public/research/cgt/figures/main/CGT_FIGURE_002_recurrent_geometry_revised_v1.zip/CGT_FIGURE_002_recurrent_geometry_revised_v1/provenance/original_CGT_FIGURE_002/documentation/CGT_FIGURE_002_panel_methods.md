# CGT-FIGURE-002 panel methods

Family recurrence and context distributions were taken from META-003,
which contained 248 modes from
43 datasets and
9 contexts. Residual analyses were
taken from PREDICT-003B and used exact perturbation labels.

Panel e uses mean cosine similarity across held-out perturbation
observations. Label-shuffle controls preserve the residual-coordinate
geometry but destroy perturbation identity; random-label controls replace
the same-label residual with residuals from unrelated labels.

Panel f uses the same-label residual-shrink predictor. Confidence
intervals were estimated with 4,000 cluster-bootstrap
iterations. Held-out datasets or contexts were sampled with replacement;
cluster sums and counts were combined so that the reported mean remains
row weighted while dependence within a held-out group is respected.

The combined figure is 183 mm wide and
170 mm high. The selected font is Liberation Sans;
standard text is 6.25 pt and panel labels are
8 pt. PDF and SVG preserve editable text; PNG is
exported at 600 dpi.
