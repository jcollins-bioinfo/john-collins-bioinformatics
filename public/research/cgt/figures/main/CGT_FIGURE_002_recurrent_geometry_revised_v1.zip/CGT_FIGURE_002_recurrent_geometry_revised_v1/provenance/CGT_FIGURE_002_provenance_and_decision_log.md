# CGT Figure 2: provenance and scientific decision log

**Document status:** release-candidate decision record  
**Audit date:** 2026-08-20 UTC  
**Figure:** `CGT_FIGURE_002`, revised title: *Residual family-coordinate structure recurs within the leave-dataset-out benchmark but attenuates under study-proxy and context exclusion*  
**Scope:** provenance, reconstruction, definitions, claim boundaries, falsification checks, and design decisions for the revised six-panel Figure 2. This record does not modify the frozen upstream analyses or their original exports.

## 1. Decisions at a glance

1. Treat the final standalone Colab notebooks as canonical. The later ZIP archives contain initial notebook revisions and are retained only as provenance evidence.
2. Preserve every original notebook, table, workbook, export, manifest, and archive byte-for-byte. The revised renderer reads the frozen Figure 2 panel tables and does not rerun or alter the scientific analyses.
3. Distinguish the two upstream analysis universes explicitly: PREDICT-003B supplies panels a, b, e, and f (2,720 perturbation observations; 39 datasets; 8 contexts), whereas META-003 supplies panels c and d (248 modes; 43 datasets; 9 contexts; 16 families).
4. Rename the upstream `universality_index` to **descriptive recurrence score** in the figure. Relabel `universal_candidate`, `intermediate`, and `context_specific` as B, I, and C, respectively. These are descriptive classes, not causal or ontological categories.
5. Interpret same-label cosine transfer as directional recurrence conditional on the preprocessing, label normalization, residualization scheme, and holdout design. Do not describe it as accurate vector reconstruction, causal prediction, or universal portability.
6. Do not display the legacy row-level Mann–Whitney p-values. Their repeated-shuffle rows and within-cluster dependence do not support treating them as calibrated independent-replicate inference.
7. Put the strict holdouts in the main figure. Their attenuation is a scientific boundary on the claim, not a supplementary detail.
8. Make all six panels complete and auditable: no family cherry-selection in panel d, no connected lines implying trajectories in panels e or f, explicit denominators and analysis universes, and a minimum final-size font of 7 pt.

## 2. Canonical source chain

### 2.1 Drive locations

| Role | Drive ID |
|---|---|
| CGT root | `1CZqDmkWTqq4mv53f3cZ8gDqUzUo11gcU` |
| `outputs/CGT_FIGURE_002` | `1qrOrTrJNATwh1zmNbAD0Mo3Wn6QoFgm_` |
| `outputs/CGT_META_003` | `1JrbwEFIcV1nUti3cuEm9JHnMweW_ou0A` |
| `outputs/CGT_PREDICT_003B` | `1XV8C0fw2NKAIczQrxb9los1eEx_rredY` |
| Colab Notebooks parent | `1PLk8Z6otvIQPbPFirM2LsX4rbA0oZwGa` |

### 2.2 Canonical executed notebooks

| Run | Drive ID | Modified UTC | Bytes | SHA-256 |
|---|---|---:|---:|---|
| `CGT_FIGURE_002` | `1arxGmsJtvJ5M0FTDkNaVfaz_niFCGPHD` | 2026-06-23 18:15:14.792 | 399,087 | `f8046ecb45971bb4d81288af00c0bca5ac2b075e2db6ae1dcd602dbebdf017d8` |
| `CGT_META_003` | `15auKNYoBedbmbGdPFlCXpTWtXkPP509f` | 2026-06-18 21:41:51.923 | 1,202,663 | `1a9cc4a8ec3a777c9cbde34c66227dde26716f40fa765fd4fd08e1b37c978693` |
| `CGT_PREDICT_003B` | `11GNwA6Lva3wmP_mwGjBx-rauJoOEHZ6M` | 2026-06-20 10:58:54.200 | 767,877 | `d6cd601713b4fab7f5fb01481ea860e0c26bda0b712f3e4bd0169508ea46afb6` |

The Figure 2 notebook digest exactly matches the expected canonical digest. Canonical Figure notebook URL: `https://colab.research.google.com/drive/1arxGmsJtvJ5M0FTDkNaVfaz_niFCGPHD`.

### 2.3 Exact upstream artifacts read for reconstruction

| Run | Artifact | Drive ID | Bytes | SHA-256 | Role |
|---|---|---|---:|---|---|
| META-003 | `CGT_META_003_summary_report.json` | `1MnAKvPEo3UuZfSYmma4M8Un-FUXkYCJE` | 6,761 | `0070361149e31a86a10696e4cd0a25c8289e595e187bf26adb19b11444ffdca8` | Universe counts and summary cross-check |
| META-003 | `CGT_META_003_universal_constraint_atlas_annotated.csv` | `1gHCbd0r4Ylp55KM_9fDpkEzC5jY7oy9i` | 13,626 | `d65ede640de157066f2c78e5856371cbdda190e42c8a5c012fc84a8e374d8b0d` | Family recurrence, breadth, and descriptive classes |
| META-003 | `CGT_META_003_family_context_row_normalized.csv` | `1_wgKRRws60hJQc5_5mas5_aeOnI6oANv` | 1,022 | `806038a77274860c3ec8957b3cdbe6a2367601d876eea20916c4f08d62fab14a` | Within-family context composition |
| PREDICT-003B | `CGT_PREDICT_003B_summary_report.json` | `1PD-MxUqab_RXTVlbIjtXk8E-KB2TpHzC` | 33,720 | `8f17dc821aaab2cf9181952a7641fc6c475037b3e1e0291602185aae9bd0f070` | Run parameters and summary cross-check |
| PREDICT-003B | `CGT_PREDICT_003B_coordinates_residualized_context.csv` | `1lSeEFSkZWhdInmKf8UU1NGdPW-RGm7rI` | 1,496,400 | `cafb13a570edaaf04663af4e41b23394ca8c298f3ad417d1a387dc86baad7e81` | PREDICT observation universe and context residual coordinates |
| PREDICT-003B | `CGT_PREDICT_003B_variance_decomposition.csv` | `1FPYXVQMt1LuzOqewzMauMdS6dYUv2TbI` | 617 | `1939ecc04a0210434924bbae4b7f1621e0deb47c23f1f352d2ee1f988188bfd6` | Panel-b variance summaries |
| PREDICT-003B | `CGT_PREDICT_003B_residual_real_vs_controls.csv` | `1QTx4ApcP9j7kyTDDEfyPJwIN59C1KWKk` | 2,545 | `125cfb089a2341dfdc3697f718c6303ce1c8d0476a474619ae06a36cf2443e6d` | Same-label versus shuffled/random controls |
| PREDICT-003B | `CGT_PREDICT_003B_decision_report.csv` | `18mXC2qCfQHumJjsszDQ0YXZ8NX5GwxsN` | 961 | `f2d278b4d6c716809ab98717f1bbe6757c0dca1dbae690fd53bb5571840733f7` | Upstream verdict criteria and R2 boundary |
| PREDICT-003B | `CGT_PREDICT_003B_residual_leave_dataset_out_benchmark.csv` | `1PSvl2IdAKRvmQNasTXx1y6tAPsDUy12x` | 4,512,426 | `bf5157bd943bafbd4cb5e33df023a8873c538b6f7826c56a1b7b5f3732dc0b87` | Leave-dataset-out raw predictions |
| PREDICT-003B | `CGT_PREDICT_003B_residual_excluding_same_study_proxy.csv` | `1O3C0Ld-i6sxW-dMbDzUtHQHx2Nhk6sI8` | 3,746,189 | `0a47ecb336bc5569d44942bb5a5abd99ab72b5ee2a3552f72dc0e69848f7b18b` | Same-study-proxy-excluded raw predictions |
| PREDICT-003B | `CGT_PREDICT_003B_residual_leave_context_out_benchmark.csv` | `1PtVOYSx7ePWuhwnB6PHlaCsFSyhVNnD_` | 1,931,089 | `e6f8c45e03782d0179de9208fe007898127a6aee84656f4d8057742dadd6cf76` | Leave-context-out raw predictions |
| PREDICT-003B | `CGT_PREDICT_003B_per_label_residual_reliability.csv` | `1oAs6c-dp5J3cIzu1tRlA7-P-yLht3Vsl` | 216,127 | `1f5e3a340c5785bbb5105684dc1393904baa77a8863751c85f1cf14413934d4a` | Supplementary repeated-label reliability |

### 2.4 Frozen Figure 2 data product

The original workbook is Drive file `1mpsZkdwF0viHcwgK9sZevVwIrAkzYO34`, 72,946 bytes, SHA-256 `60c9929454e8b2766efb7961b6652a6601e8df47787b97b8092cc76ac0144746`. Its seven sheets match the corresponding original frozen CSV values and ordering. The revised renderer consumes the six original main-panel tables plus one audit-derived denominator table; `FigS2_reliability.csv` is supplementary. The added denominator table is reconstructed directly from the exact upstream leave-dataset benchmark and does not alter an original artifact.

| Frozen table | Rows x columns | SHA-256 | Relation to upstream data |
|---|---:|---|---|
| `Fig2a_contexts.csv` | 8 x 5 | `811b64ed5b59e569f697cfa1ca76c2ce44423c1a3e2e4b568a6118bf24981334` | Group PREDICT coordinate rows by `context`; count rows, datasets, and exact labels |
| `Fig2b_variance.csv` | 3 x 11 | `63c745a260a02f020131cd63e88331a759ed0952ac8711206f9d89ddb641bdeb` | Preserve the three variance rows; add display label and order |
| `Fig2c_context_matrix.csv` | 144 x 5 | `6822f060d9deccb4728541c285ac900ad9883728a56a0263a6dcf7e0e907c63c` | Melt the complete 16-family x 9-context matrix and join score/class by family |
| `Fig2d_recurrence.csv` | 16 x 10 | `5e7661b0c731d52545bad9bad91de83ead7b4e2f03c9cbc08d51be81cf6948fa` | Select all 16 atlas families; add deterministic display-only collision offsets |
| `Fig2e_controls.csv` | 3 x 8 | `c5c45025e50c8fb7a8c7b93a02fc75da2d2a213d824b5185a99e951d3a2a1d00` | Filter to `same_label_residual_shrink`; select real, shuffled-label, and random-label means |
| `Fig2e_same_label_denominators.csv` | 3 x 5 | `ba5712784b1df0cb6f77c7a3df6b5a87438814817cef0772d393738109b28ba1` | Count generated rows, finite cosines, zero true norms, and zero predicted norms by scheme directly from the leave-dataset benchmark |
| `Fig2f_robustness.csv` | 9 x 8 | `a5b395d1494dabce00596d96c9b70cb9fe963463e6a6fe2166d2d28577ead348` | Three residual schemes x three holdouts; row-weighted cluster bootstrap |
| `FigS2_reliability.csv` | 1,254 x 9 | `92bfbe13ba96f1ba3a963814076f3b3c7875c53128a70947c84da564273708a0` | Display subset of the 1,254-row per-label reliability table |

## 3. Archive drift and original-release discrepancies

### 3.1 Stale notebook archives

The later-created archives do not contain the final executed notebooks.

| Archive | Drive ID | ZIP bytes | ZIP SHA-256 | Contained notebook status and SHA-256 |
|---|---|---:|---|---|
| `CGT_FIGURE_002.zip` | `1FcLFKqmf1tstoR7XA4uTBdLjb-R65Dtn` | 21,729 | `9c56ac412db39bc5ec64acc5696e295f813108adbdc87f58fca282a01e5b6576` | Initial 107,943-byte revision; `9ada8b193986e2940993e3f916c6aae95f6be9d210aa21f5a78937d82a652414` |
| `CGT_META_003.zip` | `13jQtbaTH5dnQGcc3X-3ARhxLj1HbSFGH` | 9,180 | `45b357a583bf2eb227a8007d0a1e905c11b07ce7fcecf6190233b020f37dabb8` | Initial revision; `4baa943df7a3428a2b13c722f308d7db47f69297eec58f6d0cff21475ecf2401` |
| `CGT_PREDICT_003B.zip` | `10Q8PEtKFRnSUZtAGNodUIuWrVzg_64zH` | 10,121 | `cd980af8f248c65538c680fcd1b76bc145caf0eb0781826bada1a00579f2a1d3` | Initial revision; `218171c06d82f0cc7cf13fa6ba02e0f22b81f4666c8200265304771552693dd1` |

The Figure notebook revision sequence is 107,943 bytes at 16:11:01.255 UTC, 394,081 bytes at 16:39:01.149 UTC, and the canonical 399,087-byte revision at 18:15:14.792 UTC. The final source changes panel-b annotations/layout, replaces the obsolete panel-d bubble plot with a ranked recurrence panel, and changes the combined GridSpec. Therefore archive drift is scientifically and visually material, not merely a difference in cached outputs.

### 3.2 Original output metadata defects

- The original output manifest is 3,751 bytes but reports 3,675 bytes for itself. This is a self-referential manifest-generation defect. Revised manifests must self-exclude rather than claim a stable digest for themselves.
- The original legend describes panel d as an obsolete bubble plot, while the canonical final notebook renders a ranked bar/point panel.
- The original source manifest names the upstream runs generically but records no exact upstream file digests; the output manifest records byte sizes but no SHA-256 values.
- The original Nature-compliance report records a minimum embedded font of 4.35 pt, below the publication target.
- The website scratch SVG is identical to the Drive SVG for the first 117,117 bytes but has one additional trailing byte. It is semantically the same image but not byte-identical; the Drive object remains the immutable original.

These findings require corrected documentation and a new release manifest. They do not justify altering or deleting the originals.

## 4. Data model, schemas, and row relationships

### 4.1 PREDICT-003B schema

| Artifact | Shape | Essential schema and relationship |
|---|---:|---|
| Context-residual coordinates | 2,720 x 75 | One row per unique `dataset` + raw `perturbation`; identifiers include `dataset`, `context`, `perturbation`, normalized `label`, and prefix-derived `study_group`; measurements include 16 signed and 16 absolute family coordinates plus 16 context baselines, 16 context residuals, and vector norms. The 2,720 rows contain 39 datasets, 8 contexts, 23 study-proxy groups, 2,073 raw perturbation strings, and 2,046 exact normalized labels. |
| Variance decomposition | 3 x 9 | One row per residual scheme (`context`, `dataset`, `dataset_shrink`); raw, baseline, and residual variance totals/fractions plus residual/raw norm summaries. |
| Real versus controls | 12 x 12 | `scheme` x prediction `method` x `control`; includes attempted real/control row counts, cosine means/lifts, legacy Mann–Whitney p-values, and R2 means/lifts. Panel e retains only the primary method and two controls for each scheme. |
| Decision report | 3 x 17 | One row per scheme; criterion flags and verdict plus cosine, R2, shuffle, same-study-proxy, and leave-context summaries. It is provenance, not an independent validation layer. |
| Leave-dataset benchmark | 21,972 x 19 | Prediction-level rows keyed by scheme, held-out dataset, label, perturbation, method, and optional shuffle ID; metrics include cosine, error, R2, true/predicted norms, and top-family match. |
| Same-study-proxy exclusion | 18,462 x 19 | Same prediction schema, with training rows sharing a held-out prefix-derived study proxy removed. |
| Leave-context benchmark | 11,136 x 15 | Prediction-level rows keyed by scheme, held-out context, dataset, label, perturbation, and method. |
| Per-label reliability | 1,254 x 11 | One row per scheme + repeated label; occurrence, dataset, and context counts plus pairwise residual cosine/L2 and norm summaries. |

The coordinate table is unique on `dataset` + `perturbation`. Prediction tables are long-form algorithm evaluations, not independent biological-replicate tables; one held-out observation can appear under multiple methods and, for controls, many shuffle/random IDs.

### 4.2 META-003 schema

| Artifact | Shape | Essential schema and relationship |
|---|---:|---|
| Annotated family atlas | 16 x 40 | One row per unsupervised family. Fields include mode/dataset/context counts and coverage, entropy/effective-count summaries, dominant context, energy summaries, graph recurrence, z-scored components, recurrence and specificity indices, evidence strength, descriptive class, marker genes, post-hoc labels, and display PCA coordinates. |
| Family-context row normalization | 16 x 10 | One `unsup_family` identifier plus nine context-fraction columns. Each family row sums to one; a zero is an observed zero rather than missingness. |
| Underlying mode table | 248 rows | One dataset-specific latent response mode, identified as `dataset::M#`, with dataset, context, energy fraction, gene poles, and an assigned unsupervised family. This table is upstream of the two Figure inputs and defines the META universe. |

Panel c is the complete cartesian 16-family x 9-context melt of the normalized matrix, not a selected subset. Panel d contains all 16 families. `plot_x` and `plot_y` are deterministic collision-avoidance offsets only; scientific counts remain `n_datasets` and `n_contexts`.

## 5. Why the counts are 39/8 in some panels and 43/9 in others

The numbers refer to different upstream products and observation units:

| Universe | Unit | Counts | Figure panels |
|---|---|---|---|
| PREDICT-003B residual analysis | Eligible dataset-perturbation coordinate profile | 2,720 observations; 39 datasets; 8 contexts | a, b, e, f |
| META-003 family atlas | Dataset-specific latent response mode | 248 modes; 43 datasets; 9 contexts; 16 families | c, d |

The PREDICT dataset set is a strict subset of the META set. The four META dataset identifiers absent from PREDICT are `AissaBenevolenskaya2021`, `ChangYe2021`, `SrivatsanTrapnell2020_sciplex2`, and `XieHon2017`; there are no PREDICT-only datasets. The sole META context absent from PREDICT is `compact_screen`.

This is not a display-row collapse, arithmetic error, or stale count. PREDICT operates after its own coordinate availability, label construction, control-like exclusion, and prediction eligibility steps; META summarizes a broader mode atlas. The supplied final Figure inputs do not retain a row-level exclusion ledger that proves which individual eligibility rule removed each of the four datasets. The figure and caption may state that the universes have different upstream eligibility scopes, but must not invent a more specific 43-to-39 filtering mechanism without an additional upstream trace.

## 6. Exact computational definitions

### 6.1 Labels, controls, coordinates, and study proxy

- `label = str(perturbation).strip().upper()`; this is exact normalization, not gene-level alias harmonization.
- A row is excluded as control-like when the uppercase label contains any of: `CONTROL`, `CTRL`, `NON_TARGET`, `NON-TARGET`, `UNTREATED`, `SAFE`, `NEG_`, `NEG-`, `SCRAMBLE`, `MOCK`, or `EMPTY`.
- The coordinate vector is the 16-element absolute family-coordinate vector (`F1_abs` through `F16_abs`; `COORDINATE_MODE="abs"`). Although the input magnitudes are non-negative, subtracting a baseline produces signed residual deviations.
- `study_group` is the dataset identifier prefix before the first underscore. It is a coarse leakage proxy, not a curated study accession or verified laboratory identity.

### 6.2 Residualization

For an observation vector \(x\), context \(c\), and dataset \(d\):

\[
r_{\mathrm{context}} = x - \mathbb{E}[x\mid c]
\]

\[
r_{\mathrm{dataset}} = x - \mathbb{E}[x\mid d]
\]

\[
r_{\mathrm{shrink}} = x - \left(0.75\,\mathbb{E}[x\mid d] + 0.25\,\mathbb{E}[x\mid c]\right).
\]

The dataset-shrinkage baseline is a fixed convex blend, not a fitted hierarchical estimator.

### 6.3 Variance summaries

For coordinate matrix \(X\), total raw variance is

\[
V_{\mathrm{raw}}=\sum_{j=1}^{16}\operatorname{Var}(X_j;\,\mathrm{ddof}=0).
\]

Baseline and residual variances are the analogous coordinate-wise population-variance sums and are divided by the same \(V_{\mathrm{raw}}\). Context and dataset means are group projections and their recorded fractions sum to one up to floating-point precision. Dataset-shrinkage residualization is not orthogonal, so its baseline and residual fractions need not sum to one; the observed values are 0.75645 and 0.05339.

### 6.4 Same-label transfer and controls

For each held-out dataset, training excludes that dataset. For held-out exact label \(\ell\), let \(n\) be the number of same-label training rows and \(\bar r_\ell\) their mean residual vector. The primary prediction is

\[
\widehat r_\ell = \frac{n}{n+2}\bar r_\ell,
\]

provided \(n\ge 1\). The shrink factor is fixed and is not tuned within the held-out split.

- **Label-shuffle control:** within each held-out-dataset training set, permute training labels while keeping residual geometry and other row attributes fixed; 100 shuffles.
- **Random-label control:** choose another training label at random; if its pool is larger than the true label's \(n\), subsample it to \(n\); 100 random controls per eligible held-out observation.
- Upstream PREDICT random operations use `np.random.default_rng(619)` (`RANDOM_STATE=619`).
- **Same-study-proxy exclusion:** start from leave-dataset-out training data, then remove every dataset whose prefix-derived proxy appears among the held-out dataset's proxy values.
- **Leave-context-out:** remove the held-out context from training and form the same-label predictor from the remaining contexts.

Residual-vector cosine is

\[
\cos(r,\widehat r)=\frac{r^\top\widehat r}{\lVert r\rVert_2\lVert\widehat r\rVert_2},
\]

and is undefined (`NaN`) if either norm is zero. Cosine measures direction, not magnitude calibration. The separate upstream `r2_vs_zero` compares squared error with the zero-residual vector.

### 6.5 Family recurrence and descriptive classes

For each family, context coverage is `n_contexts / 9`, dataset coverage is `n_datasets / 43`, effective contexts are \(\exp(H_{\mathrm{context}})\), and normalized context entropy is \(H_{\mathrm{context}}/\log(k)\) for \(k>1\) observed contexts (zero for one context). The function named `robust_z` is not a robust median/MAD score: it median-fills missing values and applies the ordinary SciPy z-score, with zero returned for a constant or all-missing vector.

The upstream index displayed as **recurrence score** is

\[
U=z(\text{context coverage})+z(\text{dataset coverage})+z(\text{effective contexts})+z(\text{normalized context entropy})
+0.5z(\log(1+\text{total energy}))+0.5z(\log(1+\text{incident graph edges})).
\]

The specificity index is

\[
S=z(\text{dominant-context fraction})-z(\text{effective contexts})-z(\text{normalized context entropy})+0.25z(\log(1+\text{total energy})).
\]

The class is assigned by `pandas.cut(U-S, bins=[-inf,-1,1,inf], right=True)`:

- C / `context_specific`: \(U-S\le -1\)
- I / `intermediate`: \(-1<U-S\le 1\)
- B / upstream `universal_candidate`: \(U-S>1\)

The revised B label means **broad-recurrence candidate**, not “universal biological constraint.” The within-family panel-c value is `modes in family/context / all modes in family`; the nine context fractions sum to one for every family.

## 7. Independent reconstruction and uncertainty method

The independent verifier reconstructs the six original main Figure 2 tables plus the audit-derived panel-e denominator table from the exact upstream files rather than trusting notebook cell outputs. It checks column order, row order, strings, shape, and numeric values at `rtol=0` and `atol=1e-12`. All seven renderer inputs pass; maximum absolute numeric differences are 0 for a, b, e, and the denominator table; `4.44e-16` for c and d; and `8.33e-17` for f. The workbook's seven original sheets were separately checked against the corresponding original frozen CSVs. The supplementary reliability table is not independently rederived by the main-figure verifier and should not be represented as such.

Panel-f intervals are regenerated as follows:

1. Filter to `method == "same_label_residual_shrink"` and drop missing cosine values.
2. Cluster by held-out dataset for leave-dataset-out and same-study-proxy exclusion, or by held-out context for leave-context-out.
3. Store each cluster's cosine sum and finite-row count.
4. Resample the same number of clusters with replacement.
5. For each sample, calculate `sum(sampled cluster sums) / sum(sampled cluster counts)`, preserving the observed row weighting.
6. Repeat 4,000 times with a single sequential `np.random.default_rng(1201)` stream in scheme order `context`, `dataset_shrink`, `dataset` and holdout order leave-dataset-out, same-study-proxy exclusion, leave-context-out.
7. Report the direct finite-row mean and the NumPy 0.025 and 0.975 quantiles (default linear quantile interpolation).

These are descriptive percentile cluster-bootstrap intervals conditional on the observed datasets or contexts and on the prefix-based grouping proxy. They do not make the 34, 22, or 7/4 clusters a random sample from a defined biological superpopulation.

## 8. Results and interpretation boundaries

### 8.1 Same-label transfer versus controls

| Residual scheme | Same label | Shuffled label | Random label | Mean R2 vs zero | Interpretation |
|---|---:|---:|---:|---:|---|
| Context | 0.56320 | -0.01997 | -0.01166 | -0.48048 | Strong directional alignment in ordinary leave-dataset-out splits, but worse-than-zero mean squared-error reconstruction |
| Dataset shrink | 0.55798 | -0.01242 | -0.00450 | -0.07928 | Similar directional alignment; magnitude calibration still fails the mean-R2 criterion |
| Dataset | 0.08353 | 0.00360 | 0.00489 | -0.92922 | Weak directional alignment and extensive zero-norm degeneracy |

The legacy `real_n=1,092` field counts attempted primary-method prediction rows per scheme. It is not the number of finite cosines for every scheme. Finite leave-dataset-out cosines are 1,092/1,092 for context and dataset-shrinkage but only 215/1,092 for dataset residuals; in the latter, 815 true residual norms and 723 predicted residual norms are zero. Any caption or accessible description must state that the dataset-scheme cosine is based on 215 finite rows rather than implying 1,092 finite values.

### 8.2 Strict holdouts

| Scheme | Leave dataset out | Exclude same-study proxy | Leave context out |
|---|---:|---:|---:|
| Context residual | 0.5632 [0.3690, 0.7948], 34 groups / 1,092 rows | 0.0350 [-0.0373, 0.0932], 22 / 507 | 0.0794 [0.0480, 0.1278], 7 / 496 |
| Dataset-shrink residual | 0.5580 [0.3647, 0.7846], 34 / 1,092 | 0.0367 [-0.0179, 0.0924], 22 / 507 | 0.0691 [0.0369, 0.1225], 7 / 496 |
| Dataset residual | 0.0835 [0.0238, 0.4088], 6 / 215 | 0.0361 [-0.0198, 0.2554], 4 / 185 | 0.0396 [0.0075, 0.1712], 4 / 201 |

The large drop after same-study-proxy exclusion and leave-context-out evaluation is the central boundary condition. The same-study-proxy intervals include zero for every scheme. Leave-context-out point estimates remain positive, but they are small and supported by only 7, 7, and 4 context clusters. The figure supports recurrence in related data partitions and limited portability; it does not support context-invariant or study-invariant transfer.

## 9. Claim classification

| Claim | Class | Status | Permitted wording | Prohibited extrapolation |
|---|---|---|---|---|
| The PREDICT residual universe contains 2,720 observations across 39 datasets and 8 contexts. | Descriptive identity/count | Verified | Exact count statement tied to PREDICT-003B | Treating these as META mode counts or independent replicates |
| META contains 248 modes across 43 datasets and 9 contexts, grouped into 16 families. | Descriptive upstream summary | Verified | Exact count statement tied to META-003 | Claiming the clustering is uniquely identified or biologically causal |
| Context residualization retains about 52.9% of raw-coordinate variance. | Descriptive preprocessing result | Verified | “Retains 52.9% under this definition” | “52.9% is causal signal” or a general variance partition across cohorts |
| Exact same-label residual vectors have positive directional recurrence in ordinary leave-dataset-out splits. | Predictive association | Supported within scope | “Mean cosine is about 0.56 for context and shrink schemes” | “Accurate prediction,” because mean R2 versus zero is negative |
| Label identity contributes information beyond the two implemented controls. | Algorithmic null comparison | Supported within scope | “Real mean cosine exceeds shuffled- and random-label means” | Treating the controls as independent biological replications or their Mann–Whitney p-values as calibrated permutation inference |
| Portability is limited across study proxies and contexts. | Boundary/robustness claim | Supported | “Transfer attenuates substantially under stricter exclusions” | “No portable signal exists anywhere” or a population-wide null conclusion |
| The recurrence score orders families by breadth, entropy, energy, and graph recurrence. | Descriptive composite | Verified | “Descriptive recurrence score” | “Universality index proves a universal constraint” |
| Recurrent families are causal constraint coordinates or mechanisms. | Causal/mechanistic | Not tested | “Candidate” or “hypothesis” only | Causal, mechanistic, law-like, or intervention-level claims |

No panel establishes causality. No panel validates a biological mechanism. No panel provides an external cohort replication independent of the source atlas and PREDICT pipeline.

## 10. Falsification and alternative-explanation checks

| Competing explanation or stronger claim | Diagnostic prediction | Check/status | Decision |
|---|---|---|---|
| Same-label signal is only an arbitrary label assignment artifact. | Real and label-shuffled performance should be similar. | Performed: shuffled-label means are near zero while context/shrink real means are about 0.56. | This narrow artifact is disfavored under the implemented shuffle. |
| Any other perturbation label would predict equally well because of generic residual direction. | Random-label controls should approach the real mean. | Performed: random-label means are near zero. | Generic random-label transfer is disfavored. |
| Recurrence is broadly portable across independent studies. | Excluding same-study-proxy data should preserve most of the leave-dataset-out signal. | Performed: means fall to about 0.035-0.037, with all intervals crossing zero. | Strong across-study portability is falsified under this proxy definition. |
| Recurrence is context invariant. | Leave-context-out performance should remain near ordinary leave-dataset-out performance. | Performed: means fall to about 0.040-0.079. | Strong context invariance is falsified in the observed universe. |
| Positive cosine implies accurate residual-vector reconstruction. | Mean R2 against a zero residual should be positive. | Performed upstream: mean R2 is negative for all three schemes. | The accuracy claim is falsified; only directional alignment is supportable. |
| Dataset residualization is a stable comparison on the same effective sample. | Most attempted rows should have nonzero true and predicted residual norms. | Checked: only 215/1,092 leave-dataset-out rows have finite cosine; median dataset residual norm is zero. | Dataset-scheme results require explicit missingness/degeneracy qualification. |
| Prefix-before-underscore removes all same-study dependence. | The proxy should match curated study accessions and laboratory batches. | Not performed; proxy is string-derived only. | Residual study leakage may remain, and distinct studies may be over-collapsed. |
| Family recurrence is robust to atlas construction choices. | Family assignments and ranking should persist under clustering seeds, signed coordinates, leave-one-dataset/context recomputation, and alternative score weights. | Not performed in Figure 2. | The family ranking remains descriptive and pipeline-dependent. |
| The result generalizes beyond exact-string labels and source datasets. | A harmonized alias map and external datasets should reproduce the directional transfer. | Not performed. | No claim beyond exact normalized labels and included datasets. |

Priority future falsification tests are: curated study/accession holdouts; leave-one-laboratory and leave-one-platform holdouts; complete re-estimation of residual means within every training fold; alias-aware versus exact-label sensitivity; signed-coordinate replication; family clustering stability across seeds/resamples; and prospective external-dataset replication.

## 11. Limitations that must travel with the figure

1. **Two universes:** panels a/b/e/f and c/d do not share the same dataset/context universe or observation unit.
2. **Eligibility trace:** the available final Figure inputs identify the four absent PREDICT datasets and the absent `compact_screen` context, but not a per-row causal ledger for every exclusion decision.
3. **Exact labels:** uppercasing and trimming do not harmonize aliases, guide suffixes, drug doses, or orthologs; biologically equivalent perturbations can remain separated, and string collisions are possible.
4. **Study proxy:** dataset-prefix grouping is not a curated study identifier.
5. **Cosine versus accuracy:** high cosine can coexist with poor magnitude prediction; mean R2 versus zero is negative for every scheme.
6. **Zero-norm degeneracy:** dataset-mean residualization produces many zero true and predicted residual vectors, so most dataset-scheme cosine values are undefined.
7. **Dependence and null inference:** prediction rows, shuffle rows, and random-label rows are not independent biological replicates. Legacy Mann–Whitney p-values are not displayed or promoted.
8. **Small strict-holdout cluster counts:** leave-context-out intervals use only 7, 7, and 4 clusters; dataset-residual intervals use only 6, 4, and 4 clusters across the three holdouts.
9. **Composite score:** recurrence-score weights and class thresholds are analyst-defined, standardized within 16 families, and not externally calibrated.
10. **Post-hoc biology:** marker-based family names and candidate constraint phrases are interpretive annotations, not mechanism validation.
11. **No causal identification:** the analyses are observational/computational and do not isolate an intervention on a latent constraint variable.
12. **Responsive display:** the two-column composite is uncropped at 480 px, but 7 pt publication text is not comfortably readable at that width. Website integration should provide zoom/open-original behavior or a separately approved mobile derivative.

## 12. Scientific and design decisions for the revised figure

| Decision | Rationale | Consequence |
|---|---|---|
| Use a deterministic renderer over frozen panel CSVs. | Separates visual repair from scientific recomputation and preserves the approved numbers. | Renderer fails rather than silently changing data; upstream recomputation is a separate verification step. |
| State the PREDICT and META universes inside relevant panels/caption. | Prevents 39/8 and 43/9 from appearing contradictory. | Counts are interpreted only within their source universe. |
| Title panel b “Raw-coordinate variance fractions” and use one shared raw denominator. | Avoids implying all residualization schemes are orthogonal decompositions. | Dataset-shrink fractions are shown without a forced sum-to-one visual. |
| Render panel c as vector cells with a separate colorbar and class strip. | Makes zero versus missing explicit and preserves legibility in vector export. | All 144 family-context cells and nine contexts remain visible. |
| Replace “universality” with “descriptive recurrence”; show all 16 families in panel d. | Prevents ontological overstatement and removes selection ambiguity. | Families are ranked by the unchanged upstream score; B/I/C classes are explicitly descriptive. |
| Use unconnected grouped markers in panel e. | The three schemes and controls are categories, not a temporal or dose trajectory. | Same-label and control values can be compared without implying continuity. |
| Omit legacy p-values from panel e. | Row-level tests ignore hierarchical and repeated-control dependence. | The panel communicates effect sizes and control separation, not pseudo-precise significance. |
| Use points and confidence intervals without connecting lines in panel f. | Holdout designs are distinct tests, not ordered stages. | Attenuation and uncertainty are visually primary. |
| Show strict holdouts in the main figure. | They materially delimit the central recurrence claim. | The main conclusion is calibrated to limited portability. |
| Use a 182.88 x 190.50 mm fixed canvas, 600-dpi 4,320 x 4,500 raster, 2,400 x 2,500 web raster, vector PDF/SVG, and 7 pt minimum font. | Meets publication and web-delivery requirements while permitting automated geometry checks. | Downscaled mobile readability requires an open-original/zoom affordance. |
| Use redundant color and form encodings. | Color alone should not carry class, scheme, or control identity. | Color-vision simulations, grayscale, vector, raster, and PDF renders can be independently audited. |
| Pin the document date, SVG hash salt, and 588-byte sRGB ICC profile. | Generated ICC/PDF/SVG metadata otherwise changed byte hashes despite identical pixels and geometry. | Two independent clean renders now produce byte-identical PNG, PDF, SVG, and QA-SVG outputs. |

## 13. Release and citation policy

- Cite the canonical notebook IDs and SHA-256 values above, not only filenames.
- Include the exact frozen source CSVs, workbook, canonical notebooks, verifier, renderer, audit, environment record, and a self-excluding release manifest.
- Preserve the three stale ZIPs and original exports in provenance storage; mark them noncanonical rather than deleting them.
- The website replacement must copy approved assets byte-for-byte, publish a caption and accessible description containing the two-universe and finite-cosine qualifications, provide direct downloads, and verify the rendered page responsively. Website integration is a separate repository task and must not regenerate or optimize the supplied figure assets.
- Any future numerical change requires a new version, new hashes, a rerun of the scientific verifier and visual audit, and an amended decision log. Cosmetic website placement alone must not alter the approved asset bytes.

## 14. Bottom-line claim

Within the PREDICT-003B preprocessing and ordinary leave-dataset-out design, exact same-label residual vectors show reproducible directional alignment for context and dataset-shrinkage residuals, substantially exceeding two implemented label controls. That alignment attenuates sharply after exclusion of a prefix-defined same-study proxy and under leave-context-out transfer, and it does not achieve positive mean R2 against the zero-residual baseline. Separately, META-003 shows that 16 mode families differ descriptively in breadth across a broader 43-dataset, 9-context atlas. The combined evidence supports **recurrent, pipeline-dependent residual geometry with limited observed portability**; it does not establish universal, causal, or mechanistic constraint variables.
