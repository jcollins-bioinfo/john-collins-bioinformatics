**Figure X | Residual perturbation geometry is recurrent across datasets and contexts.**
**a,** Composition of the context-residualized prediction atlas,
comprising 2,720
perturbation observations from
39
datasets and
8
contexts. Bar annotations report the number of contributing datasets and
distinct perturbation labels per context. **b,** Fraction of raw family-
coordinate variance assigned to the residual and baseline components
under context, dataset-shrink and dataset residualization. Fractions need
not sum to one for shrinkage residualization because baseline and residual
components are not constrained to be orthogonal. **c,** Row-normalized
distribution of 248 perturbation modes
across 16 unsupervised families and
9 contexts. Families are ordered by
the META-003 universality index; the left stripe denotes universal-
candidate, intermediate or context-specific classification.
**d,** Family recurrence across datasets and contexts. Bubble area denotes
family mode count and color denotes universality index; small deterministic
offsets separate families with identical counts. **e,** Mean cosine
similarity between held-out perturbation residuals and same-label
residual predictions compared with label-shuffled and random-label
controls. Context and dataset-shrink residuals yielded mean cosines of
0.56 and
0.56, respectively, whereas
both controls were near zero. **f,** Same-label residual transfer under
leave-dataset-out, same-study-proxy exclusion and leave-context-out
evaluation. Points are row-weighted means; error bars are 95% cluster-
bootstrap intervals obtained by resampling held-out datasets or contexts.
