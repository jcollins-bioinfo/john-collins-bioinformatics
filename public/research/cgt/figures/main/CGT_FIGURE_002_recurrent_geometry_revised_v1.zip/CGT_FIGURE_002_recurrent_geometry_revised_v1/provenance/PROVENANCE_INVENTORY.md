# CGT Figure 2 provenance inventory

Inventory date: 2026-08-20 UTC

Scope: canonical and archived notebooks, the finalized `CGT_FIGURE_002` output tree, and the exact `CGT_META_003` / `CGT_PREDICT_003B` inputs read by the canonical Figure 2 notebook. All downloaded files were fetched as raw bytes and preserved unchanged.

## Drive roots and run folders

| Role | Drive ID | URL |
|---|---|---|
| CGT root | `1CZqDmkWTqq4mv53f3cZ8gDqUzUo11gcU` | https://drive.google.com/drive/folders/1CZqDmkWTqq4mv53f3cZ8gDqUzUo11gcU |
| `outputs/CGT_FIGURE_002` | `1qrOrTrJNATwh1zmNbAD0Mo3Wn6QoFgm_` | https://drive.google.com/drive/folders/1qrOrTrJNATwh1zmNbAD0Mo3Wn6QoFgm_ |
| `outputs/CGT_META_003` | `1JrbwEFIcV1nUti3cuEm9JHnMweW_ou0A` | https://drive.google.com/drive/folders/1JrbwEFIcV1nUti3cuEm9JHnMweW_ou0A |
| `outputs/CGT_PREDICT_003B` | `1XV8C0fw2NKAIczQrxb9los1eEx_rredY` | https://drive.google.com/drive/folders/1XV8C0fw2NKAIczQrxb9los1eEx_rredY |
| Colab Notebooks parent | `1PLk8Z6otvIQPbPFirM2LsX4rbA0oZwGa` | https://drive.google.com/drive/folders/1PLk8Z6otvIQPbPFirM2LsX4rbA0oZwGa |

## Canonical notebooks

The final standalone Colab notebooks, rather than the later-created ZIP archives, are the canonical executed versions.

| Run | Drive ID | Modified (UTC) | Bytes | SHA-256 | Local path |
|---|---|---:|---:|---|---|
| `CGT_FIGURE_002` | `1arxGmsJtvJ5M0FTDkNaVfaz_niFCGPHD` | 2026-06-23 18:15:14.792 | 399,087 | `f8046ecb45971bb4d81288af00c0bca5ac2b075e2db6ae1dcd602dbebdf017d8` | `materialized/canonical/CGT-FIGURE-002_recurrent_residual_geometry.ipynb` |
| `CGT_META_003` | `15auKNYoBedbmbGdPFlCXpTWtXkPP509f` | 2026-06-18 21:41:51.923 | 1,202,663 | `1a9cc4a8ec3a777c9cbde34c66227dde26716f40fa765fd4fd08e1b37c978693` | `materialized/canonical/CGT-META-003_universal_constraint_atlas.ipynb` |
| `CGT_PREDICT_003B` | `11GNwA6Lva3wmP_mwGjBx-rauJoOEHZ6M` | 2026-06-20 10:58:54.200 | 767,877 | `d6cd601713b4fab7f5fb01481ea860e0c26bda0b712f3e4bd0169508ea46afb6` | `materialized/canonical/CGT-PREDICT-003B_residual_perturbation_prediction.ipynb` |

Canonical Figure 2 notebook URL: https://colab.research.google.com/drive/1arxGmsJtvJ5M0FTDkNaVfaz_niFCGPHD

The Figure 2 digest exactly matches the expected task digest.

### Revision history and archive drift

The canonical Figure 2 Drive file has three revisions:

| Revision time (UTC) | Bytes | Status |
|---:|---:|---|
| 2026-06-23 16:11:01.255 | 107,943 | initial source revision; retained forever |
| 2026-06-23 16:39:01.149 | 394,081 | intermediate executed revision; retained forever |
| 2026-06-23 18:15:14.792 | 399,087 | current canonical revision |

`notebooks/CGT_FIGURE_002.zip` was created later but contains the **initial 107,943-byte revision**, not the final notebook:

- ZIP Drive ID: `1FcLFKqmf1tstoR7XA4uTBdLjb-R65Dtn`
- ZIP bytes: 21,729
- ZIP SHA-256: `9c56ac412db39bc5ec64acc5696e295f813108adbdc87f58fca282a01e5b6576`
- contained notebook SHA-256: `9ada8b193986e2940993e3f916c6aae95f6be9d210aa21f5a78937d82a652414`

The difference is substantive, not only cell outputs. The final notebook changes panel-b annotation/layout logic, replaces the panel-d bubble plot with a ranked recurrence panel, and changes the combined GridSpec. The archive copy must not be used as the canonical renderer.

The same initial-revision packaging pattern affects the upstream archives:

| Archive | Drive ID | ZIP SHA-256 | Contained initial-notebook SHA-256 |
|---|---|---|---|
| `CGT_META_003.zip` | `13jQtbaTH5dnQGcc3X-3ARhxLj1HbSFGH` | `45b357a583bf2eb227a8007d0a1e905c11b07ce7fcecf6190233b020f37dabb8` | `4baa943df7a3428a2b13c722f308d7db47f69297eec58f6d0cff21475ecf2401` |
| `CGT_PREDICT_003B.zip` | `10Q8PEtKFRnSUZtAGNodUIuWrVzg_64zH` | `cd980af8f248c65538c680fcd1b76bc145caf0eb0781826bada1a00579f2a1d3` | `218171c06d82f0cc7cf13fa6ba02e0f22b81f4666c8200265304771552693dd1` |

Both ZIPs and their extracted contents remain preserved under `archives/` and `materialized/archives/` as provenance records.

## Finalized Figure 2 source data and exports

| Artifact | Drive ID | Bytes | SHA-256 |
|---|---|---:|---|
| Source Data workbook | `1mpsZkdwF0viHcwgK9sZevVwIrAkzYO34` | 72,946 | `60c9929454e8b2766efb7961b6652a6601e8df47787b97b8092cc76ac0144746` |
| Main PNG | `1RlOpcVD2zJvEpAalmKRf7RJ2sf_xs8bS` | 1,015,630 | `39683bf1c8d03438d24585a155cfb212804a4aa2045f137b2835ed5cef376477` |
| Main PDF | `1v8qSI0NNeaXoneoCp9AdJv6rBfQ4aCjZ` | 45,198 | `3c08a83d61369028b924795b537d506aa8d358542488d53db0994c011d0e5656` |
| Main SVG | `1gGPfCwArnjoOzoqbcYG2OIiYCo_DHfpv` | 117,117 | `6a2b3803b7d8596ca623b2a8d54ba15a87eb2f62202f20eff851a04645322ca9` |
| Metrics JSON | `1sJQEY1-vMEVq44sdxsiEcy5QWbvdgJBZ` | 432 | `e27b2b74fcf05d1ae7753d5f84e1ba209c63e82ed7c78d209d5a80116282bfff` |
| Output manifest | `1hppKSmAE0J1qAh_JpvwHhvRSQaio_pKT` | 3,751 | `2689ac1b84d00bd32cfe828bdc781ce06289f680769d4f603266f1c5da7c6d14` |

The task-provided current PNG digest is confirmed exactly. The website SVG available in the scratch workspace is byte-identical to the Drive SVG for the first 117,117 bytes and adds one trailing byte (apparently a final newline), producing website-copy SHA-256 `6f1b794b0b48f29262f3f978e8e69236c9728dad06a9f21b363832fa605737a4`.

All main, individual-panel, and supplementary PNG/PDF/SVG exports were materialized under `materialized/CGT_FIGURE_002/`.

## Exact upstream inputs read by the canonical Figure 2 notebook

| Run | Drive ID | Filename | Local path |
|---|---|---|---|
| META-003 | `1MnAKvPEo3UuZfSYmma4M8Un-FUXkYCJE` | `CGT_META_003_summary_report.json` | `materialized/CGT_META_003/` |
| META-003 | `1gHCbd0r4Ylp55KM_9fDpkEzC5jY7oy9i` | `CGT_META_003_universal_constraint_atlas_annotated.csv` | `materialized/CGT_META_003/` |
| META-003 | `1_wgKRRws60hJQc5_5mas5_aeOnI6oANv` | `CGT_META_003_family_context_row_normalized.csv` | `materialized/CGT_META_003/` |
| PREDICT-003B | `1PD-MxUqab_RXTVlbIjtXk8E-KB2TpHzC` | `CGT_PREDICT_003B_summary_report.json` | `materialized/CGT_PREDICT_003B/` |
| PREDICT-003B | `1lSeEFSkZWhdInmKf8UU1NGdPW-RGm7rI` | `CGT_PREDICT_003B_coordinates_residualized_context.csv` | `materialized/CGT_PREDICT_003B/` |
| PREDICT-003B | `1FPYXVQMt1LuzOqewzMauMdS6dYUv2TbI` | `CGT_PREDICT_003B_variance_decomposition.csv` | `materialized/CGT_PREDICT_003B/` |
| PREDICT-003B | `1QTx4ApcP9j7kyTDDEfyPJwIN59C1KWKk` | `CGT_PREDICT_003B_residual_real_vs_controls.csv` | `materialized/CGT_PREDICT_003B/` |
| PREDICT-003B | `18mXC2qCfQHumJjsszDQ0YXZ8NX5GwxsN` | `CGT_PREDICT_003B_decision_report.csv` | `materialized/CGT_PREDICT_003B/` |
| PREDICT-003B | `1PSvl2IdAKRvmQNasTXx1y6tAPsDUy12x` | `CGT_PREDICT_003B_residual_leave_dataset_out_benchmark.csv` | `materialized/CGT_PREDICT_003B/` |
| PREDICT-003B | `1O3C0Ld-i6sxW-dMbDzUtHQHx2Nhk6sI8` | `CGT_PREDICT_003B_residual_excluding_same_study_proxy.csv` | `materialized/CGT_PREDICT_003B/` |
| PREDICT-003B | `1PtVOYSx7ePWuhwnB6PHlaCsFSyhVNnD_` | `CGT_PREDICT_003B_residual_leave_context_out_benchmark.csv` | `materialized/CGT_PREDICT_003B/` |
| PREDICT-003B | `1oAs6c-dp5J3cIzu1tRlA7-P-yLht3Vsl` | `CGT_PREDICT_003B_per_label_residual_reliability.csv` | `materialized/CGT_PREDICT_003B/` |

The summary variants needed for cross-checks were also materialized.

## Verification results

1. All seven finalized source CSVs were independently regenerated from the exact upstream inputs using the canonical notebook's transformations and fixed seed (`RANDOM_STATE = 1201`, 4,000 cluster-bootstrap iterations). Every table matched the frozen CSV at `rtol = atol = 1e-12`:
   - `Fig2a_contexts`: 8 rows × 5 columns
   - `Fig2b_variance`: 3 × 11
   - `Fig2c_context_matrix`: 144 × 5
   - `Fig2d_recurrence`: 16 × 10
   - `Fig2e_controls`: 3 × 8
   - `Fig2f_robustness`: 9 × 8
   - `FigS2_reliability`: 1,254 × 9
2. Each of the seven workbook sheets matches its corresponding CSV, including values and ordering.
3. The apparently inconsistent analysis counts have a traceable origin:
   - PREDICT-003B residual-analysis universe: 2,720 observations, 39 datasets, 8 contexts.
   - META-003 family-atlas universe: 248 modes, 43 datasets, 9 contexts, 16 families.
   These are different upstream universes, not a numerical recomputation error. The current figure/caption does not distinguish them as clearly as a publication-ready redesign should.
4. The output manifest has 43 entries. All reported byte counts match the materialized files except its self-entry: it reports 3,675 bytes for `CGT_FIGURE_002_output_manifest.csv`, while the final file is 3,751 bytes. This is a self-referential manifest-generation defect.
5. The final legend is stale relative to the canonical renderer: it describes panel d as a bubble plot whose area encodes family size and color encodes the universality index, but the final notebook renders a ranked horizontal recurrence panel with bars and rescaled dataset/context point tracks.
6. The source manifest identifies upstream runs only generically (`CGT_META_003 and CGT_PREDICT_003B`) and records no upstream file digests. The existing output manifest records byte sizes but no SHA-256 digests.
7. The Nature compliance report itself records failure of the font-size requirement: minimum embedded font size 4.35 pt.

## Local handoff

- Canonical notebooks: `materialized/canonical/`
- Preserved ZIP archives: `archives/`
- Extracted stale archive contents: `materialized/archives/`
- Complete finalized Figure 2 output tree: `materialized/CGT_FIGURE_002/`
- Exact upstream dependencies: `materialized/CGT_META_003/` and `materialized/CGT_PREDICT_003B/`
- Full local hashes: `SHA256SUMS.txt`
- Byte/path inventory: `LOCAL_FILE_MANIFEST.tsv`

Use the standalone canonical notebooks for source-level reconstruction. Retain the archives only as provenance evidence of the initial revisions.
