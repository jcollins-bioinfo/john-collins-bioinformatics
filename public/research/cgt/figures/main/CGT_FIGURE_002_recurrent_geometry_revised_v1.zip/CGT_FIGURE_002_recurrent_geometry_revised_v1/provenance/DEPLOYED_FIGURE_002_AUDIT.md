# Deployed-main audit: CGT Figure 2

Audit date: 2026-08-20 UTC  
Repository: `jcollins-bioinfo/john-collins-bioinformatics`  
Audited branch/head: `main` at `19b14b196980177e2778dd7a7392a9c1f0e331e6`  
Scope: current repository implementation, deployed asset triplet, website copy, accessibility text, manifest metadata, and repository tests. This was a read-only audit. It does **not** independently validate the notebook, workbook, upstream tables, or numerical estimands.

## Bottom line

The current Figure 2 is not publication-ready. The manifest's characterization of the remaining work as `minor_polish`, with only a 4.35-pt minimum-font warning, is materially incomplete. The source SVG and an independent Inkscape render show several hard collisions, an internally ambiguous color encoding, an underspecified analysis-universe change, and captions that selectively foreground the two successful residualization schemes while omitting the weak dataset-residual result.

The most serious concrete defects are:

1. Panel b's panel letter, title, and `0.53/0.47` annotation overlap; its legend also covers the `0.98` annotation and baseline point.
2. Panel d's legend intersects six `datasets / contexts` count labels.
3. The panel-c colorbar/tick region collides with panel e's y-axis title.
4. Panel d uses the same blue for both `datasets` and `universal candidate`, and the same orange for both `contexts` and `context-specific`.
5. The figure contains text down to 4.35 pt and is uniformly downscaled on mobile, making the smallest text approximately 3.7 CSS pixels at an intended 444-pixel image width.
6. Panels e and f connect categorical controls or non-nested evaluation regimes, implying trajectories that the deployed copy does not establish.

## Frozen baseline and integrity

The GitHub API and independently decoded repository bytes agree with the manifest for all three active assets.

| Asset | Bytes | SHA-256 | Git blob | Metadata |
|---|---:|---|---|---|
| PNG | 1,015,630 | `39683bf1c8d03438d24585a155cfb212804a4aa2045f137b2835ed5cef376477` | `2ad110208d1b71adab386cadd3821503d2d4026a` | 4,322 × 4,015 px; 8-bit RGBA; non-interlaced; pHYs = 23,622 px/m = 599.9988 dpi; Matplotlib 3.10.0 |
| PDF | 45,198 | `3c08a83d61369028b924795b537d506aa8d358542488d53db0994c011d0e5656` | `8e4e213a36597706f56e08bd60e196de7e3bbee8` | PDF 1.4; MediaBox 518.7401574803 × 481.8897637795 pt; embedded subset Liberation Sans and Liberation Sans Bold; Matplotlib 3.10.0 |
| SVG | 117,117 | `6a2b3803b7d8596ca623b2a8d54ba15a87eb2f62202f20eff851a04645322ca9` | `fe80752d4b9a7832bec181d80accb2c0c9681c9c` | 518.740157 × 481.889764 pt = 183 × 170 mm; matching viewBox; Matplotlib 3.10.0 |

The SVG uses live text with `font-family: 'Liberation Sans'`; it does not embed the font or convert text to outlines. Browser font substitution can therefore change vector-label geometry. The PDF embeds subset fonts; the displayed PNG is geometrically stable.

Read-only baseline files retained beside this report:

- `baseline/figure-02-recurrent-geometry.svg`: byte-exact repository SVG.
- `baseline/figure-02-recurrent-geometry-rendered.png`: independent 2,400-pixel-wide Inkscape render.
- `baseline/panel-b-crop.png`, `baseline/panel-d-crop.png`, `baseline/panel-c-labels-crop.png`, and `baseline/panel-c-e-interface-crop.png`: native-render audit crops.

## Exact implementation path

- [`content.ts`, lines 143–167](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/app/research/cgt/content.ts#L143-L167) defines Figure 2's title, asset paths, PNG dimensions, alt text, accessible description, caption, notebook hash, upstream runs, freeze status, and QA note.
- [`publication-components.tsx`, lines 29–123](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/app/research/cgt/publication-components.tsx#L29-L123) displays the PNG, links it to the SVG, and falls back to generic PDF/SVG/PNG downloads because Figure 2 has no `releaseAssets` array.
- [`publication.module.css`, lines 373–408](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/app/research/cgt/publication.module.css#L373-L408) uniformly scales the image to `width: 100%; height: auto`.
- [`manifest.json`, lines 359–470](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/public/research/cgt/figures/manifest.json#L359-L470) records the Figure 2 assets, dimensions, provenance, `minor_polish` status, and only a minimum-font warning.
- [`manifest.json`, lines 118–123](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/public/research/cgt/figures/manifest.json#L118-L123) repeats the incomplete QA summary.
- [`rendered-html.test.mjs`, lines 411–503](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/tests/rendered-html.test.mjs#L411-L503) is the only figure-asset test relevant to Figure 2.

## Publication-blocking visual defects

### 1. Panel b has four distinct collisions

Relevant SVG source: [`figure-02-recurrent-geometry.svg`, lines 479–614](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/public/research/cgt/figures/main/figure-02-recurrent-geometry.svg#L479-L614).

Inkscape `--query-all` bounding boxes, measured in its 96-dpi query coordinate system, establish:

- Panel letter `b` overlaps the title by 2.692 × 3.564 px (about 2.019 × 2.673 pt in the SVG coordinate system).
- The title overlaps the `0.53/0.47` annotation by 26.182 × 2.882 px (about 19.637 × 2.162 pt).
- The legend group intersects the `0.98` annotation; the actual `residual` legend text overlaps `0.98` by 5.445 × 1.913 px.
- The legend group also intersects the gray baseline point at `0.98`.

This is not a near miss or an audit artifact; all four defects are visible in the independent raster crop. The bottom `res.` and `base.` labels also sit below the data rectangle immediately adjacent to the x-axis tick labels, leaving inadequate clearance.

### 2. Panel d's legend overwrites its count gutter

Relevant SVG source: [`figure-02-recurrent-geometry.svg`, lines 1121–1314](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/public/research/cgt/figures/main/figure-02-recurrent-geometry.svg#L1121-L1314).

The legend bounding box is x = 600.064–668.586 and y = 106.344–145.514 in Inkscape query coordinates. It intersects six right-gutter count labels (`1 ds / 1 ctx`): five labels across their full text height and a sixth partially. The collision is visually severe and renders multiple count strings illegible.

The panel also assigns colors ambiguously **within the same legend**:

- dark blue circle = datasets;
- blue square = universal candidate;
- orange circle = contexts;
- orange square = context-specific.

Shape technically distinguishes the encodings, but the same hues represent unrelated variables simultaneously. This violates a basic cross-panel and within-panel semantic-color invariant.

### 3. The panel-c colorbar and panel-e y-axis do not have a valid gutter

Relevant SVG source: [`figure-02-recurrent-geometry.svg`, lines 1680–1937](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/public/research/cgt/figures/main/figure-02-recurrent-geometry.svg#L1680-L1937).

Panel e's vertical title `Mean residual-vector cosine` intersects four panel-c colorbar tick labels (`0.2`, `0.4`, `0.6`, and `0.8`) in the Inkscape text-bounds audit. The separate vertical titles `Fraction of family modes` and `Mean residual-vector cosine` have only about 2.44 pt of horizontal clearance. The independent raster crop confirms that the interface is crowded and visually entangled.

Panel c's 35-degree x labels are also too densely packed. Axis-aligned rendered bounds intersect for several neighboring long labels (`T cell`, `Compact screen`, `Drug / cancer`, `Epithelial cancer`, `iPSC / neuron`, and `Immune cancer`). The native raster keeps most glyphs barely distinguishable, so this is best described as a clearance failure rather than claiming every bounding-box intersection is a literal glyph collision. A reconstructed layout needs more width or a dedicated label gutter.

### 4. Typography fails both physical-size and responsive-use criteria

The SVG contains:

- 4.35-pt `res.` / `base.` labels;
- 4.6-pt colorbar ticks;
- 4.75-pt count annotations;
- 4.8-pt numerical annotations;
- 5.2-pt ticks and legends;
- 6.25-pt axis titles;
- 7-pt panel titles.

This is not repaired by offering a full-resolution download. The website displays a uniformly scaled bitmap. From the SVG geometry, a 4.35-pt label is approximately:

| Intended display width | Approximate rendered label height |
|---:|---:|
| 1,320 px | 11.1 px |
| 800 px | 6.7 px |
| 584 px | 4.9 px |
| 444 px | 3.7 px |

The mobile result is intrinsically unreadable. Raising the print minimum to 7 pt alone would still yield only about 6.0 px at 444 px wide; a panel-grouped or reflowed mobile asset is therefore needed if mobile legibility is an acceptance criterion.

### 5. Categorical lines imply unsupported trajectories

- Panel e connects `same label`, `label shuffled`, and `random label` within each residualization scheme. These are categorical estimands/null controls, not an ordered continuum.
- Panel f connects `Leave dataset out`, `Exclude same-study proxy`, and `Leave context out`. The latter conditions are not shown to be a single nested or paired sequence. `Leave context out` is a different transport problem, not simply the next scalar level of stringency.

The lines visually assert ordered trajectories and should be removed unless the source analysis establishes a paired estimand and the caption states it.

## Scientific and semantic audit

### Observed and directly supported by the deployed artifact

- Panel a/page copy reports 2,720 perturbation observations from 39 datasets and 8 contexts.
- Panels c–d/page copy report 248 perturbation modes from 43 datasets and 9 contexts across 16 families.
- Panel c includes `Compact screen`, which panel a does not.
- Panel e displays strong same-label cosine for context and dataset-shrink residuals (about 0.56) but weak dataset-residual performance (about 0.08).
- Panel f displays strong leave-dataset-out values for context and dataset-shrink residuals, followed by much smaller values under study-proxy and context exclusions.
- The content caption reports only context-residual point estimates for panel f and only the two strong same-label schemes for panel e.

### Inference that must be verified from source

The exact +1 context difference between panels a and c–d is visibly consistent with the addition of `Compact screen`. The +4 dataset difference may also be attributable to that context. This is a plausible inference, not demonstrated by the deployed figure or copy; the workbook/notebook must confirm it.

### Unresolved scientific definitions and denominators

1. **Analysis universes.** The page states 39/8 and 43/9 but never explains why the universes differ, what eligibility filter defines each, or whether observations can contribute to one panel but not another.
2. **Universality index.** The axis formula, range, normalization, null, and interpretation are absent. The caption calls the panel recurrence while the axis says universality; biological universality is not identified by recurrence within the sampled atlas.
3. **Heatmap cells.** `Fraction of family modes` does not identify the denominator or whether rows, columns, or another grouping sum to one. Missing cells and structural zeros are not distinguished.
4. **Family classes.** `universal candidate`, `intermediate`, and `context-specific` are called descriptive, but their thresholds, ranking rule, tie handling, and robustness are absent.
5. **Panel-b fractions.** The displayed dataset-shrink pair is 0.05 residual and 0.76 baseline, which sums to 0.81 rather than one. Therefore the two quantities are not evidently exhaustive variance partitions. Any stacked/compositional rendering would be false unless the missing component/cross-term and denominator are defined.
6. **Null controls.** The distinction between `label shuffled` and `random label`, their repetition counts, sampling units, and uncertainty are absent from the figure and page caption.
7. **Bootstrap intervals.** The caption says 95% cluster-bootstrap intervals from 4,000 resamples but does not identify the cluster unit, weighting, seed, or whether the intervals target means across labels, datasets, studies, contexts, or folds.
8. **Evaluation unit.** Neither panels e/f nor the caption gives the number of held-out labels, datasets, studies, contexts, or effective independent units behind each point.

### Claim framing problems

1. The manifest title is `Residual perturbation geometry is recurrent across datasets and contexts` ([line 365](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/public/research/cgt/figures/manifest.json#L365)), while the live content title is `Residual perturbation geometry recurs in related datasets but attenuates under context transfer` ([line 145](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/app/research/cgt/content.ts#L145)). The manifest title conflates recurrence among represented contexts with transport to unseen contexts and is difficult to reconcile with the reported leave-context-out mean of 0.079.
2. `related datasets` is not defined. If it includes same-study proxies, it can obscure study leakage rather than describe genuine transport.
3. The alt text calls the tests `increasingly strict`, but the three panel-f regimes are not established as a nested ordinal sequence.
4. The panel-e caption foregrounds 0.563 and 0.558 but omits the approximately 0.08 dataset-residual same-label result. The panel-f caption similarly gives only context-residual values. Because residualization choice is a dominant sensitivity parameter, the omission makes the prose more favorable than the complete visual evidence.
5. The two near-zero controls do not establish biological recurrence independently; they only reject the particular null constructions used, conditional on preprocessing and split design.

The defensible claim envelope is therefore: **preprocessing- and split-dependent same-label predictive association within the represented atlas, with substantial attenuation under study-proxy and context exclusions.** The deployed asset does not identify a context-general mechanism or universal biological law.

## Accessibility and delivery defects

1. The `accessibleDescription` at [`content.ts`, lines 153–154](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/app/research/cgt/content.ts#L153-L154) describes essentially panels e–f. It omits panels a–d, the 39/8 versus 43/9 universe change, the family heatmap/ranking, panel-b variance fractions, and the weak dataset-residual result.
2. Figure 2 has no `releaseAssets`, so the page exposes only generic `Download PDF`, `Open vector SVG`, and `Open 600-dpi PNG` links. It does not display the PDF/SVG filenames, byte counts, hashes, dimensions, or a reproducibility package as Figure 1 does.
3. Only the PNG hash is rendered in the provenance details. The SVG and PDF hashes exist only in the manifest.
4. The component sets `unoptimized` and serves the full 1,015,630-byte 4,322 × 4,015 PNG at all widths. No web-sized or mobile panel-grouped asset is supplied.
5. The linked SVG depends on locally available Liberation Sans. Font substitution can worsen the already-failing text geometry.

## Test-coverage audit

The current test suite does **not** protect Figure 2's scientific copy, layout, or byte integrity.

What [`rendered-html.test.mjs`, lines 411–503](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/tests/rendered-html.test.mjs#L411-L503) does:

- checks that every PNG/PDF/SVG path exists;
- checks that figures 2–11 have a truthy manifest SHA-256 string;
- performs exact file SHA-256 comparisons only for Figure 1 release assets and aliases.

What it does not do for Figure 2:

- recompute PNG/PDF/SVG hashes and compare them with the manifest;
- verify byte counts, dimensions, DPI, MIME types, PDF page size/fonts, or SVG viewBox/resources;
- assert the Figure 2 title, caption, alt text, accessible description, dimensions, source run, notebook hash, or download links in rendered HTML;
- verify agreement between `content.ts` and `manifest.json`;
- render the SVG/PDF/PNG and test clipping, overlap, minimum font size, or downscaled readability;
- exercise desktop/tablet/mobile viewport rendering;
- verify that downloads return expected bytes and content types.

`npm run build` only validates that the built worker exposes `default.fetch`; [`scripts/validate-artifact.mjs`](https://github.com/jcollins-bioinfo/john-collins-bioinformatics/blob/19b14b196980177e2778dd7a7392a9c1f0e331e6/scripts/validate-artifact.mjs) does not inspect figure assets.

## Replacement acceptance criteria derived from this audit

At minimum, a replacement should hard-fail unless all of the following are true:

1. no panel-label/title, title/annotation, legend/text, legend/data, colorbar/neighbor-axis, or outer-canvas collisions;
2. minimum final-size font is at least 7 pt, with a separately legible mobile presentation rather than a single dense composite shrunk to phone width;
3. residualization schemes and family classes use disjoint semantic palettes, with controls differentiated by marker shape and neutral styling;
4. panels e/f do not connect categorical/non-nested conditions without a documented paired estimand;
5. panel-a and panels-c/d universes are reconciled or explicitly named and explained;
6. recurrence score/index, heatmap denominator, family-class thresholds, null-control construction, evaluation units, and bootstrap cluster unit are defined;
7. captions and accessible description report all material preprocessing sensitivities, including the weak dataset-residual result;
8. web copy and manifest use identical, scope-correct titles and metadata;
9. PNG/PDF/SVG byte counts and SHA-256 values are recomputed in tests, not merely populated;
10. rendered-page tests verify desktop/tablet/mobile appearance and exact download integrity.

## Limitations of this audit

This audit establishes defects in the deployed representation and repository safeguards. It cannot determine whether the displayed statistics are numerically correct, why the two analysis universes differ, how the recurrence index is computed, or whether bootstrap intervals are valid without the canonical notebook, frozen source data, methods, and upstream manifests. Those remain mandatory source-level checks before the figure can be described as scientifically audited.
