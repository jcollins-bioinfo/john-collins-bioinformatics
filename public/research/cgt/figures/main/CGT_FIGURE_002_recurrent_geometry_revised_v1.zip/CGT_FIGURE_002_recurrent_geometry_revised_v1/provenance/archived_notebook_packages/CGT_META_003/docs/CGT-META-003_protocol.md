# CGT-META-003 Protocol — Universal Constraint Atlas

## Motivation

META-002 showed a strong family-level signal:
- Family 14 was highly universal across many datasets and contexts.
- Family 12 was strongly context-specific, apparently K562/erythroid.
- The superfamily hierarchy was not yet clean, likely because max-linkage overconnected families.

META-003 therefore avoids fragile hierarchy claims and focuses on the robust object:
family-level universality.

## Core questions

1. Which perturbation-response families are most universal?
2. Which are most context-specific?
3. Which families carry the most perturbation-mode energy?
4. Which marker genes define each family's polarity?
5. What candidate biological constraint axis does each family represent?

## Metrics

For each family:
- number of modes
- number of datasets
- number of contexts
- context entropy
- effective contexts
- dominant context fraction
- total energy
- mean energy
- graph degree / recurrence
- marker-gene recurrence

Composite scores:
- universality_index
- specificity_index
- evidence_strength

## Interpretation

Universal families are candidate general cellular constraints.
Context-specific families are candidate lineage/state-specific constraints.
