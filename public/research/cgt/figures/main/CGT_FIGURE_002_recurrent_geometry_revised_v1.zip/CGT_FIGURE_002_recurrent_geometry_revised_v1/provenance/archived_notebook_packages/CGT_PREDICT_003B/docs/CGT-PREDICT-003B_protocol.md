# CGT-PREDICT-003B Protocol

PREDICT-003 found that raw CGT family-coordinate prediction is dominated by dataset/context structure. This notebook tests residual prediction.

For each coordinate vector y:
- context residual: y - E[y | context]
- dataset residual: y - E[y | dataset]
- dataset_shrink residual: y - (0.75*E[y|dataset] + 0.25*E[y|context])

Main benchmark: leave one dataset out, predict held-out residual vectors from same-label residuals in training datasets, and compare to zero residual, shuffled labels, random labels, same-study proxy exclusion, and leave-context-out tests.

Interpretation: if same-label residual prediction beats zero and shuffled controls, perturbation identity carries information beyond context/dataset structure.
