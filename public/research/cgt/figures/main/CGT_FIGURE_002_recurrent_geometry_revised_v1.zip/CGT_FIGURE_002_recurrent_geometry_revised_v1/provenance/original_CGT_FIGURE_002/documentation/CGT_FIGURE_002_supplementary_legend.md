**Supplementary Figure X | Repeated-label residual reliability depends on context breadth.**
**a,** Median pairwise residual-vector cosine for perturbation labels
represented in at least two datasets but only one biological context.
**b,** The same statistic for labels represented across at least two
contexts. Violins show the distribution across labels; horizontal lines
show medians and points show individual labels. The contrast defines an
important limitation: high within-context recurrence does not imply
equally strong transport across contexts.
