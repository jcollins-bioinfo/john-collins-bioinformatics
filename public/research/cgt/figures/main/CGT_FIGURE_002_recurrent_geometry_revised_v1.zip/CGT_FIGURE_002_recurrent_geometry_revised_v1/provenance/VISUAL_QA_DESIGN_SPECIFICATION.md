# Figure 2 independent visual audit and QA design

## Scope and status

This is a read-only audit of the deployed `figure-02-recurrent-geometry.svg` and a design/QA specification for its replacement. It does not modify the source notebook, frozen data, canonical release, or website repository. The baseline was rendered independently with Inkscape at 2,400 px wide and inspected at 2,400, 1,200, 800, and 480 px.

## Independent findings in the current SVG

The current canvas is exactly `518.740157 × 481.889764 pt`, or `183.000 × 170.000 mm`. It is not merely suffering from one or two accidental label placements; the three-panel top row and the shared middle-row boundary are structurally too tight for the amount of information shown.

### Measured defects

Post-layout bounds below were obtained with Inkscape `--query-all`, then converted from CSS px to final-size points using `72/96`. These are actual SVG-renderer bounds, not inferred Matplotlib axes bounds.

| Defect | Measured result | Consequence |
|---|---:|---|
| Panel-b letter `b` versus title | Intersection `2.019 × 2.673 pt` | The letter is visibly embedded in the title. |
| Panel-b title versus `0.53/0.47` annotation | Intersection `19.637 × 2.162 pt` | The top numerical result is unreadable. |
| Panel-b legend versus `0.98` annotation | Intersection `5.436 × 3.581 pt` | The bottom estimate and legend merge. |
| Panel-d legend versus right count gutter | The legend intersects six count labels (`F15`, `F13`, `F8`, `F7`, `F4`, and `F2`) | Several `datasets / contexts` counts are partly covered. |
| Panel-c colorbar label versus panel-e y-axis label | Only `2.439 pt` horizontal edge clearance over a shared vertical span of `55.676 pt` | The two vertical labels visually read as one overprinted phrase even though their bare glyph boxes narrowly avoid intersection. |

The six count-label collision is particularly important: a legend with a white background was placed above already-rendered annotations, so a text-only overlap check can miss the resulting occlusion.

### Typography and semantics

The SVG contains 164 text objects. Its declared final-size text distribution is:

| Font size | Objects |
|---:|---:|
| 4.35 pt | 6 |
| 4.60 pt | 6 |
| 4.75 pt | 24 |
| 4.80 pt | 5 |
| 5.20 pt | 106 |
| 6.25 pt | 5 |
| 7.00 pt | 6 |
| 8.00 pt | 6 |

Thus 147 of 164 text objects are below 6 pt and all but the panel labels/titles are below the proposed 7 pt minimum. The current SVG also requests `Liberation Sans` without embedding it; this environment substitutes another font, so text extents are not portable.

Additional observed defects:

- Panel a uses floating count strings rather than a reserved count column and renders grammatically incorrect labels such as `1 datasets`.
- Panel b uses abbreviated `res.`/`base.` labels and a connector that can suggest an exhaustive variance decomposition even though the dataset-shrinkage values do not sum to one.
- Panel c's family-class strip has no local column header, and its heatmap, long context labels, colorbar, class key, and adjacent panel-e y label compete for the same narrow boundary.
- Panel d redundantly plots dataset/context counts and repeats them as text, necessitating a legend that then obscures the count text. `Universality index` is also a stronger label than the visual evidence alone supports.
- Panel e connects three categorical control conditions into triangular paths; panel f connects three categorical exclusion designs into trajectories. Neither connection should survive unless the scientific audit establishes a paired/ordered estimand.
- The same blue/gray/orange hues encode residualization schemes, control types, and family classes in different panels.
- Panel a visibly summarizes eight contexts/39 datasets, while panels c/d summarize nine contexts/43 datasets; the additional `Compact screen` context is visible only in panel c. The replacement must reconcile or explicitly label these universes.

### Downscale reality

At a 480 px display width, a 7 pt label on a 518.4 pt-wide composite is only `7 × 480 / 518.4 = 6.48 px` high before rasterization. The current 4.35 pt labels fall to about 4.0 px. Therefore a full six-panel desktop composite cannot be honestly declared readable at 480 px, even if it is geometrically collision-free. The 480 px check should catch clipping, merger, and structural failure; mobile legibility requires either a separately approved one-column derivative, zoom/open-original behavior, or panel-level responsive images.

## Exact replacement layout

### Canvas and grid

Use a `7.2 × 7.5 in` canvas: exactly `518.4 × 540.0 pt` = `182.88 × 190.50 mm`. This is effectively the requested 183 mm publication width while producing integer raster dimensions at 600 dpi and at the 2,400 px web width:

- publication PNG: exactly `4320 × 4500 px` at 600 ppi;
- web PNG: exactly `2400 × 2500 px`;
- PDF MediaBox: exactly `518.4 × 540.0 pt`;
- SVG: `width="182.88mm"`, `height="190.50mm"`, `viewBox="0 0 518.4 540"`.

Use the following layout contract in top-origin final-size points:

| Region | x range (pt) | y range (pt) | Size (pt) |
|---|---:|---:|---:|
| Left column | 28.0–254.2 | — | 226.2 wide |
| Inter-column gap | 254.2–276.2 | — | 22.0 wide |
| Right column | 276.2–502.4 | — | 226.2 wide |
| Row 1: panels a/b | — | 18.0–138.0 | 120.0 high |
| Row gap 1 | — | 138.0–160.0 | 22.0 high |
| Row 2: panels c/d | — | 160.0–360.0 | 200.0 high |
| Row gap 2 | — | 360.0–382.0 | 22.0 high |
| Row 3: panels e/f | — | 382.0–516.0 | 134.0 high |

This leaves outer margins of 28 pt left, 16 pt right, 18 pt top, and 24 pt bottom. Panel frames are layout regions, not visible boxes. Each panel gets a dedicated 18 pt title band. Panels e/f may use an additional 12 pt key band beneath the title, outside the data rectangle.

Use nested GridSpec or an equivalent explicit layout; do not use `tight_layout`, `constrained_layout`, or `bbox_inches="tight"` to determine the final canvas.

### Panel-local allocation

- **a:** use a 58 pt context-label gutter, approximately 96 pt bar-data rectangle, then a 60 pt two-column count table with headers `Datasets` and `Labels`. Do not append prose to bar ends.
- **b:** use at least 74 pt for the three fully spelled scheme labels and the remaining width for the dumbbell/data rectangle. Put the title, panel letter, and top value labels in separate reserved bands. Do not place a legend in the data rectangle; direct-label endpoints as `residual` and `baseline` or use dedicated column headers.
- **c:** reserve, in order, an 18 pt family-ID gutter, 4 pt gap, 7 pt class strip, 4 pt gap, approximately 145 pt heatmap, 6 pt gap, 8 pt colorbar, and a dedicated colorbar tick/title cell. Prefer a two-line horizontal colorbar title (`Family-mode` / `fraction`) over two competing rotated y labels. Allow at least 128 pt vertical height for 16 heatmap rows and at least 38 pt beneath the heatmap for the nine context labels.
- **d:** reserve an 18 pt family-ID gutter, 4 pt gap, 7 pt class strip headed `Class`, 4 pt gap, approximately 110 pt recurrence-score plot, 8 pt gap, and a 75 pt right table with direct headers `Datasets` and `Contexts`. Plot one recurrence-score mark/lollipop per family and show counts only in the table; this removes the redundant dataset/context point legend entirely.
- **e:** grouped points only. Use one filled same-label point at each scheme and neutral hollow square/diamond controls, without connecting segments. Put the control-shape key in the dedicated key band, not over data. State `n` or the evaluation unit in a subtitle/caption rather than squeezing it into the axes.
- **f:** grouped point-and-whisker estimates with horizontal dodge for the three schemes, no cross-category lines, and a dedicated scheme key band. Wrap the longer exclusion labels onto at most two lines. Annotate only predeclared key estimates; do not opportunistically label whichever values happen to fit.

### Typography

Pin and checksum one redistributable font file in the reproducibility environment (DejaVu Sans is acceptable and present in this environment). Register that exact file explicitly rather than relying on font-family lookup.

- panel letters: 10.5 pt, bold;
- panel titles: 9.0 pt, semibold;
- axis titles: 7.5 pt, regular/medium;
- tick labels, table headers, legends, and annotations: 7.0–7.5 pt;
- absolute minimum: 7.0 pt, with no footnote, legend, colorbar, or superscript exception.

For the website SVG, convert glyphs to vector paths to eliminate browser substitution, while preserving `<title>`, `<desc>`, and page-level alt/accessibility text. Also retain a QA-only editable-text SVG generated from the same draw for bounding-box and OCR comparison. The PDF must embed/subset the pinned TrueType/OpenType font and must contain no Type 3 fonts.

### Color contract

Use colors only as redundant encodings; every category must also differ by marker, fixed position, direct label, or strip location.

Residualization schemes:

- context residual: blue `#0072B2`, circle;
- dataset-shrinkage residual: teal `#009E73`, triangle;
- dataset residual: burnt orange `#D55E00`, square.

Family classes:

- universal candidate: violet `#7B3294`;
- intermediate: neutral gray `#7A7A7A`;
- context-specific: gold `#E6AB02`.

Controls:

- same-label: filled scheme-colored marker;
- label-shuffled: hollow dark-gray square, `#5F6770` stroke;
- random-label: hollow dark-gray diamond, `#5F6770` stroke.

Use a neutral sequential heatmap (white/light gray to charcoal) so continuous intensity does not reuse either categorical palette. Encode missing values separately from observed zero (for example, white with a thin diagonal hatch for missing; unhatched white for zero). Render and inspect grayscale plus protanopia, deuteranopia, and tritanopia simulations. The semantic registry must prove that no comparison relies on hue alone.

## Geometry hard-fail contract

All measurements below are in final-size points. Bounds must include glyph outlines, transforms, marker radius, cap width, and half the rendered stroke width—not merely the artist anchor or axes box.

| Relationship | Minimum clearance / rule |
|---|---:|
| Any non-background content to canvas edge | 12 pt |
| Content assigned to neighboring panel frames | 14 pt between post-stroke bounds |
| Panel letter to title | 8 pt horizontal or 6 pt Euclidean clearance; never overlapping after 2 pt dilation |
| Title/subtitle to data rectangle | 5 pt |
| Unrelated text objects | 3 pt edge-to-edge; test after 1.5 pt dilation of each object |
| Text to its own box/gutter boundary | 3 pt internal padding |
| Tick label to spine/tick stroke | 3 pt |
| Axis title to union of tick-label bounds | 4 pt |
| Text/direct label to data mark or whisker | 3 pt unless the label owns that mark; owned labels still require 2 pt |
| Legend/key to any data rectangle | Disjoint; legends over data are prohibited for this design |
| Colorbar group to heatmap | 6 pt |
| Colorbar group to another panel's content | 10 pt |
| Marker/whisker to its axes boundary | marker radius/cap extent plus 1 pt, unless a documented clipping allowlist entry exists |

Every drawable receives a stable `gid`, semantic role, owner panel, owner container, z-order, expected font size (if text), and an explicit list of allowed contacts. Unregistered artists and implicit allowlists are hard failures. Intentional multi-span labels should be rendered as one registered text object where practical.

## Executable multi-layer QA strategy

### 1. Source/data gate

Before drawing, validate the frozen table schemas and stable keys. Assert exact integer counts and compare every plotted float against the independently recomputed result with a documented tolerance (normally `atol <= 5e-12`, `rtol = 0` before display rounding). Validate displayed rounding separately. A visual QA pass cannot override a numerical mismatch.

### 2. Renderer-time semantic geometry

After an Agg draw at the exact final size and 600 dpi:

1. collect `get_window_extent(renderer)`/`get_tightbbox(renderer)` for every registered artist;
2. transform every bound to final-size points;
3. expand by half the stroke width and role-specific clearance;
4. assert containment in the declared panel/container polygons;
5. perform a sweep-line pairwise intersection test against the explicit contact allowlist;
6. assert all text sizes are at least 7.0 pt and that every requested glyph exists in the pinned font;
7. serialize the measured boxes, clearances, owning regions, and test results to the audit JSON.

Do not trust this layer alone. It is a fast semantic preflight and a way to identify pairs needing exact rendered-mask testing.

### 3. SVG structural and post-layout audit

Generate both a QA text SVG and the path-outlined release SVG.

- Parse XML; require a valid namespace, unique IDs, the exact width/height/viewBox, no scripts, `foreignObject`, external URLs, linked raster images, absolute paths, or missing references.
- Run Inkscape `--query-all` on the QA text SVG and repeat canvas, panel, container, and pairwise clearance tests on the post-layout bounds.
- Reject any text element carrying a clip path. Permit clipping only for registered data layers, and inspect all clipped extrema.
- Confirm the path-outlined release SVG has the same semantic group inventory and page geometry as the QA SVG and contains no unresolved font dependency.
- For any pair whose inflated boxes intersect, render the two stable-ID groups to separate transparent 1,200 dpi masks, dilate each mask by the required clearance, and test alpha-mask intersection. This prevents both bounding-box false positives and glyph/stroke false negatives.

### 4. PDF audit

- Run `qpdf --check` or an equivalent PDF validator.
- Require `pdfinfo` page size `518.4 × 540.0 pt` within `0.02 pt` on each dimension and exactly one page.
- Run `pdffonts`; every font must report embedded/subset `yes`, and no Type 3 font is allowed.
- Rasterize independently with Poppler at 600 dpi and at a second diagnostic resolution (for example 300 dpi). Do not use the original renderer to rasterize the PDF.

### 5. PNG audit

- Require the web PNG to be exactly `2400 × 2500 px`.
- Require the publication PNG to be exactly `4320 × 4500 px` with `600 × 600 ppi` metadata (tolerance `0.5 ppi`), sRGB or a documented embedded ICC profile, and a white background.
- Reject unintended indexed-color conversion, alpha halos, or non-white border pixels.
- At 600 dpi, the 12 pt outer safe zone is 100 px. The non-background mask must be empty in that outer band.

### 6. Independent cross-format comparison

Rasterize the release SVG with Inkscape and the PDF with Poppler to a common `4320 × 4500` sRGB canvas. Compare those renders with the 600 dpi PNG after identical white compositing.

- after a 0.5 px Gaussian normalization, require global SSIM >= 0.995;
- require per-panel SSIM >= 0.990 so a local omission cannot hide inside a high global score;
- require foreground-ink area to agree within 0.5%;
- emit full-resolution absolute-difference and thresholded-difference images;
- any connected difference component wider or taller than 1.0 mm must be reviewed and dispositioned even if SSIM passes.

Antialiasing differences are expected; missing labels, shifted groups, font substitution, or clipping are not.

### 7. Raster mask collision and clipping audit

Create temporary transparent renders by semantic layer (`text`, `data`, `keys`, `containers`, `colorbar`, one layer per panel) at 1,200 dpi. Use morphological dilation corresponding to the required point clearance and assert disjointness for forbidden layer pairs. Erode each owner-container mask by its required padding and assert that the owned content mask is a subset. Also test connected components against every axes and panel boundary to catch visually clipped marker caps, glyphs, and strokes.

This layer specifically prevents the Figure 1-style failure in which text was inside the canvas but outside its own rounded box, and the current Figure 2 failure in which a legend's background occludes earlier content.

### 8. OCR/text-presence audit

Use Tesseract hOCR/TSV at the 600 dpi and 2,400 px renders, with an expected-token table generated from the semantic registry.

- require 100% recovery of panel letters, panel titles, axis titles, table headers, legend/key labels, and predeclared direct numerical annotations;
- require at least 95% recovery of other non-rotated, nonnumeric labels;
- rotate isolated crops of vertical labels before OCR;
- verify each recovered OCR box lies inside the expected owner panel/container;
- treat an OCR discrepancy as a review blocker, not proof of geometric failure or success.

Do not set OCR pass thresholds at 800 or 480 px; those renders are for human/responsive inspection.

### 9. Downscales and contact sheet

Create Lanczos downscales at 2,400, 1,600, 1,200, 800, and 480 px. The contact sheet should include:

1. full SVG-, PDF-, and PNG-derived renders;
2. full figures at all five downscales;
3. native-resolution crops of all six panels;
4. additional enlarged crops of panel b's header/labels, panel c's bottom labels/colorbar, all of panel d, the c/e boundary, panel e's key/zero line, and panel f's title/key/intervals/bottom labels;
5. a geometry-overlay page showing panel frames, assigned gutters, and measured minimum-clearance pair;
6. grayscale and three common color-vision simulations.

The human audit must explicitly record `pass`, `fail`, or `not applicable` for each hotspot and all four outer edges. Reviewer, timestamp, renderer versions, and display scale must be stored in the audit JSON. A single global `PASS` without per-rule evidence is insufficient.

## Responsive acceptance criteria

- **2,400/1,600/1,200 px:** all text must be readable at 100% display, with no clipping, alias loss, or merged labels.
- **800 px:** structure, titles, axes, and principal numeric values must remain readable; fine annotations may require opening the original but must not merge or clip.
- **480 px desktop-composite thumbnail:** no clipping, overlaps, or structural collapse; do not claim full label legibility.
- **Website mobile requirement:** if full label legibility at 480 CSS px is required, generate and separately approve a semantically identical one-column six-panel derivative approximately 90 mm wide. At 480 px, 7 pt text on a 90 mm canvas is about 13.2 px and is realistically readable. The website-integration prompt should use `<picture>`/panel-level sources only if this derivative is included in the checksummed release; otherwise require zoom/open-original behavior and a complete accessible description.

## Minimum machine-readable audit fields

The final audit JSON should contain at least:

- canvas dimensions in pt, mm, inches, and pixels;
- renderer/font files, versions, and SHA-256 values;
- source-table filenames/hashes and recomputation tolerances;
- every artist's stable ID, role, owner, font size, stroke-expanded bbox, and clearances;
- all collision/containment rules and explicit allowlist entries;
- minimum observed outer, inter-panel, text-text, title-letter, container, colorbar, and legend/data clearances;
- SVG validation and external-dependency results;
- PDF page/font validation results;
- PNG pixel/DPI/profile results;
- global and per-panel cross-format metrics;
- OCR coverage and unresolved tokens;
- downscale/manual checklist results;
- exact release filenames, byte counts, and SHA-256 hashes;
- overall status computed as failure if any mandatory field is absent or any hard-fail rule is false.

## Publication-readiness decision rule

The figure may be called publication-ready only if numerical provenance is closed, all hard-fail geometry/format checks pass, every cross-format render is inspected, the contact sheet is included, and the manual hotspot checklist has no unresolved defect. A valid export, a clean Matplotlib artist-bbox report, high global SSIM, or successful OCR is individually insufficient.
