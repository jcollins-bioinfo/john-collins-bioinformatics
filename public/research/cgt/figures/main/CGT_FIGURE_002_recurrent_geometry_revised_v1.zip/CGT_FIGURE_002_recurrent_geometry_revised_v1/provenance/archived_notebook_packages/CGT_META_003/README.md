# CGT-META-003

Universal Constraint Atlas.

This notebook follows CGT-META-002 and focuses on the strongest emerging result:
some perturbation-response families appear broadly universal across datasets and contexts, while others are sharply context-specific.

Purpose:
Rank CGT perturbation-mode families along a universal-to-specific axis and produce a clean atlas suitable for manuscript/preprint development.

Inputs:
- Prefer CGT-META-002 outputs from Google Drive.
- Requires CGT-META-001 outputs if META-002 outputs are missing.
- Does not read original h5ad files.

Outputs:
- universal constraint ranking table
- specificity/context restriction table
- family archetype marker genes
- universal vs specific atlas figure
- candidate constraint labels and evidence summaries
