# CGT-FIGURE-002 design specification

## Editorial objective

Figure 2 should establish that residual perturbation geometry is recurrent,
perturbation-specific and partially portable across datasets and contexts.

## Evidence order

- Panel a defines the data scope.
- Panel b shows why residualization is scientifically necessary.
- Panels c and d establish recurrent family structure.
- Panel e shows collapse under perturbation-identity destruction.
- Panel f shows both robustness and the present generalization limit.

## Statistical choices

- Family-context values are row-normalized mode fractions.
- Panel e uses the reported mean cosine across held-out observations.
- Panel f uses row-weighted observed means with 95% cluster-bootstrap
  confidence intervals, resampling held-out datasets or contexts.
- The supplementary figure separates within-context recurrence from
  cross-context recurrence to avoid conflating them.

## Artwork constraints

- no embedded figure title
- all lettering in the same non-default sans-serif typeface
- no red-green comparisons
- no rainbow colormap
- exact double-column width
- editable vector text
- line weights remain within print-safe bounds
