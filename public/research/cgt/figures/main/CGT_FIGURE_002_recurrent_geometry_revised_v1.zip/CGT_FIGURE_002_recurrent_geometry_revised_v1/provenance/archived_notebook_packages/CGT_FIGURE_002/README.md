# CGT-FIGURE-002

Publication-grade figure assembly for recurrent residual perturbation geometry.

## Central scientific narrative

This figure establishes that the CGT signal is not merely a context mean or
an endpoint-prediction artifact:

1. the residual-prediction atlas spans many perturbation contexts;
2. substantial coordinate variance remains after context residualization;
3. recurrent CGT families occupy characteristic context distributions;
4. several families recur across datasets and contexts;
5. same-perturbation residual geometry strongly exceeds shuffled-label and
   random-label controls;
6. the signal attenuates under study and context exclusion, defining the
   current boundary of generalization.

## Main figure panels

- **a** — composition of the residual-prediction atlas
- **b** — baseline versus residual coordinate variance
- **c** — family distribution across biological contexts
- **d** — family recurrence across datasets and contexts
- **e** — real residual transfer versus two identity-destroying controls
- **f** — robustness to dataset, study-proxy and context exclusion

## Supplementary figure

Repeated-label residual reliability is shown separately for labels recurring
within one context and labels recurring across multiple contexts.

## Nature-oriented artwork specification

- combined artwork: 183 mm × 170 mm
- standard text: 5–7 pt
- panel labels: 8 pt bold, upright, lower-case
- non-default Liberation Sans / Arial-compatible font
- editable PDF and SVG
- 600 dpi PNG preview
- white background
- color-vision-safe blue/teal/orange/neutral palette
- individual panel exports
- Source Data workbook and panel-level CSVs
- claim, evidence, figure and source-data ledgers

## Required upstream outputs

```text
/content/drive/MyDrive/CGT/outputs/CGT_META_003/
/content/drive/MyDrive/CGT/outputs/CGT_PREDICT_003B/
```

## Runtime output

```text
/content/drive/MyDrive/CGT/outputs/CGT_FIGURE_002/
```
