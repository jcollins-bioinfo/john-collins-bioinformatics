# CGT Figure 2 — revised release v1

This is the audited replacement release for Figure 2 of the Constraint Geometry Theory preprint, **“Residual family-coordinate structure recurs within the leave-dataset-out benchmark but attenuates under study-proxy and context exclusion.”** It was rebuilt from the frozen Figure 2 source tables and independently checked against the exact `CGT_META_003` and `CGT_PREDICT_003B` upstream inputs. The original notebook, tables, exports, and manifests were preserved unchanged.

## Release status

All mandatory scientific, geometry, raster, vector, PDF, cross-format, text-presence, and human visual checks pass. The fixed canvas is 182.88 × 190.50 mm (7.2 × 7.5 in). The publication raster is 4,320 × 4,500 px at 600 dpi; the web raster is 2,400 × 2,500 px. The minimum final-size font is 7.0 pt.

The full machine-readable result is in `qa/CGT_FIGURE_002_recurrent_geometry_revised_audit.json`. Checksums for all release files other than the manifest itself are in `CGT_FIGURE_002_release_manifest.json`; the manifest is self-excluded because a file cannot contain its own stable digest.

## Directory map

- `assets/`: approved website and publication outputs.
- `source/`: deterministic renderer, scientific verifier, QA program, frozen Figure 2 panel tables/workbook, exact upstream inputs, and canonical notebooks.
- `documentation/`: caption, alt text, accessible description, reproduction commands, and data dictionary.
- `provenance/`: provenance inventory, decision log, original ledgers/manifests, and baseline audits.
- `environment/`: exact software versions used for the final render and audit.
- `qa/`: final audit, scientific recomputation record, contact sheet, independent PDF/SVG renders, downscales, crops, and accessibility simulations.

## Reproduction order

1. Run `source/verify_cgt_figure_002_science.py` against `source/upstream/` and compare with `source/figure_data/`. This reconstructs the six original main-panel tables plus the derived finite-denominator table.
2. Run `source/render_cgt_figure_002.py` against `source/figure_data/`.
3. Run `source/audit_cgt_figure_002.py`, supplying the generated layout registry, scientific-verification JSON, and the included human-review record.

Exact commands are in `documentation/REPRODUCE.md`. The renderer never reads from the network and does not alter the frozen tables.

## Scope and interpretation

Panels a, b, e, and f use the PREDICT residual-analysis universe (2,720 observations, 39 datasets, 8 contexts). Panels c and d use the upstream META family-atlas universe (248 modes, 43 datasets, 9 contexts, 16 families). These are distinct upstream analysis universes, not conflicting counts.

The family classes and recurrence score are descriptive summaries. Same-label transfer is preprocessing- and split-dependent. Shuffled-label and random-label results are null checks, not independent biological replications. Strong leave-dataset-out recurrence attenuates under same-study-proxy exclusion and leave-context-out evaluation. The package does not claim causality, mechanism, or biological universality.

## Website handoff

The website repository was not modified in this task. Use the separate, externally supplied `CGT_FIGURE_002_website_integration_codex_prompt.md` together with the intact release ZIP. That prompt contains the ZIP's own byte count and SHA-256, which cannot be embedded inside the ZIP without creating an impossible self-reference.
