# Figure-source data dictionary

The six original main-panel `Fig2*.csv` files and one audit-derived denominator CSV are the frozen, machine-readable inputs consumed by the renderer. `CGT_FIGURE_002_SourceData.xlsx` contains the original panel tables in workbook form and is included for human inspection. The scientific verifier independently reconstructs every renderer input from the exact files under `source/upstream/`.

## Panel tables

| File | Rows × columns | Role |
|---|---:|---|
| `Fig2a_contexts.csv` | 8 × 5 | Context-level counts for the PREDICT analysis universe. |
| `Fig2b_variance.csv` | 3 × 11 | Raw-coordinate baseline and residual variance summaries by residualization scheme. |
| `Fig2c_context_matrix.csv` | 144 × 5 | Complete 16-family × 9-context matrix; each cell is the fraction of that family's modes in the context. |
| `Fig2d_recurrence.csv` | 16 × 10 | Complete family ranking, descriptive class, dataset/context counts, and non-overlap plot offsets. |
| `Fig2e_controls.csv` | 3 × 8 | Same-label mean cosine and two null-control means for each scheme. Legacy Mann–Whitney fields are retained as frozen provenance but are not displayed or interpreted. |
| `Fig2e_same_label_denominators.csv` | 3 × 5 | Generated-row, finite-cosine, zero-true-norm, and zero-predicted-norm counts, independently derived from the leave-dataset benchmark to prevent `real_n` from being misread as the finite denominator. |
| `Fig2f_robustness.csv` | 9 × 8 | Mean cosine and 95% cluster-bootstrap intervals for three schemes × three holdout designs. |

## Important fields

- `context`: upstream analysis-context code; `context_label` is its display form.
- `n_observations`: number of residual-coordinate rows in the PREDICT universe.
- `n_datasets`, `n_labels`, `n_modes`, `n_contexts`: descriptive distinct counts in the stated table universe.
- `scheme`: `context`, `dataset_shrink`, or `dataset`.
- `baseline_fraction_of_raw_variance`, `residual_fraction_of_raw_variance`: components computed relative to total raw variance. Dataset-shrinkage residualization is not an orthogonal projection, so the graphical design does not imply a general partition identity beyond the recorded calculation.
- `unsup_family`: upstream unsupervised family identifier.
- `fraction_of_family_modes`: modes in a family/context divided by all modes in that family. Rows over the nine contexts sum to one; zero denotes an observed zero, not missingness.
- `universality_index`: upstream field renamed **recurrence score** in the figure to avoid ontological overstatement.
- `family_class`: upstream descriptive class. `universal_candidate` is displayed as **B**, “broad-recurrence candidate”; `intermediate` as **I**; and `context_specific` as **C**.
- `plot_x`, `plot_y`: deterministic, display-only offsets for coincident family counts; scientific values remain `n_datasets` and `n_contexts`.
- `real_mean_cosine`, `shuffle_mean_cosine`, `random_mean_cosine`: row-weighted mean residual-vector cosine for the primary same-label predictor and null checks.
- `mean`, `ci_low`, `ci_high`: row-weighted point estimate and percentile cluster-bootstrap bounds.
- `n_groups`: number of resampled clusters; held-out datasets for leave-dataset-out and same-study-proxy exclusion, held-out contexts for leave-context-out.
- `n_rows`: held-out prediction rows contributing to the estimate. Rows are not independent biological replications.

## Definitions used by the reconstruction

- **Perturbation observation:** one PREDICT residual-coordinate row for a dataset–perturbation profile after upstream eligibility filtering.
- **Perturbation label:** `str(label).strip().upper()` after upstream control-like tokens are excluded.
- **Perturbation mode:** one dataset-specific mode in the META atlas.
- **Dataset:** upstream dataset identifier.
- **Study / same-study proxy:** the prefix of the dataset identifier before the first underscore; this is a coarse proxy, not a curated study accession.
- **Context:** upstream biological/experimental context category.
- **Coordinate vector:** the 16 absolute family-coordinate magnitudes (`COORDINATE_MODE="abs"`).
- **Context residual:** coordinate vector minus the mean vector within context.
- **Dataset residual:** coordinate vector minus the mean vector within dataset.
- **Dataset-shrinkage residual:** coordinate vector minus `0.75 × dataset mean + 0.25 × context mean`.
- **Same-label predictor:** training mean residual vector for the exact normalized label, shrunk by `n/(n+2)`.
- **Residual-vector cosine:** cosine similarity between the held-out residual vector and its prediction.
- **Family:** upstream unsupervised cluster of dataset-specific modes.
- **Recurrence score:** `z(context coverage) + z(dataset coverage) + z(effective contexts) + z(normalized context entropy) + 0.5 z(log1p(total energy)) + 0.5 z(log1p(incident graph edges))`.
- **Specificity score:** `z(dominant-context fraction) − z(effective contexts) − z(normalized context entropy) + 0.25 z(log1p(total energy))`.
- **Family class:** based on recurrence minus specificity: C at `≤ −1`, I at `> −1` and `≤ 1`, and upstream `universal_candidate` at `> 1`; the last is deliberately relabeled B in the figure.

## Analysis universes

- PREDICT (`CGT_PREDICT_003B`): 2,720 observations, 39 datasets, 8 contexts; panels a, b, e, and f.
- META (`CGT_META_003`): 248 modes, 43 datasets, 9 contexts, 16 families; panels c and d.

The difference is traced to two distinct upstream products and their eligibility scopes. It is not caused by duplicated/collapsed display rows or a stale count label.
