# Reproducing and auditing CGT Figure 2

Run these commands from the root of the unpacked release directory. They require the versions recorded in `environment/environment.json` and the external programs listed in `environment/system_tools.txt`.

```bash
export MPLCONFIGDIR=/tmp/cgt_figure_002_mplconfig

python3 source/verify_cgt_figure_002_science.py \
  --upstream-root source/upstream \
  --frozen-dir source/figure_data \
  --output qa/CGT_FIGURE_002_scientific_verification_reproduced.json

python3 source/render_cgt_figure_002.py \
  --source-dir source/figure_data \
  --output-dir reproduced/output \
  --qa-dir reproduced/qa

python3 source/audit_cgt_figure_002.py \
  --output-dir reproduced/output \
  --qa-dir reproduced/qa \
  --layout reproduced/qa/CGT_FIGURE_002_layout_registry.json \
  --science qa/CGT_FIGURE_002_scientific_verification_reproduced.json \
  --human-review qa/CGT_FIGURE_002_human_visual_audit.json \
  --audit-output reproduced/output/CGT_FIGURE_002_recurrent_geometry_revised_audit.json
```

The scientific verifier uses an absolute tolerance of `1e-12`, zero relative tolerance, 4,000 cluster-bootstrap resamples, and seed `1201`. It independently rebuilds all six displayed panel tables from the exact upstream inputs. The audit independently rasterizes the PDF with Poppler and the SVG with Inkscape, creates 2,400/1,600/1,200/800/480-pixel downscales, checks geometry and font constraints, runs text-presence/OCR checks, and compares formats.

The supplied human-review JSON records the completed visual inspection of the released bytes. A newly regenerated figure should receive a new visual review rather than inheriting that judgment automatically.
