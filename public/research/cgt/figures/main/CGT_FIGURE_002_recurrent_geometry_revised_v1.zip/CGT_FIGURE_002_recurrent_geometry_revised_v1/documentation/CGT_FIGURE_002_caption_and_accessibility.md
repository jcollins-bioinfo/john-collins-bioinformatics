# CGT Figure 2 — approved caption and accessibility copy

## Publication title and caption

**Figure 2 | Residual family-coordinate structure recurs within the leave-dataset-out benchmark but attenuates under study-proxy and context exclusion.** Two upstream analysis universes are shown and are not interchangeable: panels **a**, **b**, **e**, and **f** use the PREDICT-003B residual-analysis universe (2,720 dataset–perturbation observations, 39 datasets, and 8 contexts), whereas panels **c** and **d** use the META-003 family-atlas universe (248 perturbation-response modes, 43 datasets, 9 contexts, and 16 unsupervised families). **a,** Composition of PREDICT-003B after exact-label mapping and string-based removal of control-like labels. Each observation is one unique dataset–perturbation row represented by a 16-dimensional absolute family-coordinate vector. Bars show observations; the two right columns give contributing datasets and distinct exact perturbation labels within each context: Unclassified, 713 observations/10 datasets/620 labels; K562, 528/10/362; T cell, 436/8/349; iPSC/neuron, 333/4/294; immune cancer, 236/2/236; drug/cancer, 174/3/174; epithelial cancer, 150/1/150; and RPE1, 150/1/150. **b,** Baseline and residual fractions use a shared denominator, the sum across the 16 coordinates of their population variances in the raw PREDICT-003B vectors (total raw variance 0.752720). Context-mean subtraction assigns 0.4712057 of raw variance to the baseline and 0.5287943 to the residual; subtraction of a shrinkage baseline, (0.75\,E[y\mid\mathrm{dataset}]+0.25\,E[y\mid\mathrm{context}]), gives 0.7564466 baseline and 0.0533927 residual; dataset-mean subtraction gives 0.9783007 baseline and 0.0216993 residual. Baseline and residual fractions are shown as separate fractions of raw variance and need not sum to one when the two components are not orthogonal, as in the shrinkage scheme. **c,** Within-family distribution of all 248 META-003 modes across nine contexts. Each heatmap cell is (n_{fc}/n_f), the number of modes assigned to family (f) and context (c) divided by all modes in family (f); each row therefore sums to one. The adjacent class strip uses `B` for the source `universal_candidate` class (described here more cautiously as a broad candidate), `I` for intermediate, and `C` for context-specific. These are descriptive source classes, not validated biological types. **d,** All 16 families, without top-(n) selection, ordered by the source `universality_index`, relabelled here as a descriptive recurrence score. For family (f),

\[
R_f=z(C_f/9)+z(D_f/43)+z(e^{H_f})+z(H_f^{\mathrm{norm}})
+\tfrac12 z\{\log(1+E_f)\}+\tfrac12 z\{\log(1+G_f)\},
\]

where (C_f) and (D_f) are represented-context and represented-dataset counts; (H_f=-\sum_c p_{fc}\log p_{fc}); (e^{H_f}) is the effective number of contexts; (H_f^{\mathrm{norm}}=H_f/\log C_f) for (C_f>1) and 0 otherwise; (E_f) is summed mode `energy_fraction`; and (G_f) is the number of graph edges incident to at least one mode in the family. Each (z(\cdot)) is a population-standardized value computed across these 16 families after median imputation if needed. Thus (R_f) is a dimensionless, sample-relative composite—not a probability, effect size, or transportability estimand—and a negative value means below-average composite recurrence within this run, not negative biological recurrence. Source classes were assigned from (R_f-S_f), where (S_f=z(q_f)-z(e^{H_f})-z(H_f^{\mathrm{norm}})+0.25z\{\log(1+E_f)\}) and (q_f) is the dominant-context fraction: `C` if (R_f-S_f\leq-1), `I` if (-1<R_f-S_f\leq1), and `B` if (R_f-S_f>1). F14 has the highest score (12.6496; 13 datasets, 7 contexts), followed by F16 (3.8869; 3, 3); the remaining scores range from 2.9202 to -4.1653. **e,** Leave-one-dataset-out transfer of residual direction. For each eligible held-out observation, the predictor is the mean residual vector among training observations with the same exact label, multiplied by (\alpha=n/(n+2)), where (n) is the number of same-label training rows; cosine is unchanged by this positive scalar shrinkage. The response is the dimensionless cosine between the held-out residual vector and this prediction. Same-label means were 0.5632, 0.5580, and 0.08353 for context, dataset-shrinkage, and dataset residuals, respectively. Training-label permutation controls were -0.01997, -0.01242, and 0.003599; unrelated-random-label controls were -0.01166, -0.004505, and 0.004891. Each control procedure was repeated 100 times under the upstream PREDICT-003B random seed 619. The controls destroy perturbation identity while retaining the residual-coordinate table and split structure; they are null diagnostics, not independent biological replications. PREDICT-003B generated 1,092 same-label holdout rows per scheme, but cosine is undefined for a zero-norm observed or predicted vector: the finite same-label cosine denominators were 1,092 for context residuals, 1,092 for dataset-shrinkage residuals, and 215 for dataset residuals. The frozen panel-e source table records 109,200 generated control rows per scheme/control but not the post-NaN finite control denominators. **f,** The same shrunken same-label predictor under progressively stricter exclusion designs. Points are means over finite observation-level residual-vector cosines. Horizontal bars are percentile 95% cluster-bootstrap intervals from 4,000 resamples using NumPy generator seed 1201. For leave-dataset-out and same-study-proxy exclusion, held-out datasets were resampled with replacement; for leave-context-out, held-out contexts were resampled. Each replicate sums the sampled cluster sums and counts before division, preserving row weighting while treating the held-out grouping variable as the resampling unit. Leave-dataset-out means [95% interval; clusters, finite rows] were 0.5632 [0.3690, 0.7948; 34, 1,092] for context residuals, 0.5580 [0.3647, 0.7846; 34, 1,092] for dataset-shrinkage residuals, and 0.08353 [0.02383, 0.4088; 6, 215] for dataset residuals. After excluding training datasets sharing the held-out dataset's string prefix before the first underscore, the corresponding values were 0.03500 [-0.03730, 0.09316; 22, 507], 0.03667 [-0.01789, 0.09236; 22, 507], and 0.03608 [-0.01981, 0.25544; 4, 185]. Leave-context-out values were 0.07937 [0.04801, 0.12778; 7, 496], 0.06913 [0.03686, 0.12255; 7, 496], and 0.03960 [0.007525, 0.17124; 4, 201]. The strong attenuation under the latter exclusions bounds the original result: same-label residual direction is recurrent within the PREDICT-003B split/preprocessing system, but broad study- or context-independent transport is not established.

**Interpretive and provenance limitations.** The source artifacts establish that META-003 and PREDICT-003B are different upstream universes, but they do not provide a row-level inclusion map explaining the four-dataset/one-context difference. Residual baselines were estimated once from the full PREDICT-003B table before holdout splitting rather than re-estimated inside each training fold; panels e/f therefore evaluate transfer conditional on transductive preprocessing, not a fully nested inductive pipeline. The “same-study” exclusion is only a dataset-name-prefix proxy, not verified study identity. Exact-label recurrence can reflect repeated studies, platform effects, label prevalence, context imbalance, shared controls, or other dependence in addition to perturbation-specific biology. Dataset-mean residualization produces many zero-norm vectors, sharply reducing its finite cosine denominator. The recurrence score and B/I/C thresholds are hand-constructed, correlated-component, run-relative summaries with no uncertainty interval or external calibration. Cluster-bootstrap intervals use only 4–34 held-out clusters depending on scheme/design and quantify resampling variability under that clustering choice; they do not establish mechanistic, causal, or biological universality. No panel tests an external phenotype, intervention response outside the assembled data, or causal mechanism.

## Concise alt text

Six-panel figure separates two analysis universes. In PREDICT-003B (2,720 observations, 39 datasets, 8 contexts), context and dataset-shrinkage residuals show mean same-label leave-dataset-out cosine near 0.56, with shuffled and random-label controls near zero, but the signal falls to about 0.04 after a same-study-prefix exclusion and 0.07–0.08 under leave-context-out evaluation. META-003 (248 modes, 43 datasets, 9 contexts) contains one dominant broad-recurrence family, F14, and many single-context families. Results are descriptive and preprocessing-dependent, not causal or universally transportable.

## Full accessible description

### Overall organization and encodings

The figure is arranged as two columns by three rows. Panels a, b, e, and f use PREDICT-003B; panels c and d use the larger META-003 family-atlas universe. Context residuals are blue circles, dataset-shrinkage residuals are teal triangles, and dataset residuals are orange squares. Panel-e controls use a hollow gray square for shuffled labels and a hollow gray diamond for random labels. Family-class strips use violet `B` (source universal-candidate, described as broad candidate), gray `I` (intermediate), and gold `C` (context-specific). Panel c uses a white-to-charcoal scale from family-mode fraction 0 to 1. Color is redundant with shape, position, direct labels, or class letters.

All cosines and variance fractions are dimensionless. Counts are numbers of observations, labels, modes, datasets, contexts, or bootstrap clusters as specified. Recurrence scores are run-relative standardized composites.

### Panel a: PREDICT-003B composition

The horizontal bars descend from 713 to 150 observations. The table gives exact values.

| Context | Observations | Datasets | Distinct exact labels within context |
|---|---:|---:|---:|
| Unclassified | 713 | 10 | 620 |
| K562 | 528 | 10 | 362 |
| T cell | 436 | 8 | 349 |
| iPSC / neuron | 333 | 4 | 294 |
| Immune cancer | 236 | 2 | 236 |
| Drug / cancer | 174 | 3 | 174 |
| Epithelial cancer | 150 | 1 | 150 |
| RPE1 | 150 | 1 | 150 |

The rows sum to 2,720 observations. Dataset and label counts are within-context counts and must not be summed to infer global unique counts.

### Panel b: raw-coordinate variance fractions

Three horizontal dumbbells compare residual and baseline fractions using the same total raw-variance denominator, 0.7527200104.

| Residualization scheme | Residual fraction | Baseline fraction | Sum shown |
|---|---:|---:|---:|
| Context mean | 0.528794 | 0.471206 | 1.000000 |
| 75% dataset + 25% context shrinkage baseline | 0.053393 | 0.756447 | 0.809839 |
| Dataset mean | 0.021699 | 0.978301 | 1.000000 |

The shrinkage fractions do not sum to one because the residual and baseline are not orthogonal; the omitted covariance term is not a fourth plotted component.

### Panel c: family distribution across contexts

Rows are ordered by the panel-d recurrence score. Each listed value is the fraction of that family's modes in a context; omitted contexts are exactly zero in the frozen source table.

| Family (class) | Nonzero within-family context fractions |
|---|---|
| F14 (B) | K562 0.020; RPE1 0.020; T cell 0.510; drug/cancer 0.122; epithelial cancer 0.020; immune cancer 0.122; unclassified 0.184 |
| F16 (B) | RPE1 0.455; epithelial cancer 0.364; unclassified 0.182 |
| F10 (B) | Immune cancer 0.250; unclassified 0.750 |
| F3 (B) | Drug/cancer 0.727; unclassified 0.273 |
| F9 (B) | T cell 0.733; unclassified 0.267 |
| F12 (I) | K562 1.000 |
| F11 (B) | K562 0.857; epithelial cancer 0.143 |
| F5 (C) | iPSC/neuron 1.000 |
| F6 (C) | iPSC/neuron 1.000 |
| F1 (C) | T cell 1.000 |
| F15 (C) | Unclassified 1.000 |
| F13 (C) | Compact screen 1.000 |
| F8 (C) | Unclassified 1.000 |
| F7 (C) | Unclassified 1.000 |
| F4 (C) | Unclassified 1.000 |
| F2 (C) | Unclassified 1.000 |

The nine contexts are K562, RPE1, T cell, compact screen, drug/cancer, epithelial cancer, iPSC/neuron, immune cancer, and unclassified. Row normalization intentionally removes family size from the cell values; a fraction of 1.0 can describe a small or large family.

### Panel d: descriptive recurrence score and coverage counts

Each row is a lollipop from zero to the sample-relative recurrence score. Negative values extend left of zero. The right columns give exact dataset and context coverage; the class strip is descriptive.

| Family | Class | Modes | Recurrence score | Datasets | Contexts |
|---|:---:|---:|---:|---:|---:|
| F14 | B | 49 | 12.650 | 13 | 7 |
| F16 | B | 11 | 3.887 | 3 | 3 |
| F10 | B | 24 | 2.920 | 4 | 2 |
| F3 | B | 22 | 2.857 | 4 | 2 |
| F9 | B | 15 | 2.260 | 3 | 2 |
| F12 | I | 53 | 1.852 | 10 | 1 |
| F11 | B | 7 | 1.048 | 3 | 2 |
| F5 | C | 12 | -2.254 | 2 | 1 |
| F6 | C | 12 | -2.327 | 2 | 1 |
| F1 | C | 12 | -2.564 | 2 | 1 |
| F15 | C | 6 | -2.815 | 1 | 1 |
| F13 | C | 3 | -3.045 | 1 | 1 |
| F8 | C | 6 | -3.081 | 1 | 1 |
| F7 | C | 6 | -3.540 | 1 | 1 |
| F4 | C | 4 | -3.680 | 1 | 1 |
| F2 | C | 6 | -4.165 | 1 | 1 |

F14 is a marked outlier on the constructed score. F12 illustrates why the score and class are not interchangeable: despite a positive recurrence score and ten represented datasets, all 53 modes occur in one context, producing the intermediate class after the separate specificity score is considered.

### Panel e: same-label transfer and identity-destroying controls

Three x-axis groups correspond to context, dataset-shrinkage, and dataset residualization. Filled colored points are same-label predictions; hollow squares and diamonds are the two controls. No connecting line implies a trajectory.

| Scheme | Same-label mean cosine | Finite same-label rows | Shuffled-label mean | Random-label mean |
|---|---:|---:|---:|---:|
| Context residual | 0.563195 | 1,092 | -0.019972 | -0.011657 |
| Dataset-shrinkage residual | 0.557978 | 1,092 | -0.012417 | -0.004505 |
| Dataset residual | 0.083530 | 215 | 0.003599 | 0.004891 |

The source table's `real_n=1,092` is the generated holdout-row count for each scheme, not always the finite cosine denominator. The 100 shuffled-label and 100 random-label repetitions generated 109,200 control rows per scheme/control; their finite post-NaN denominators were not retained in the frozen Figure 2 table. The near-zero controls support label-specific association within this pipeline, but do not identify biological mechanism or remove study/context dependence.

### Panel f: transfer under stricter exclusions

Rows are leave-dataset-out, exclusion of a same-study string-prefix proxy, and leave-context-out. Within each row, the three marker shapes show residualization schemes; horizontal whiskers are percentile 95% cluster-bootstrap intervals.

| Evaluation | Scheme | Mean cosine | 95% interval | Resampled clusters | Finite rows |
|---|---|---:|---:|---:|---:|
| Leave dataset out | Context | 0.563195 | [0.368969, 0.794758] | 34 datasets | 1,092 |
| Leave dataset out | Dataset shrinkage | 0.557978 | [0.364704, 0.784560] | 34 datasets | 1,092 |
| Leave dataset out | Dataset | 0.083530 | [0.023832, 0.408824] | 6 datasets | 215 |
| Exclude same-study proxy | Context | 0.034999 | [-0.037302, 0.093158] | 22 datasets | 507 |
| Exclude same-study proxy | Dataset shrinkage | 0.036667 | [-0.017893, 0.092363] | 22 datasets | 507 |
| Exclude same-study proxy | Dataset | 0.036080 | [-0.019807, 0.255440] | 4 datasets | 185 |
| Leave context out | Context | 0.079368 | [0.048007, 0.127777] | 7 contexts | 496 |
| Leave context out | Dataset shrinkage | 0.069125 | [0.036860, 0.122546] | 7 contexts | 496 |
| Leave context out | Dataset | 0.039597 | [0.007525, 0.171243] | 4 contexts | 201 |

The context and dataset-shrinkage estimates drop from approximately 0.56 in the ordinary leave-dataset-out benchmark to approximately 0.04 after the study-prefix exclusion and 0.07–0.08 under leave-context-out evaluation. This is evidence against interpreting the original leave-dataset-out value as broadly transportable across studies or contexts.

### Accessibility-level interpretation boundary

The figure establishes descriptive, preprocessing-dependent associations inside the CGT family-coordinate pipeline. It does not establish an identified causal effect, a mechanistic cellular law, external phenotype prediction, or family universality. The strongest alternative explanations still include study leakage not captured by the string-prefix proxy, context and platform imbalance, repeated perturbation labels, full-table baseline estimation before splitting, family-construction dependence, and score-definition dependence. External replication with fold-fitted residualization and verified study identifiers would be required to distinguish portable perturbation-specific structure from these alternatives.
