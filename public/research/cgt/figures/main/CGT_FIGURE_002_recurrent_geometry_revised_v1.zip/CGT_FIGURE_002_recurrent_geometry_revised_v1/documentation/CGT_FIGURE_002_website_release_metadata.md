# CGT Figure 2 website release metadata

## Approved copy

**Title:** Residual family-coordinate structure recurs within the leave-dataset-out benchmark but attenuates under study-proxy and context exclusion

**Concise alt text:** Six-panel figure separates two analysis universes. In PREDICT-003B (2,720 observations, 39 datasets, 8 contexts), context and dataset-shrinkage residuals show mean same-label leave-dataset-out cosine near 0.56, with shuffled and random-label controls near zero, but the signal falls to about 0.04 after a same-study-prefix exclusion and 0.07–0.08 under leave-context-out evaluation. META-003 (248 modes, 43 datasets, 9 contexts) contains one dominant broad-recurrence family, F14, and many single-context families. Results are descriptive and preprocessing-dependent, not causal or universally transportable.

**Release status:** Scientifically audited replacement release v1; all mandatory automated and rendered visual QA passed.

**Revision scope:** Source-level provenance and numerical audit; deterministic six-panel reconstruction; corrected analysis-universe, denominator, uncertainty, score, class, and claim wording; publication typography, layout, accessibility, and cross-format integrity. No original or upstream scientific input was modified.

**Quality note:** Exact 182.88 × 190.50 mm canvas; 4,320 × 4,500 publication PNG at 600 dpi; 2,400 × 2,500 web PNG; 7.0 pt minimum font; no canvas/container escape, text collision, legend/data collision, clipping, invalid SVG, unembedded PDF font, numerical mismatch, or cross-format failure; complete human visual review passed. The two-column composite is uncropped at 480 px, but small publication text requires an open-original or zoom affordance on narrow screens unless a separately approved mobile derivative is supplied.

The exact publication caption and full accessible description are authoritative in `CGT_FIGURE_002_caption_and_accessibility.md`. They must be transferred without scientific paraphrase.

## Approved repository destination mapping

| Release path | Canonical website destination |
|---|---|
| `assets/CGT_FIGURE_002_recurrent_geometry_revised_web.png` | `public/research/cgt/figures/main/CGT_FIGURE_002_recurrent_geometry_revised_web.png` |
| `assets/CGT_FIGURE_002_recurrent_geometry_revised_600dpi.png` | `public/research/cgt/figures/main/CGT_FIGURE_002_recurrent_geometry_revised_600dpi.png` |
| `assets/CGT_FIGURE_002_recurrent_geometry_revised.pdf` | `public/research/cgt/figures/main/CGT_FIGURE_002_recurrent_geometry_revised.pdf` |
| `assets/CGT_FIGURE_002_recurrent_geometry_revised.svg` | `public/research/cgt/figures/main/CGT_FIGURE_002_recurrent_geometry_revised.svg` |
| `qa/CGT_FIGURE_002_recurrent_geometry_revised_audit.json` | `public/research/cgt/figures/main/CGT_FIGURE_002_recurrent_geometry_revised_audit.json` |
| complete intact release ZIP | `public/research/cgt/figures/main/CGT_FIGURE_002_recurrent_geometry_revised_v1.zip` |

The legacy `figure-02-recurrent-geometry.{png,pdf,svg}` URLs may be retained as byte-identical compatibility aliases if that remains consistent with the current repository’s Figure 1 pattern. The active page should use the new canonical filenames to invalidate the old cache key.
