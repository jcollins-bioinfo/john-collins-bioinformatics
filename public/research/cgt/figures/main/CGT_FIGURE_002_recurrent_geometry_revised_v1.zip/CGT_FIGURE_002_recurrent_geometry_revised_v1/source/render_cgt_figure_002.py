#!/usr/bin/env python3
"""Deterministic renderer for revised CGT Figure 2.

The renderer consumes only the frozen Figure 2 panel tables.  It does not
re-run or alter the upstream scientific analyses.  The fixed 7.2 x 7.5 inch
canvas gives exact 4320 x 4500 px output at 600 dpi and 2400 x 2500 px web
output.  All geometry is specified in final-size points.
"""

from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import json
import math
import os
import re
from pathlib import Path
from typing import Any, Iterable

os.environ.setdefault("MPLCONFIGDIR", "/tmp/cgt_figure_002_mplconfig")
os.environ.setdefault("SOURCE_DATE_EPOCH", "1787184000")

import matplotlib as mpl
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from PIL import Image


FIG_W_IN = 7.2
FIG_H_IN = 7.5
FIG_W_PT = 518.4
FIG_H_PT = 540.0
FIG_W_MM = 182.88
FIG_H_MM = 190.50
PUB_DPI = 600
WEB_SIZE = (2400, 2500)
MIN_FONT_PT = 7.0

# Pillow's generated sRGB profile embeds its creation time.  Pin the exact
# redistribution-safe profile bytes so repeated renders are byte-identical.
SRGB_ICC_PROFILE = base64.b64decode(
    "AAACTGxjbXMEQAAAbW50clJHQiBYWVogB+oACAAUAAwANgAqYWNzcEFQUEwA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPbWAAEAAAAA0y1sY21zAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALZGVz"
    "YwAAAQgAAAA2Y3BydAAAAUAAAABMd3RwdAAAAYwAAAAUY2hhZAAAAaAAAAAs"
    "clhZWgAAAcwAAAAUYlhZWgAAAeAAAAAUZ1hZWgAAAfQAAAAUclRSQwAAAggA"
    "AAAgZ1RSQwAAAggAAAAgYlRSQwAAAggAAAAgY2hybQAAAigAAAAkbWx1YwAA"
    "AAAAAAABAAAADGVuVVMAAAAaAAAAHABzAFIARwBCACAAYgB1AGkAbAB0AC0A"
    "aQBuAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAADAAAAAcAE4AbwAgAGMAbwBw"
    "AHkAcgBpAGcAaAB0ACwAIAB1AHMAZQAgAGYAcgBlAGUAbAB5WFlaIAAAAAAA"
    "APbWAAEAAAAA0y1zZjMyAAAAAAABDEIAAAXe///zJQAAB5MAAP2Q///7of//"
    "/aIAAAPcAADAblhZWiAAAAAAAABvoAAAOPUAAAOQWFlaIAAAAAAAACSfAAAP"
    "hAAAtsNYWVogAAAAAAAAYpcAALeHAAAY2XBhcmEAAAAAAAMAAAACZmYAAPKn"
    "AAANWQAAE9AAAApbY2hybQAAAAAAAwAAAACj1wAAVHsAAEzNAACZmgAAJmYA"
    "AA9c"
)
FIXED_DOCUMENT_DATE = dt.datetime(2026, 8, 20, tzinfo=dt.timezone.utc)

COLORS = {
    "ink": "#17212B",
    "muted": "#55616D",
    "grid": "#D9DEE3",
    "light": "#F4F6F8",
    "white": "#FFFFFF",
    "context": "#0072B2",
    "dataset_shrink": "#009E73",
    "dataset": "#D55E00",
    "broad": "#7B3294",
    "intermediate": "#7A7A7A",
    "specific": "#E6AB02",
    "control": "#5F6770",
}

SCHEME_ORDER = ["context", "dataset_shrink", "dataset"]
SCHEME_LABEL = {
    "context": "Context",
    "dataset_shrink": "Dataset shrinkage",
    "dataset": "Dataset",
}
SCHEME_COLOR = {key: COLORS[key] for key in SCHEME_ORDER}
SCHEME_MARKER = {"context": "o", "dataset_shrink": "^", "dataset": "s"}

CLASS_LABEL = {
    "universal_candidate": "B",
    "intermediate": "I",
    "context_specific": "C",
}
CLASS_COLOR = {
    "universal_candidate": COLORS["broad"],
    "intermediate": COLORS["intermediate"],
    "context_specific": COLORS["specific"],
}

CONTEXT_SHORT = {
    "K562_hematopoietic": "K562",
    "RPE1_epithelial": "RPE1",
    "T_cell_immune": "T cell",
    "compact_screen": "Compact screen",
    "drug_cancer_response": "Drug / cancer",
    "epithelial_cancer": "Epithelial cancer",
    "iPSC_neuron": "iPSC / neuron",
    "immune_cancer": "Immune cancer",
    "unclassified": "Unclassified",
}

PANEL_BOXES_PT = {
    "a": (28.0, 402.0, 226.2, 120.0),
    "b": (276.2, 402.0, 226.2, 120.0),
    "c": (28.0, 180.0, 226.2, 200.0),
    "d": (276.2, 180.0, 226.2, 200.0),
    "e": (28.0, 24.0, 226.2, 134.0),
    "f": (276.2, 24.0, 226.2, 134.0),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def add_axes_pt(fig: plt.Figure, box: tuple[float, float, float, float], gid: str) -> plt.Axes:
    x, y, w, h = box
    ax = fig.add_axes([x / FIG_W_PT, y / FIG_H_PT, w / FIG_W_PT, h / FIG_H_PT])
    ax.set_gid(gid)
    return ax


def fig_text_pt(
    fig: plt.Figure,
    x: float,
    y: float,
    text: str,
    *,
    gid: str,
    size: float = 7.0,
    weight: str = "normal",
    color: str = COLORS["ink"],
    ha: str = "left",
    va: str = "top",
    rotation: float = 0.0,
) -> mpl.text.Text:
    artist = fig.text(
        x / FIG_W_PT,
        y / FIG_H_PT,
        text,
        fontsize=size,
        fontweight=weight,
        color=color,
        ha=ha,
        va=va,
        rotation=rotation,
        transform=fig.transFigure,
    )
    artist.set_gid(gid)
    return artist


def add_panel_header(
    fig: plt.Figure,
    panel: str,
    title: str,
    subtitle: str,
) -> None:
    x, y, _, h = PANEL_BOXES_PT[panel]
    top = y + h
    fig_text_pt(
        fig, x, top, panel, gid=f"panel_{panel}_letter", size=10.5,
        weight="bold", va="top"
    )
    fig_text_pt(
        fig, x + 16.0, top - 0.2, title, gid=f"panel_{panel}_title",
        size=9.0, weight="semibold", va="top"
    )
    fig_text_pt(
        fig, x + 16.0, top - 12.2, subtitle, gid=f"panel_{panel}_subtitle",
        size=7.0, color=COLORS["muted"], va="top"
    )


def style_axis(ax: plt.Axes, grid: str = "") -> None:
    ax.tick_params(axis="both", labelsize=7.0, colors=COLORS["ink"], width=0.6, length=2.5, pad=2.5)
    ax.xaxis.label.set_size(7.5)
    ax.yaxis.label.set_size(7.5)
    ax.xaxis.label.set_color(COLORS["ink"])
    ax.yaxis.label.set_color(COLORS["ink"])
    for spine in ax.spines.values():
        spine.set_linewidth(0.65)
        spine.set_color(COLORS["ink"])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if grid:
        ax.grid(axis=grid, color=COLORS["grid"], linewidth=0.55, zorder=0)
    ax.set_axisbelow(True)


def validate_sources(source_dir: Path) -> dict[str, pd.DataFrame]:
    required: dict[str, set[str]] = {
        "Fig2a_contexts.csv": {"context", "n_observations", "n_datasets", "n_labels", "context_label"},
        "Fig2b_variance.csv": {"scheme", "baseline_fraction_of_raw_variance", "residual_fraction_of_raw_variance"},
        "Fig2c_context_matrix.csv": {"unsup_family", "context", "fraction_of_family_modes", "universality_index", "family_class"},
        "Fig2d_recurrence.csv": {"unsup_family", "n_modes", "n_datasets", "n_contexts", "universality_index", "family_class"},
        "Fig2e_controls.csv": {"scheme", "real_mean_cosine", "shuffle_mean_cosine", "random_mean_cosine", "real_n"},
        "Fig2e_same_label_denominators.csv": {"scheme", "generated_rows", "finite_cosine_rows", "zero_true_norm_rows", "zero_pred_norm_rows"},
        "Fig2f_robustness.csv": {"scheme", "holdout", "mean", "ci_low", "ci_high", "n_groups", "n_rows"},
    }
    tables: dict[str, pd.DataFrame] = {}
    for filename, columns in required.items():
        path = source_dir / filename
        if not path.is_file():
            raise FileNotFoundError(path)
        table = pd.read_csv(path)
        missing = columns.difference(table.columns)
        if missing:
            raise ValueError(f"{filename}: missing columns {sorted(missing)}")
        tables[filename] = table

    a = tables["Fig2a_contexts.csv"]
    b = tables["Fig2b_variance.csv"]
    c = tables["Fig2c_context_matrix.csv"]
    d = tables["Fig2d_recurrence.csv"]
    e = tables["Fig2e_controls.csv"]
    e_denominators = tables["Fig2e_same_label_denominators.csv"]
    f = tables["Fig2f_robustness.csv"]

    assertions = [
        (len(a) == 8, "panel a must contain eight context groups"),
        (int(a["n_observations"].sum()) == 2720, "panel a observation sum must be 2,720"),
        (set(b["scheme"]) == set(SCHEME_ORDER) and len(b) == 3, "panel b scheme rows invalid"),
        (len(c) == 144 and c["unsup_family"].nunique() == 16 and c["context"].nunique() == 9, "panel c must be 16 x 9"),
        (np.allclose(c.groupby("unsup_family")["fraction_of_family_modes"].sum(), 1.0, atol=5e-12, rtol=0), "panel c rows must sum to one"),
        (len(d) == 16 and d["unsup_family"].is_unique, "panel d must show all 16 families exactly once"),
        (set(e["scheme"]) == set(SCHEME_ORDER) and len(e) == 3 and set(e["real_n"]) == {1092}, "panel e rows invalid"),
        (
            e_denominators.set_index("scheme").loc[SCHEME_ORDER, "finite_cosine_rows"].astype(int).tolist() == [1092, 1092, 215],
            "panel e finite-cosine denominators invalid",
        ),
        (len(f) == 9 and set(f["scheme"]) == set(SCHEME_ORDER) and f["holdout"].nunique() == 3, "panel f must be 3 x 3"),
        ((f["ci_low"] <= f["mean"]).all() and (f["mean"] <= f["ci_high"]).all(), "panel f confidence intervals do not bracket means"),
    ]
    for ok, message in assertions:
        if not ok:
            raise ValueError(message)
    return tables


def panel_a(fig: plt.Figure, table: pd.DataFrame) -> plt.Axes:
    add_panel_header(
        fig, "a", "Perturbation observations by context",
        "PREDICT-003B · n=2,720 · 39 datasets · 8 contexts",
    )
    ax = add_axes_pt(fig, (91.0, 407.0, 157.0, 82.0), "panel_a_axes")
    work = table.sort_values("n_observations", ascending=True).reset_index(drop=True)
    y = np.arange(len(work), dtype=float)
    bars = ax.barh(y, work["n_observations"], height=0.62, color="#8CBED6", edgecolor=COLORS["context"], linewidth=0.55, zorder=2)
    for idx, bar in enumerate(bars):
        bar.set_gid(f"panel_a_bar_{idx}")
    ax.set_yticks(y)
    ax.set_yticklabels(work["context_label"].str.replace("Drug / cancer", "Drug / cancer", regex=False))
    ax.set_xlim(0, 1020)
    ax.set_xticks([0, 250, 500, 750])
    ax.axvline(735, color=COLORS["grid"], linewidth=0.75, zorder=1)
    for row, ypos in zip(work.itertuples(index=False), y):
        ax.text(760, ypos, f"{int(row.n_datasets)}", fontsize=7.0, ha="center", va="center", color=COLORS["ink"], gid=f"panel_a_datasets_{int(ypos)}")
        ax.text(965, ypos, f"{int(row.n_labels)}", fontsize=7.0, ha="center", va="center", color=COLORS["ink"], gid=f"panel_a_labels_{int(ypos)}")
    ax.text(760, len(work) - 0.15, "Datasets", fontsize=7.0, ha="center", va="bottom", color=COLORS["muted"], gid="panel_a_datasets_header")
    ax.text(965, len(work) - 0.15, "Labels", fontsize=7.0, ha="center", va="bottom", color=COLORS["muted"], gid="panel_a_labels_header")
    style_axis(ax, "x")
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0, pad=4)
    return ax


def panel_b(fig: plt.Figure, table: pd.DataFrame) -> plt.Axes:
    add_panel_header(
        fig, "b", "Raw-coordinate variance fractions",
        "PREDICT-003B · shared raw-variance denominator",
    )
    ax = add_axes_pt(fig, (348.0, 409.0, 148.0, 80.0), "panel_b_axes")
    work = table.set_index("scheme").loc[SCHEME_ORDER]
    y = np.array([2.0, 1.0, 0.0])
    for ypos, (scheme, row) in zip(y, work.iterrows()):
        residual = float(row["residual_fraction_of_raw_variance"])
        baseline = float(row["baseline_fraction_of_raw_variance"])
        ax.plot([residual, baseline], [ypos, ypos], color=COLORS["grid"], linewidth=1.2, zorder=1, gid=f"panel_b_connector_{scheme}")
        ax.scatter([residual], [ypos], s=30, marker=SCHEME_MARKER[scheme], facecolor=SCHEME_COLOR[scheme], edgecolor=COLORS["white"], linewidth=0.55, zorder=3, gid=f"panel_b_residual_{scheme}")
        ax.scatter([baseline], [ypos], s=28, marker="o", facecolor=COLORS["white"], edgecolor=COLORS["control"], linewidth=0.9, zorder=3, gid=f"panel_b_baseline_{scheme}")
        close = abs(residual - baseline) < 0.13
        ax.annotate(
            f"Residual {residual:.2f}", (residual, ypos),
            xytext=(0, 6), textcoords="offset points",
            fontsize=7.0, ha="left" if residual < 0.87 else "right", va="bottom",
            color=SCHEME_COLOR[scheme], gid=f"panel_b_residual_label_{scheme}",
        )
        ax.annotate(
            f"Baseline {baseline:.2f}", (baseline, ypos),
            xytext=(0, -6), textcoords="offset points",
            fontsize=7.0, ha="right" if baseline > 0.15 else "left", va="top",
            color=COLORS["control"], gid=f"panel_b_baseline_label_{scheme}",
        )
    ax.set_yticks(y)
    ax.set_yticklabels(["Context", "Dataset shrinkage", "Dataset"])
    ax.set_xlim(-0.01, 1.03)
    ax.set_ylim(-0.52, 2.52)
    ax.set_xticks([0, 0.25, 0.50, 0.75, 1.0])
    style_axis(ax, "x")
    ax.tick_params(axis="y", length=0, pad=4)
    return ax


def panel_c(fig: plt.Figure, table: pd.DataFrame) -> tuple[plt.Axes, plt.Axes]:
    add_panel_header(
        fig, "c", "Family distribution across contexts",
        "META-003 · 248 modes · 43 datasets · 9 contexts",
    )
    order = (
        table[["unsup_family", "universality_index"]]
        .drop_duplicates()
        .sort_values("universality_index", ascending=False)["unsup_family"]
        .astype(int).tolist()
    )
    contexts = list(dict.fromkeys(table["context"].astype(str).tolist()))
    matrix = table.pivot(index="unsup_family", columns="context", values="fraction_of_family_modes").loc[order, contexts]
    classes = table[["unsup_family", "family_class"]].drop_duplicates().set_index("unsup_family")["family_class"].to_dict()

    ax = add_axes_pt(fig, (49.0, 225.0, 163.0, 126.0), "panel_c_heatmap_axes")
    cmap = LinearSegmentedColormap.from_list("neutral_fraction", ["#FFFFFF", "#E4E7EA", "#AEB5BC", "#626B73", "#1F2933"])
    values = matrix.to_numpy(dtype=float)
    for row in range(values.shape[0]):
        for col in range(values.shape[1]):
            value = values[row, col]
            patch = Rectangle((col, row), 1.0, 1.0, facecolor=cmap(value), edgecolor=COLORS["white"], linewidth=0.28, gid=f"panel_c_cell_{row}_{col}")
            ax.add_patch(patch)
        cls = str(classes[order[row]])
        stripe = Rectangle((-0.80, row), 0.38, 1.0, facecolor=CLASS_COLOR[cls], edgecolor=COLORS["white"], linewidth=0.25, gid=f"panel_c_class_{row}")
        ax.add_patch(stripe)
        ax.text(-0.61, row + 0.5, CLASS_LABEL[cls], fontsize=7.0, fontweight="bold", ha="center", va="center", color=COLORS["white"] if cls != "context_specific" else COLORS["ink"], gid=f"panel_c_class_label_{row}")
    ax.set_xlim(-0.88, len(contexts))
    ax.set_ylim(len(order), 0)
    ax.set_aspect("auto")
    ax.set_xticks(np.arange(len(contexts)) + 0.5)
    ax.set_xticklabels([CONTEXT_SHORT.get(x, x.replace("_", " ")) for x in contexts], rotation=52, ha="right", rotation_mode="anchor")
    ax.set_yticks(np.arange(len(order)) + 0.5)
    ax.set_yticklabels([f"F{x}" for x in order])
    ax.tick_params(axis="both", length=0, pad=2.5, labelsize=7.0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.text(-0.61, -0.10, "Class", fontsize=7.0, ha="center", va="bottom", color=COLORS["muted"], gid="panel_c_class_header", clip_on=False)

    cax = add_axes_pt(fig, (228.0, 247.0, 7.0, 82.0), "panel_c_colorbar_axes")
    cax.set_xlim(0.0, 1.0)
    cax.set_ylim(0.0, 1.0)
    for index in range(64):
        lower = index / 64.0
        cax.add_patch(Rectangle((0.0, lower), 1.0, 1.0/64.0 + 1e-6, facecolor=cmap((index + 0.5)/64.0), edgecolor="none", gid=f"panel_c_colorbar_cell_{index}"))
    cax.set_xticks([])
    cax.set_yticks([0.0, 0.5, 1.0])
    cax.yaxis.tick_right()
    cax.tick_params(axis="y", labelsize=7.0, width=0.55, length=2.0, pad=2.0)
    for spine in cax.spines.values():
        spine.set_linewidth(0.55)
    fig_text_pt(fig, 231.5, 341.0, "Family-mode\nfraction", gid="panel_c_colorbar_title", size=7.0, color=COLORS["muted"], ha="center", va="bottom")
    return ax, cax


def panel_d(fig: plt.Figure, table: pd.DataFrame) -> tuple[plt.Axes, plt.Axes, plt.Axes, plt.Axes]:
    add_panel_header(
        fig, "d", "Descriptive recurrence score",
        "META-003 · all 16 families · ordered by source score",
    )
    work = table.sort_values("universality_index", ascending=False).reset_index(drop=True)
    y = np.arange(len(work), dtype=float)

    label_ax = add_axes_pt(fig, (277.0, 210.0, 20.0, 137.0), "panel_d_family_axes")
    label_ax.set_xlim(0, 1)
    label_ax.set_ylim(len(work) - 0.5, -0.5)
    for idx, family in enumerate(work["unsup_family"]):
        label_ax.text(0.95, idx, f"F{int(family)}", fontsize=7.0, ha="right", va="center", color=COLORS["ink"], gid=f"panel_d_family_{idx}")
    label_ax.set_xticks([])
    label_ax.set_yticks([])
    label_ax.axis("off")
    class_ax = add_axes_pt(fig, (300.0, 210.0, 13.0, 137.0), "panel_d_class_axes")
    class_ax.set_xlim(0, 1)
    class_ax.set_ylim(len(work) - 0.5, -0.5)
    for idx, row in work.iterrows():
        cls = str(row["family_class"])
        class_ax.add_patch(Rectangle((0.08, idx - 0.38), 0.84, 0.76, facecolor=CLASS_COLOR[cls], edgecolor=COLORS["white"], linewidth=0.25, gid=f"panel_d_class_{idx}"))
        class_ax.text(0.5, idx, CLASS_LABEL[cls], fontsize=7.0, fontweight="bold", ha="center", va="center", color=COLORS["white"] if cls != "context_specific" else COLORS["ink"], gid=f"panel_d_class_label_{idx}")
    class_ax.set_xticks([])
    class_ax.set_yticks([])
    class_ax.axis("off")
    fig_text_pt(fig, 306.5, 350.0, "Class", gid="panel_d_class_header", size=7.0, color=COLORS["muted"], ha="center", va="bottom")

    ax = add_axes_pt(fig, (319.0, 210.0, 110.0, 137.0), "panel_d_score_axes")
    scores = work["universality_index"].to_numpy(dtype=float)
    for idx, (score, row) in enumerate(zip(scores, work.itertuples(index=False))):
        ax.plot([0.0, score], [idx, idx], color="#B8BEC5", linewidth=0.8, zorder=1, gid=f"panel_d_stem_{idx}")
        ax.scatter([score], [idx], s=23, marker="o", facecolor=COLORS["ink"], edgecolor=COLORS["white"], linewidth=0.4, zorder=3, gid=f"panel_d_score_{idx}")
    ax.axvline(0, color=COLORS["grid"], linewidth=0.65, zorder=0)
    ax.set_ylim(len(work) - 0.5, -0.5)
    ax.set_xlim(-4.8, 13.2)
    ax.set_yticks([])
    ax.set_xticks([-4, 0, 4, 8, 12])
    ax.set_xlabel("Recurrence score", labelpad=2)
    style_axis(ax, "x")
    ax.tick_params(axis="y", length=0, pad=3)

    table_ax = add_axes_pt(fig, (439.0, 210.0, 60.0, 137.0), "panel_d_counts_axes")
    table_ax.set_xlim(0, 1)
    table_ax.set_ylim(len(work) - 0.5, -0.5)
    table_ax.axvline(0.49, color=COLORS["grid"], linewidth=0.55)
    for idx, row in work.iterrows():
        table_ax.text(0.24, idx, f"{int(row['n_datasets'])}", fontsize=7.0, ha="center", va="center", color=COLORS["ink"], gid=f"panel_d_datasets_{idx}")
        table_ax.text(0.75, idx, f"{int(row['n_contexts'])}", fontsize=7.0, ha="center", va="center", color=COLORS["ink"], gid=f"panel_d_contexts_{idx}")
    table_ax.set_xticks([])
    table_ax.set_yticks([])
    table_ax.axis("off")
    fig_text_pt(fig, 452.0, 350.0, "Datasets", gid="panel_d_datasets_header", size=7.0, color=COLORS["muted"], ha="center", va="bottom")
    fig_text_pt(fig, 486.0, 350.0, "Contexts", gid="panel_d_contexts_header", size=7.0, color=COLORS["muted"], ha="center", va="bottom")
    return label_ax, class_ax, ax, table_ax


def add_figure_legend(
    fig: plt.Figure,
    handles: Iterable[Line2D],
    *,
    panel: str,
    y_pt: float,
    ncol: int,
    gid: str,
) -> mpl.legend.Legend:
    x, _, w, _ = PANEL_BOXES_PT[panel]
    legend = fig.legend(
        handles=list(handles), loc="upper left",
        bbox_to_anchor=(x / FIG_W_PT, y_pt / FIG_H_PT),
        bbox_transform=fig.transFigure, ncol=ncol, frameon=False,
        fontsize=7.0, handlelength=1.0, handletextpad=0.35,
        columnspacing=0.75, borderaxespad=0.0, labelspacing=0.2,
    )
    legend.set_gid(gid)
    return legend


def panel_e(fig: plt.Figure, table: pd.DataFrame, denominators: pd.DataFrame) -> tuple[plt.Axes, mpl.legend.Legend]:
    finite_n = denominators.set_index("scheme").loc[SCHEME_ORDER, "finite_cosine_rows"].astype(int).tolist()
    add_panel_header(
        fig, "e", "Same-label transfer versus controls",
        f"Finite same-label n = {finite_n[0]:,} / {finite_n[1]:,} / {finite_n[2]:,}",
    )
    handles = [
        Line2D([], [], marker="o", linestyle="", markersize=4.8, markerfacecolor=COLORS["context"], markeredgecolor=COLORS["white"], label="Same label"),
        Line2D([], [], marker="s", linestyle="", markersize=4.6, markerfacecolor=COLORS["white"], markeredgecolor=COLORS["control"], label="Label shuffled"),
        Line2D([], [], marker="D", linestyle="", markersize=4.4, markerfacecolor=COLORS["white"], markeredgecolor=COLORS["control"], label="Random label"),
    ]
    legend = add_figure_legend(fig, handles, panel="e", y_pt=133.5, ncol=3, gid="panel_e_key")
    ax = add_axes_pt(fig, (66.0, 34.0, 181.0, 72.0), "panel_e_axes")
    work = table.set_index("scheme").loc[SCHEME_ORDER]
    x = np.arange(3, dtype=float)
    for idx, (scheme, row) in enumerate(work.iterrows()):
        values = [float(row["shuffle_mean_cosine"]), float(row["real_mean_cosine"]), float(row["random_mean_cosine"])]
        positions = [idx - 0.18, idx, idx + 0.18]
        ax.scatter([positions[1]], [values[1]], s=34, marker=SCHEME_MARKER[scheme], facecolor=SCHEME_COLOR[scheme], edgecolor=COLORS["white"], linewidth=0.55, zorder=3, gid=f"panel_e_same_{scheme}")
        ax.scatter([positions[0]], [values[0]], s=27, marker="s", facecolor=COLORS["white"], edgecolor=COLORS["control"], linewidth=0.9, zorder=3, gid=f"panel_e_shuffle_{scheme}")
        ax.scatter([positions[2]], [values[2]], s=28, marker="D", facecolor=COLORS["white"], edgecolor=COLORS["control"], linewidth=0.9, zorder=3, gid=f"panel_e_random_{scheme}")
        ax.annotate(f"{values[1]:.2f}", (positions[1], values[1]), xytext=(0, 6), textcoords="offset points", fontsize=7.0, ha="center", va="bottom", color=SCHEME_COLOR[scheme], gid=f"panel_e_value_{scheme}")
    ax.axhline(0.0, color=COLORS["control"], linewidth=0.65, linestyle=(0, (2.5, 2.5)), zorder=1, gid="panel_e_zero")
    ax.set_xlim(-0.45, 2.45)
    ax.set_ylim(-0.10, 0.66)
    ax.set_xticks(x)
    ax.set_xticklabels(["Context", "Dataset\nshrinkage", "Dataset"])
    ax.set_yticks([0.0, 0.2, 0.4, 0.6])
    ax.set_ylabel("Mean residual-vector cosine", labelpad=3)
    style_axis(ax, "y")
    return ax, legend


def panel_f(fig: plt.Figure, table: pd.DataFrame) -> tuple[plt.Axes, mpl.legend.Legend]:
    add_panel_header(
        fig, "f", "Stricter exclusions attenuate transfer",
        "PREDICT-003B · 95% bootstrap CI · 4,000× · seed 1201",
    )
    handles = [
        Line2D([], [], marker=SCHEME_MARKER[s], linestyle="", markersize=4.7, markerfacecolor=SCHEME_COLOR[s], markeredgecolor=COLORS["white"], color=SCHEME_COLOR[s], label=SCHEME_LABEL[s])
        for s in SCHEME_ORDER
    ]
    legend = add_figure_legend(fig, handles, panel="f", y_pt=133.5, ncol=3, gid="panel_f_key")
    ax = add_axes_pt(fig, (356.0, 34.0, 141.0, 79.0), "panel_f_axes")
    holdouts = ["Leave dataset out", "Exclude same-study proxy", "Leave context out"]
    ybase = np.array([2.0, 1.0, 0.0])
    offsets = {"context": 0.21, "dataset_shrink": 0.0, "dataset": -0.21}
    for scheme in SCHEME_ORDER:
        subset = table[table["scheme"] == scheme].set_index("holdout").loc[holdouts]
        y = ybase + offsets[scheme]
        means = subset["mean"].to_numpy(float)
        lows = subset["ci_low"].to_numpy(float)
        highs = subset["ci_high"].to_numpy(float)
        error = ax.errorbar(means, y, xerr=[means - lows, highs - means], fmt="none", ecolor=SCHEME_COLOR[scheme], elinewidth=0.85, capsize=2.0, capthick=0.75, zorder=2)
        data_line, cap_lines, bar_collections = error.lines
        if data_line is not None:
            data_line.set_gid(f"panel_f_interval_{scheme}_line")
        for component_index, artist in enumerate(cap_lines):
            artist.set_gid(f"panel_f_interval_{scheme}_cap_{component_index}")
        for component_index, artist in enumerate(bar_collections):
            artist.set_gid(f"panel_f_interval_{scheme}_bar_{component_index}")
        ax.scatter(means, y, s=29, marker=SCHEME_MARKER[scheme], facecolor=SCHEME_COLOR[scheme], edgecolor=COLORS["white"], linewidth=0.5, zorder=3, gid=f"panel_f_points_{scheme}")
        label_indices = range(3) if scheme == "context" else []
        for idx in label_indices:
            mean = float(means[idx])
            ypos = float(y[idx])
            if scheme == "context":
                offset, horizontal, vertical = (0, 6), "center", "bottom"
            else:
                offset, horizontal, vertical = (0, -5), "center", "top"
            ax.annotate(
                f"{mean:.2f}", (mean, ypos), xytext=offset,
                textcoords="offset points", fontsize=7.0, ha=horizontal,
                va=vertical, color=SCHEME_COLOR[scheme],
                gid=f"panel_f_value_{scheme}_{idx}",
            )
    ax.axvline(0.0, color=COLORS["control"], linewidth=0.65, linestyle=(0, (2.5, 2.5)), zorder=1, gid="panel_f_zero")
    ax.set_xlim(-0.10, 0.87)
    ax.set_ylim(-0.55, 2.72)
    ax.set_yticks(ybase)
    ax.set_yticklabels(["Leave dataset out", "Exclude same-study\nproxy", "Leave context out"])
    ax.set_xticks([0.0, 0.2, 0.4, 0.6, 0.8])
    ax.set_xlabel("Mean residual-vector cosine", labelpad=2)
    style_axis(ax, "x")
    ax.tick_params(axis="y", length=0, pad=4)
    return ax, legend


def assign_semantic_axis_text_gids(
    panel_axes: dict[str, list[plt.Axes]],
    legends: dict[str, mpl.legend.Legend],
) -> None:
    for panel, axes in panel_axes.items():
        for axis_index, ax in enumerate(axes):
            for role, artist in (("xlabel", ax.xaxis.label), ("ylabel", ax.yaxis.label), ("title", ax.title)):
                if artist.get_text().strip() and not artist.get_gid():
                    artist.set_gid(f"panel_{panel}_axis{axis_index}_{role}")
            for tick_index, artist in enumerate(ax.get_xticklabels()):
                if artist.get_text().strip() and not artist.get_gid():
                    artist.set_gid(f"panel_{panel}_axis{axis_index}_xtick_{tick_index}")
            for tick_index, artist in enumerate(ax.get_yticklabels()):
                if artist.get_text().strip() and not artist.get_gid():
                    artist.set_gid(f"panel_{panel}_axis{axis_index}_ytick_{tick_index}")
    for panel, legend in legends.items():
        for index, artist in enumerate(legend.get_texts()):
            if artist.get_text().strip() and not artist.get_gid():
                artist.set_gid(f"panel_{panel}_legend_text_{index}")


def assign_text_gids(fig: plt.Figure) -> list[mpl.text.Text]:
    texts = [
        artist for artist in fig.findobj(mpl.text.Text)
        if artist.get_visible()
        and artist.get_text().strip()
        and not (
            artist.axes is not None
            and not artist.axes.axison
            and artist not in artist.axes.texts
        )
    ]
    seen: set[str] = set()
    for idx, artist in enumerate(texts):
        gid = artist.get_gid()
        if not gid:
            gid = f"auto_text_{idx:03d}"
            artist.set_gid(gid)
        if gid in seen:
            artist.set_gid(f"{gid}_{idx:03d}")
        seen.add(artist.get_gid())
        artist.set_fontsize(max(float(artist.get_fontsize()), MIN_FONT_PT))
    return texts


def measure_layout(fig: plt.Figure, panel_axes: dict[str, list[plt.Axes]], legends: dict[str, mpl.legend.Legend], font_path: Path) -> dict[str, Any]:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    px_to_pt = 72.0 / float(fig.dpi)
    assign_semantic_axis_text_gids(panel_axes, legends)
    texts = assign_text_gids(fig)
    fig.canvas.draw()
    entries: list[dict[str, Any]] = []
    for artist in texts:
        bbox = artist.get_window_extent(renderer=renderer)
        x0, y0, x1, y1 = [float(v) * px_to_pt for v in (bbox.x0, bbox.y0, bbox.x1, bbox.y1)]
        gid = str(artist.get_gid())
        match = re.match(r"panel_([a-f])_", gid)
        entries.append({
            "gid": artist.get_gid(), "text": artist.get_text(), "font_size_pt": float(artist.get_fontsize()),
            "bbox_pt": [x0, y0, x1, y1], "panel": match.group(1) if match else None,
        })
    legend_entries: list[dict[str, Any]] = []
    for panel, legend in legends.items():
        bbox = legend.get_window_extent(renderer=renderer)
        legend_entries.append({"panel": panel, "gid": legend.get_gid(), "bbox_pt": [float(v) * px_to_pt for v in (bbox.x0, bbox.y0, bbox.x1, bbox.y1)]})
    return {
        "canvas": {"width_pt": FIG_W_PT, "height_pt": FIG_H_PT, "width_mm": FIG_W_MM, "height_mm": FIG_H_MM, "width_in": FIG_W_IN, "height_in": FIG_H_IN},
        "font": {"family": "DejaVu Sans", "path": str(font_path), "sha256": sha256(font_path)},
        "panel_boxes_pt": {k: list(v) for k, v in PANEL_BOXES_PT.items()},
        "axes_boxes_pt": {panel: [[ax.get_position().x0 * FIG_W_PT, ax.get_position().y0 * FIG_H_PT, ax.get_position().width * FIG_W_PT, ax.get_position().height * FIG_H_PT] for ax in axes] for panel, axes in panel_axes.items()},
        "texts": entries,
        "legends": legend_entries,
        "minimum_font_size_pt": min(entry["font_size_pt"] for entry in entries),
    }


def add_svg_accessibility(svg_path: Path) -> None:
    raw = svg_path.read_text(encoding="utf-8")
    raw = re.sub(r'width="[^"]+"', f'width="{FIG_W_MM:.2f}mm"', raw, count=1)
    raw = re.sub(r'height="[^"]+"', f'height="{FIG_H_MM:.2f}mm"', raw, count=1)
    title = "<title>CGT Figure 2: residual perturbation geometry and transfer limits</title>"
    desc = "<desc>Six-panel figure comparing residual-analysis composition, variance components, family context distribution, descriptive recurrence, label controls, and stricter study and context holdouts.</desc>"
    raw = raw.replace(">\n <metadata>", f">\n {title}\n {desc}\n <metadata>", 1)
    svg_path.write_text(raw, encoding="utf-8", newline="\n")


def render(source_dir: Path, output_dir: Path, qa_dir: Path) -> dict[str, Path]:
    tables = validate_sources(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    qa_dir.mkdir(parents=True, exist_ok=True)

    font_path = Path(mpl.get_data_path()) / "fonts" / "ttf" / "DejaVuSans.ttf"
    font_bold = Path(mpl.get_data_path()) / "fonts" / "ttf" / "DejaVuSans-Bold.ttf"
    for path in (font_path, font_bold):
        if not path.is_file():
            raise FileNotFoundError(path)
        fm.fontManager.addfont(path)

    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 7.0,
        "axes.labelsize": 7.5,
        "xtick.labelsize": 7.0,
        "ytick.labelsize": 7.0,
        "legend.fontsize": 7.0,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "path",
        "svg.hashsalt": "CGT_FIGURE_002_recurrent_geometry_revised_v1",
        "axes.unicode_minus": True,
    })

    fig = plt.figure(figsize=(FIG_W_IN, FIG_H_IN), dpi=PUB_DPI, facecolor=COLORS["white"])
    ax_a = panel_a(fig, tables["Fig2a_contexts.csv"])
    ax_b = panel_b(fig, tables["Fig2b_variance.csv"])
    ax_c, cax = panel_c(fig, tables["Fig2c_context_matrix.csv"])
    dax_label, dax_class, ax_d, dax_table = panel_d(fig, tables["Fig2d_recurrence.csv"])
    ax_e, legend_e = panel_e(
        fig,
        tables["Fig2e_controls.csv"],
        tables["Fig2e_same_label_denominators.csv"],
    )
    ax_f, legend_f = panel_f(fig, tables["Fig2f_robustness.csv"])
    panel_axes = {
        "a": [ax_a], "b": [ax_b], "c": [ax_c, cax],
        "d": [dax_label, dax_class, ax_d, dax_table], "e": [ax_e], "f": [ax_f],
    }
    legends = {"e": legend_e, "f": legend_f}
    layout = measure_layout(fig, panel_axes, legends, font_path)
    layout_path = qa_dir / "CGT_FIGURE_002_layout_registry.json"
    layout_path.write_text(json.dumps(layout, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    stem = "CGT_FIGURE_002_recurrent_geometry_revised"
    publication_png = output_dir / f"{stem}_600dpi.png"
    web_png = output_dir / f"{stem}_web.png"
    pdf_path = output_dir / f"{stem}.pdf"
    svg_path = output_dir / f"{stem}.svg"
    qa_svg = qa_dir / f"{stem}_editable_text_qa.svg"

    fig.savefig(publication_png, dpi=PUB_DPI, facecolor=COLORS["white"], edgecolor=COLORS["white"], metadata={"Software": f"Matplotlib {mpl.__version__}", "Title": "CGT Figure 2 revised"})
    fig.savefig(
        pdf_path,
        facecolor=COLORS["white"],
        edgecolor=COLORS["white"],
        metadata={
            "Title": "CGT Figure 2 revised",
            "Author": "John Patrick Collins",
            "Subject": "Constraint Geometry Theory",
            "CreationDate": FIXED_DOCUMENT_DATE,
            "ModDate": FIXED_DOCUMENT_DATE,
        },
    )
    fig.savefig(
        svg_path,
        facecolor=COLORS["white"],
        edgecolor=COLORS["white"],
        metadata={"Title": "CGT Figure 2 revised", "Date": "2026-08-20T00:00:00Z"},
    )
    add_svg_accessibility(svg_path)

    with mpl.rc_context({"svg.fonttype": "none"}):
        fig.savefig(
            qa_svg,
            facecolor=COLORS["white"],
            edgecolor=COLORS["white"],
            metadata={"Title": "CGT Figure 2 revised QA text SVG", "Date": "2026-08-20T00:00:00Z"},
        )
    add_svg_accessibility(qa_svg)
    plt.close(fig)

    with Image.open(publication_png) as image:
        image.load()
        rgb = image.convert("RGB")
        if rgb.size != (4320, 4500):
            raise RuntimeError(f"publication PNG size {rgb.size}, expected (4320, 4500)")
        temporary_png = publication_png.with_name(publication_png.stem + ".tmp.png")
        rgb.save(temporary_png, format="PNG", dpi=(PUB_DPI, PUB_DPI), icc_profile=SRGB_ICC_PROFILE, optimize=False)
        temporary_png.replace(publication_png)
        web = rgb.resize(WEB_SIZE, Image.Resampling.LANCZOS)
        web.save(web_png, format="PNG", dpi=(WEB_SIZE[0] / FIG_W_IN, WEB_SIZE[1] / FIG_H_IN), icc_profile=SRGB_ICC_PROFILE, optimize=False)

    render_meta = {
        "renderer": {"matplotlib": mpl.__version__, "pandas": pd.__version__, "numpy": np.__version__, "pillow": Image.__version__ if hasattr(Image, "__version__") else "unknown"},
        "source_files": {path.name: {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in sorted(source_dir.glob("Fig2*.csv"))},
        "outputs": {path.name: {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in (publication_png, web_png, pdf_path, svg_path, qa_svg, layout_path)},
    }
    metadata_path = qa_dir / "CGT_FIGURE_002_render_metadata.json"
    metadata_path.write_text(json.dumps(render_meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return {"publication_png": publication_png, "web_png": web_png, "pdf": pdf_path, "svg": svg_path, "qa_svg": qa_svg, "layout": layout_path, "metadata": metadata_path}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--qa-dir", type=Path, required=True)
    args = parser.parse_args()
    outputs = render(args.source_dir, args.output_dir, args.qa_dir)
    print(json.dumps({key: str(value) for key, value in outputs.items()}, indent=2))


if __name__ == "__main__":
    main()
