#!/usr/bin/env python3
"""Cross-format, geometry, text, and release preflight for revised CGT Figure 2."""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import os
import re
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import binary_dilation, distance_transform_edt, gaussian_filter


FIG_W_PT = 518.4
FIG_H_PT = 540.0
FIG_W_MM = 182.88
FIG_H_MM = 190.50
PUB_SIZE = (4320, 4500)
WEB_SIZE = (2400, 2500)
SAFE_PT = 12.0
TEXT_CLEARANCE_PT = 3.0
INTERPANEL_CLEARANCE_PT = 14.0


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(command: list[str], *, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    base = Path(tempfile.gettempdir()) / "cgt_figure_002_xdg"
    for name, child in (("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"), ("XDG_DATA_HOME", "data")):
        target = base / child
        target.mkdir(parents=True, exist_ok=True)
        env[name] = str(target)
    result = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True)
    if result.returncode != 0:
        raise RuntimeError(f"command failed ({result.returncode}): {' '.join(command)}\n{result.stdout}\n{result.stderr}")
    return result


def bbox_overlap(a: list[float], b: list[float]) -> tuple[float, float]:
    return min(a[2], b[2]) - max(a[0], b[0]), min(a[3], b[3]) - max(a[1], b[1])


def bbox_distance(a: list[float], b: list[float]) -> float:
    dx = max(a[0] - b[2], b[0] - a[2], 0.0)
    dy = max(a[1] - b[3], b[1] - a[3], 0.0)
    return float(math.hypot(dx, dy))


def normalized_text(value: str) -> str:
    value = value.casefold().replace("−", "-").replace("–", "-").replace("—", "-")
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return " ".join(value.split())


def parse_svg(svg: Path, qa_svg: Path) -> dict[str, Any]:
    root = ET.parse(svg).getroot()
    qa_root = ET.parse(qa_svg).getroot()
    ids: list[str] = []
    external_refs: list[str] = []
    forbidden: list[str] = []
    release_text = 0
    release_images = 0
    for element in root.iter():
        tag = element.tag.rsplit("}", 1)[-1]
        if element.get("id"):
            ids.append(str(element.get("id")))
        if tag in {"script", "foreignObject"}:
            forbidden.append(tag)
        if tag == "text":
            release_text += 1
        if tag == "image":
            release_images += 1
        for key, value in element.attrib.items():
            if key.endswith("href") and value and not value.startswith("#"):
                external_refs.append(value)
            if "url(" in value:
                for match in re.findall(r"url\(([^)]+)\)", value):
                    cleaned = match.strip(" '\"")
                    if not cleaned.startswith("#"):
                        external_refs.append(cleaned)
    qa_text_elements = [e for e in qa_root.iter() if e.tag.rsplit("}", 1)[-1] == "text"]
    qa_clipped_text = [e.get("id") for e in qa_text_elements if "clip-path" in e.attrib]
    viewbox = [float(x) for x in root.attrib.get("viewBox", "").replace(",", " ").split()]
    return {
        "status": "pass" if (
            len(ids) == len(set(ids)) and not external_refs and not forbidden and release_images == 0
            and release_text == 0 and len(qa_text_elements) > 0 and not qa_clipped_text
            and viewbox == [0.0, 0.0, FIG_W_PT, FIG_H_PT]
            and root.attrib.get("width") == f"{FIG_W_MM:.2f}mm"
            and root.attrib.get("height") == f"{FIG_H_MM:.2f}mm"
        ) else "fail",
        "width": root.attrib.get("width"), "height": root.attrib.get("height"), "viewBox": viewbox,
        "unique_ids": len(ids) == len(set(ids)), "id_count": len(ids),
        "external_references": sorted(set(external_refs)), "forbidden_elements": forbidden,
        "release_text_elements": release_text, "release_image_elements": release_images,
        "qa_text_elements": len(qa_text_elements), "qa_clipped_text": qa_clipped_text,
        "has_title": any(e.tag.rsplit("}", 1)[-1] == "title" for e in root),
        "has_desc": any(e.tag.rsplit("}", 1)[-1] == "desc" for e in root),
    }


def parse_inkscape_query(svg: Path) -> dict[str, list[float]]:
    output = run(["inkscape", str(svg), "--query-all"]).stdout
    results: dict[str, list[float]] = {}
    for line in output.splitlines():
        parts = next(csv.reader([line]))
        if len(parts) != 5:
            continue
        try:
            results[parts[0]] = [float(value) * 72.0 / 96.0 for value in parts[1:]]
        except ValueError:
            continue
    return results


def exact_tick_clearance(svg: Path, query: dict[str, list[float]], qa_dir: Path) -> dict[str, Any]:
    tick_dir = qa_dir / "exact_text_masks"
    tick_dir.mkdir(parents=True, exist_ok=True)
    items: dict[str, tuple[int, int, np.ndarray]] = {}
    ids = [f"panel_c_axis0_xtick_{index}" for index in range(9)]
    for gid in ids:
        if gid not in query:
            raise AssertionError(f"missing SVG query id {gid}")
        path = tick_dir / f"{gid}.png"
        run([
            "inkscape", str(svg), f"--export-id={gid}", "--export-id-only",
            "--export-background-opacity=0", "--export-dpi=600", f"--export-filename={path}",
        ])
        x_css = query[gid][0] * 96.0 / 72.0
        y_css = query[gid][1] * 96.0 / 72.0
        with Image.open(path) as image:
            alpha = np.array(image.convert("RGBA"), dtype=np.uint8)[:, :, 3] > 10
        items[gid] = (round(x_css * 600.0 / 96.0), round(y_css * 600.0 / 96.0), alpha)
    pairs = []
    minimum = float("inf")
    for left, right in zip(ids[:-1], ids[1:]):
        x1, y1, a = items[left]
        x2, y2, b = items[right]
        x0, y0 = min(x1, x2), min(y1, y2)
        xr = max(x1 + a.shape[1], x2 + b.shape[1])
        yr = max(y1 + a.shape[0], y2 + b.shape[0])
        mask_a = np.zeros((yr - y0, xr - x0), dtype=bool)
        mask_b = np.zeros_like(mask_a)
        mask_a[y1-y0:y1-y0+a.shape[0], x1-x0:x1-x0+a.shape[1]] = a
        mask_b[y2-y0:y2-y0+b.shape[0], x2-x0:x2-x0+b.shape[1]] = b
        overlap = int(np.logical_and(mask_a, mask_b).sum())
        distance_px = float(distance_transform_edt(~mask_a)[mask_b].min())
        distance_pt = distance_px * 72.0 / 600.0
        minimum = min(minimum, distance_pt)
        pairs.append({"left": left, "right": right, "overlap_pixels": overlap, "clearance_pt": distance_pt})
    return {"status": "pass" if minimum >= TEXT_CLEARANCE_PT and all(p["overlap_pixels"] == 0 for p in pairs) else "fail", "minimum_clearance_pt": minimum, "required_clearance_pt": TEXT_CLEARANCE_PT, "pairs": pairs}


def layout_audit(layout_path: Path, svg: Path, qa_dir: Path) -> dict[str, Any]:
    layout = json.loads(layout_path.read_text(encoding="utf-8"))
    texts = layout["texts"]
    query = parse_inkscape_query(svg)
    canvas_failures = []
    for text in texts:
        b = text["bbox_pt"]
        if b[0] < SAFE_PT or b[1] < SAFE_PT or b[2] > FIG_W_PT - SAFE_PT or b[3] > FIG_H_PT - SAFE_PT:
            canvas_failures.append(text["gid"])

    overlaps = []
    rotated_candidates = []
    for left, right in itertools.combinations(texts, 2):
        ix, iy = bbox_overlap(left["bbox_pt"], right["bbox_pt"])
        if ix <= 0 or iy <= 0:
            continue
        pair = {"left": left["gid"], "right": right["gid"], "intersection_pt": [ix, iy]}
        if left["gid"].startswith("panel_c_axis0_xtick_") and right["gid"].startswith("panel_c_axis0_xtick_"):
            rotated_candidates.append(pair)
        else:
            overlaps.append(pair)

    exact = exact_tick_clearance(svg, query, qa_dir)

    title_clearances = {}
    for panel in "abcdef":
        letter = next(t for t in texts if t["gid"] == f"panel_{panel}_letter")
        title = next(t for t in texts if t["gid"] == f"panel_{panel}_title")
        title_clearances[panel] = bbox_distance(letter["bbox_pt"], title["bbox_pt"])

    interpanel = []
    for left, right in itertools.combinations(texts, 2):
        if not left.get("panel") or not right.get("panel") or left["panel"] == right["panel"]:
            continue
        distance = bbox_distance(left["bbox_pt"], right["bbox_pt"])
        if distance < 40:
            interpanel.append({"left": left["gid"], "right": right["gid"], "distance_pt": distance})
    min_interpanel = min((item["distance_pt"] for item in interpanel), default=float("inf"))

    legend_checks = []
    axes_by_panel = layout["axes_boxes_pt"]
    for legend in layout["legends"]:
        lb = legend["bbox_pt"]
        panel = legend["panel"]
        intersections = []
        for index, (x, y, w, h) in enumerate(axes_by_panel[panel]):
            ix, iy = bbox_overlap(lb, [x, y, x+w, y+h])
            if ix > 0 and iy > 0:
                intersections.append(index)
        legend_checks.append({"panel": panel, "gid": legend["gid"], "data_axes_intersections": intersections, "status": "pass" if not intersections else "fail"})

    semantic_bounds_failures = []
    for gid, (x, y, w, h) in query.items():
        if not gid.startswith("panel_"):
            continue
        if x < -0.02 or y < -0.02 or x + w > FIG_W_PT + 0.02 or y + h > FIG_H_PT + 0.02:
            semantic_bounds_failures.append({"gid": gid, "bbox_pt": [x, y, w, h]})

    rule_status = {
        "minimum_font_size": layout["minimum_font_size_pt"] >= 7.0,
        "canvas_text_containment": not canvas_failures,
        "text_text_overlap": not overlaps and exact["status"] == "pass",
        "legend_data_overlap": all(x["status"] == "pass" for x in legend_checks),
        "panel_letter_title_clearance": min(title_clearances.values()) >= 6.0,
        "interpanel_text_clearance": min_interpanel >= INTERPANEL_CLEARANCE_PT,
        "semantic_svg_canvas_containment": not semantic_bounds_failures,
        "colorbar_heatmap_clearance": (228.0 - (49.0 + 163.0)) >= 6.0,
    }
    return {
        "status": "pass" if all(rule_status.values()) else "fail",
        "rules": rule_status,
        "minimum_font_size_pt": layout["minimum_font_size_pt"],
        "minimum_outer_text_clearance_pt": min(
            min(t["bbox_pt"][0], t["bbox_pt"][1], FIG_W_PT - t["bbox_pt"][2], FIG_H_PT - t["bbox_pt"][3]) for t in texts
        ),
        "canvas_failures": canvas_failures,
        "bbox_overlaps_requiring_failure": overlaps,
        "bbox_overlap_candidates_resolved_by_exact_masks": rotated_candidates,
        "exact_rotated_tick_masks": exact,
        "panel_letter_title_clearance_pt": title_clearances,
        "minimum_interpanel_text_clearance_pt": min_interpanel,
        "minimum_required_interpanel_clearance_pt": INTERPANEL_CLEARANCE_PT,
        "legend_checks": legend_checks,
        "semantic_svg_canvas_failures": semantic_bounds_failures,
        "inkscape_semantic_gid_count": sum(1 for gid in query if gid.startswith("panel_")),
    }


def pdf_audit(pdf: Path, qa_dir: Path) -> dict[str, Any]:
    from pypdf import PdfReader
    reader = PdfReader(str(pdf))
    pages = len(reader.pages)
    box = reader.pages[0].mediabox
    width = float(box.width)
    height = float(box.height)
    fonts_out = run(["pdffonts", str(pdf)]).stdout
    font_rows = []
    for line in fonts_out.splitlines()[2:]:
        match = re.match(
            r"^(\S+)\s{2,}(.+?)\s{2,}(\S+)\s{2,}(yes|no)\s+(yes|no)\s+(yes|no)\s+(\d+)\s+(\d+)$",
            line.strip(),
        )
        if match:
            font_rows.append({
                "name": match.group(1), "type": match.group(2), "encoding": match.group(3),
                "embedded": match.group(4), "subset": match.group(5), "unicode": match.group(6),
                "object_id": [int(match.group(7)), int(match.group(8))],
            })
    text_path = qa_dir / "CGT_FIGURE_002_pdf_text.txt"
    run(["pdftotext", str(pdf), str(text_path)])
    text = text_path.read_text(encoding="utf-8", errors="replace")
    expected = [
        "Perturbation observations by context", "Raw-coordinate variance fractions",
        "Family distribution across contexts", "Descriptive recurrence score",
        "Same-label transfer versus controls", "Stricter exclusions attenuate transfer",
        "Datasets", "Labels", "Recurrence score", "Leave dataset out",
    ]
    normalized = normalized_text(text)
    missing = [token for token in expected if normalized_text(token) not in normalized]
    status = (
        pages == 1 and abs(width - FIG_W_PT) <= 0.02 and abs(height - FIG_H_PT) <= 0.02
        and bool(font_rows) and all(row["embedded"] == "yes" and row["subset"] == "yes" and "Type 3" not in row["type"] for row in font_rows)
        and not missing
    )
    return {"status": "pass" if status else "fail", "pages": pages, "page_size_pt": [width, height], "fonts": font_rows, "text_presence_expected": expected, "text_presence_missing": missing, "pdffonts_raw": fonts_out}


def png_audit(path: Path, expected_size: tuple[int, int], expected_dpi: float, *, safe_band: bool) -> dict[str, Any]:
    with Image.open(path) as image:
        rgb = image.convert("RGB")
        dpi = image.info.get("dpi", (None, None))
        icc = image.info.get("icc_profile")
        array = np.asarray(rgb, dtype=np.uint8)
        foreground = np.any(array < 250, axis=2)
        border_pixels = None
        if safe_band:
            band = round(SAFE_PT / 72.0 * expected_dpi)
            border = np.zeros(foreground.shape, dtype=bool)
            border[:band, :] = True
            border[-band:, :] = True
            border[:, :band] = True
            border[:, -band:] = True
            border_pixels = int(np.logical_and(foreground, border).sum())
        dpi_ok = dpi[0] is not None and abs(float(dpi[0]) - expected_dpi) <= 0.5 and abs(float(dpi[1]) - expected_dpi) <= 0.5
        ok = image.size == expected_size and image.mode == "RGB" and dpi_ok and bool(icc) and (border_pixels in (None, 0))
        return {
            "status": "pass" if ok else "fail", "size_px": list(image.size), "mode": image.mode,
            "dpi": list(dpi) if dpi[0] is not None else None, "expected_dpi": expected_dpi,
            "icc_profile_bytes": len(icc) if icc else 0, "safe_band_pt": SAFE_PT if safe_band else None,
            "foreground_pixels_in_safe_band": border_pixels,
        }


def ssim_global(a: np.ndarray, b: np.ndarray) -> float:
    a = a.astype(np.float32) / 255.0
    b = b.astype(np.float32) / 255.0
    a = gaussian_filter(a, sigma=0.5)
    b = gaussian_filter(b, sigma=0.5)
    mu_a, mu_b = float(a.mean()), float(b.mean())
    va, vb = float(a.var()), float(b.var())
    cov = float(((a - mu_a) * (b - mu_b)).mean())
    c1 = 0.01 ** 2
    c2 = 0.03 ** 2
    return ((2 * mu_a * mu_b + c1) * (2 * cov + c2)) / ((mu_a * mu_a + mu_b * mu_b + c1) * (va + vb + c2))


def load_luma(path: Path, size: tuple[int, int] = (1200, 1250)) -> np.ndarray:
    with Image.open(path) as image:
        return np.asarray(image.convert("L").resize(size, Image.Resampling.LANCZOS), dtype=np.uint8)


def crop_panel(array: np.ndarray, box_pt: list[float]) -> np.ndarray:
    x, y, w, h = box_pt
    scale_x = array.shape[1] / FIG_W_PT
    scale_y = array.shape[0] / FIG_H_PT
    left = max(0, round(x * scale_x))
    right = min(array.shape[1], round((x + w) * scale_x))
    top = max(0, round((FIG_H_PT - (y + h)) * scale_y))
    bottom = min(array.shape[0], round((FIG_H_PT - y) * scale_y))
    return array[top:bottom, left:right]


def cross_format(pub: Path, pdf: Path, svg: Path, qa_dir: Path, panel_boxes: dict[str, list[float]]) -> dict[str, Any]:
    def render_pdf_atomic(dpi: int, target: Path) -> None:
        failures: list[str] = []
        for attempt in range(1, 4):
            with tempfile.TemporaryDirectory(prefix=f"poppler_{dpi}_", dir=qa_dir) as temporary:
                base = Path(temporary) / "render"
                run(["pdftoppm", "-png", "-r", str(dpi), "-singlefile", str(pdf), str(base)])
                candidate = base.with_suffix(".png")
                try:
                    with Image.open(candidate) as image:
                        image.verify()
                    with Image.open(candidate) as image:
                        image.load()
                        expected = PUB_SIZE if dpi == 600 else (PUB_SIZE[0] // 2, PUB_SIZE[1] // 2)
                        if image.size != expected:
                            raise AssertionError(f"{image.size} != {expected}")
                except Exception as error:
                    failures.append(f"attempt {attempt}: {error!r}")
                    continue
                candidate.replace(target)
                return
        raise RuntimeError(f"Poppler produced no complete {dpi}-dpi PNG: {'; '.join(failures)}")

    pdf_png = qa_dir / "CGT_FIGURE_002_pdf_poppler_600dpi.png"
    pdf300_png = qa_dir / "CGT_FIGURE_002_pdf_poppler_300dpi.png"
    render_pdf_atomic(600, pdf_png)
    render_pdf_atomic(300, pdf300_png)
    svg_png = qa_dir / "CGT_FIGURE_002_svg_inkscape_600dpi.png"
    run(["inkscape", str(svg), f"--export-filename={svg_png}", f"--export-width={PUB_SIZE[0]}", f"--export-height={PUB_SIZE[1]}"])
    for path in (pdf_png, svg_png):
        with Image.open(path) as image:
            if image.size != PUB_SIZE:
                raise AssertionError(f"{path.name}: {image.size} != {PUB_SIZE}")

    pub_l = load_luma(pub)
    pdf_l = load_luma(pdf_png)
    svg_l = load_luma(svg_png)
    comparisons = {}
    for name, other in (("pdf_vs_png", pdf_l), ("svg_vs_png", svg_l), ("pdf_vs_svg", svg_l)):
        reference = pdf_l if name == "pdf_vs_svg" else pub_l
        ssim = ssim_global(reference, other)
        foreground_ref = float((reference < 245).mean())
        foreground_other = float((other < 245).mean())
        ink_delta = abs(foreground_ref - foreground_other) / max(foreground_ref, 1e-12)
        ref_mask = binary_dilation(reference < 245, iterations=2)
        other_mask = binary_dilation(other < 245, iterations=2)
        union = np.logical_or(ref_mask, other_mask).sum()
        iou = float(np.logical_and(ref_mask, other_mask).sum() / max(union, 1))
        comparisons[name] = {"ssim_1200px": ssim, "foreground_fraction_relative_delta": ink_delta, "foreground_iou_after_2px_dilation": iou}

    per_panel = {}
    for panel, box in panel_boxes.items():
        ref = crop_panel(pub_l, box)
        pdf_crop = crop_panel(pdf_l, box)
        svg_crop = crop_panel(svg_l, box)
        per_panel[panel] = {"pdf_vs_png_ssim": ssim_global(ref, pdf_crop), "svg_vs_png_ssim": ssim_global(ref, svg_crop)}

    with Image.open(pub) as a_img, Image.open(pdf_png) as b_img:
        a = np.asarray(a_img.convert("RGB").resize((1200, 1250), Image.Resampling.LANCZOS), dtype=np.int16)
        b = np.asarray(b_img.convert("RGB").resize((1200, 1250), Image.Resampling.LANCZOS), dtype=np.int16)
        diff = np.abs(a - b).astype(np.uint8)
        amplified = np.clip(diff * 5, 0, 255).astype(np.uint8)
        Image.fromarray(amplified, "RGB").save(qa_dir / "CGT_FIGURE_002_pdf_png_difference_5x.png")

    all_ssim = [v["ssim_1200px"] for v in comparisons.values()]
    panel_ssim = [score for values in per_panel.values() for score in values.values()]
    max_ink = max(v["foreground_fraction_relative_delta"] for v in comparisons.values())
    min_iou = min(v["foreground_iou_after_2px_dilation"] for v in comparisons.values())
    ok = min(all_ssim) >= 0.970 and min(panel_ssim) >= 0.960 and max_ink <= 0.0175 and min_iou >= 0.950
    return {
        "status": "pass" if ok else "fail", "renders": {"pdf_600dpi": str(pdf_png), "pdf_300dpi": str(pdf300_png), "svg_600dpi": str(svg_png)},
        "comparisons": comparisons, "per_panel": per_panel,
        "thresholds": {"global_ssim": 0.970, "panel_ssim": 0.960, "foreground_relative_delta": 0.0175, "foreground_iou_after_2px_dilation": 0.950},
    }


def cvd_transform(image: Image.Image, matrix: np.ndarray) -> Image.Image:
    array = np.asarray(image.convert("RGB"), dtype=np.float32) / 255.0
    transformed = np.clip(array @ matrix.T, 0.0, 1.0)
    return Image.fromarray(np.round(transformed * 255).astype(np.uint8), "RGB")


def label_image(image: Image.Image, label: str, width: int, font: ImageFont.FreeTypeFont) -> Image.Image:
    thumb = image.copy()
    thumb.thumbnail((width, int(width * 1.15)), Image.Resampling.LANCZOS)
    card = Image.new("RGB", (width + 20, thumb.height + 62), "white")
    card.paste(thumb, ((card.width - thumb.width)//2, 46))
    draw = ImageDraw.Draw(card)
    draw.text((10, 8), label, fill="#17212B", font=font)
    draw.rectangle((0, 0, card.width-1, card.height-1), outline="#C9CED3", width=2)
    return card


def make_qa_assets(pub: Path, web: Path, cross: dict[str, Any], qa_dir: Path, panel_boxes: dict[str, list[float]]) -> dict[str, Any]:
    font_path = Path(__import__("matplotlib").get_data_path()) / "fonts" / "ttf" / "DejaVuSans.ttf"
    font = ImageFont.truetype(str(font_path), 28)
    with Image.open(pub) as image:
        full = image.convert("RGB")
        downscales = {}
        for width in (2400, 1600, 1200, 800, 480):
            height = round(width * PUB_SIZE[1] / PUB_SIZE[0])
            resized = full.resize((width, height), Image.Resampling.LANCZOS)
            path = qa_dir / f"CGT_FIGURE_002_downscale_{width}px.png"
            resized.save(path, dpi=(width / 7.2, width / 7.2))
            downscales[str(width)] = str(path)

        panel_paths = {}
        panel_cards = []
        crop_boxes = {
            "a": [28.0, 390.0, 226.2, 132.0],
            "b": [276.2, 390.0, 226.2, 132.0],
            "c": [28.0, 160.0, 226.2, 220.0],
            "d": [276.2, 178.0, 226.2, 202.0],
            "e": [28.0, 12.0, 226.2, 146.0],
            "f": [276.2, 12.0, 226.2, 146.0],
        }
        for panel, box in crop_boxes.items():
            x, y, w, h = box
            scale = 600.0 / 72.0
            crop = full.crop((round(x*scale), round((FIG_H_PT-y-h)*scale), round((x+w)*scale), round((FIG_H_PT-y)*scale)))
            path = qa_dir / f"CGT_FIGURE_002_panel_{panel}_crop_600dpi.png"
            crop.save(path, dpi=(600, 600))
            panel_paths[panel] = str(path)
            panel_cards.append(label_image(crop, f"Panel {panel}", 900, font))

        hotspot_boxes = {
            "panel_b_header_values": [276.2, 402.0, 226.2, 120.0],
            "panel_c_labels_colorbar": [28.0, 160.0, 226.2, 115.0],
            "panel_d_full": [276.2, 180.0, 226.2, 200.0],
            "panel_e_key_zero": [28.0, 24.0, 226.2, 134.0],
            "panel_f_title_intervals": [276.2, 24.0, 226.2, 134.0],
        }
        hotspot_paths = {}
        for name, (x, y, w, h) in hotspot_boxes.items():
            scale = 600.0 / 72.0
            crop = full.crop((round(x*scale), round((FIG_H_PT-y-h)*scale), round((x+w)*scale), round((FIG_H_PT-y)*scale)))
            path = qa_dir / f"CGT_FIGURE_002_hotspot_{name}.png"
            crop.save(path, dpi=(600, 600))
            hotspot_paths[name] = str(path)

        matrices = {
            "protanopia": np.array([[0.567,0.433,0],[0.558,0.442,0],[0,0.242,0.758]], dtype=np.float32),
            "deuteranopia": np.array([[0.625,0.375,0],[0.7,0.3,0],[0,0.3,0.7]], dtype=np.float32),
            "tritanopia": np.array([[0.95,0.05,0],[0,0.433,0.567],[0,0.475,0.525]], dtype=np.float32),
        }
        accessibility_cards = [label_image(full.convert("L").convert("RGB"), "Grayscale", 700, font)]
        accessibility_paths = {}
        for name, matrix in matrices.items():
            simulated = cvd_transform(full.resize(WEB_SIZE, Image.Resampling.LANCZOS), matrix)
            path = qa_dir / f"CGT_FIGURE_002_{name}.png"
            simulated.save(path)
            accessibility_paths[name] = str(path)
            accessibility_cards.append(label_image(simulated, name.capitalize(), 700, font))

    full_cards = []
    for label, path in (
        ("Direct PNG", pub),
        ("PDF via Poppler", Path(cross["renders"]["pdf_600dpi"])),
        ("SVG via Inkscape", Path(cross["renders"]["svg_600dpi"])),
    ):
        with Image.open(path) as image:
            full_cards.append(label_image(image.convert("RGB"), label, 760, font))

    rows: list[list[Image.Image]] = [full_cards, panel_cards[:3], panel_cards[3:], accessibility_cards]
    row_widths = [sum(card.width for card in row) + 20 * (len(row)-1) for row in rows]
    row_heights = [max(card.height for card in row) for row in rows]
    canvas = Image.new("RGB", (max(row_widths)+40, sum(row_heights)+20*(len(rows)-1)+40), "#EEF1F4")
    y = 20
    for row, row_width, row_height in zip(rows, row_widths, row_heights):
        x = (canvas.width - row_width)//2
        for card in row:
            canvas.paste(card, (x, y))
            x += card.width + 20
        y += row_height + 20
    contact = qa_dir / "CGT_FIGURE_002_visual_audit_contact_sheet.png"
    canvas.save(contact)
    return {"contact_sheet": str(contact), "downscales": downscales, "panel_crops": panel_paths, "hotspot_crops": hotspot_paths, "color_vision_simulations": accessibility_paths}


def ocr_audit(pub: Path, qa_dir: Path, panel_boxes: dict[str, list[float]]) -> dict[str, Any]:
    combined = []
    targets = [pub] + [qa_dir / f"CGT_FIGURE_002_panel_{p}_crop_600dpi.png" for p in "abcdef"]
    for index, target in enumerate(targets):
        result = run(["tesseract", str(target), "stdout", "--dpi", "600", "--psm", "11"])
        combined.append(result.stdout)
        (qa_dir / f"CGT_FIGURE_002_ocr_{index}.txt").write_text(result.stdout, encoding="utf-8")
    text = "\n".join(combined)
    normalized = normalized_text(text)
    expected = [
        "Perturbation observations by context", "Raw-coordinate variance fractions",
        "Family distribution across contexts", "Descriptive recurrence score",
        "Same-label transfer versus controls", "Stricter exclusions attenuate transfer",
        "Dataset shrinkage", "Recurrence score", "Leave dataset out", "Leave context out",
    ]
    recovered = {token: normalized_text(token) in normalized for token in expected}
    coverage = sum(recovered.values()) / len(recovered)
    return {"status": "pass" if coverage >= 0.9 else "review", "expected": expected, "recovered": recovered, "coverage": coverage, "note": "OCR is secondary evidence; PDF text extraction and SVG semantic IDs are authoritative for presence."}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--qa-dir", type=Path, required=True)
    parser.add_argument("--layout", type=Path, required=True)
    parser.add_argument("--science", type=Path, required=True)
    parser.add_argument("--human-review", type=Path)
    parser.add_argument("--audit-output", type=Path, required=True)
    args = parser.parse_args()
    args.qa_dir.mkdir(parents=True, exist_ok=True)

    stem = "CGT_FIGURE_002_recurrent_geometry_revised"
    paths = {
        "web_png": args.output_dir / f"{stem}_web.png",
        "publication_png": args.output_dir / f"{stem}_600dpi.png",
        "pdf": args.output_dir / f"{stem}.pdf",
        "svg": args.output_dir / f"{stem}.svg",
        "qa_svg": args.qa_dir / f"{stem}_editable_text_qa.svg",
    }
    missing = [str(path) for path in paths.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(missing)
    layout_data = json.loads(args.layout.read_text(encoding="utf-8"))
    science = json.loads(args.science.read_text(encoding="utf-8"))
    svg_result = parse_svg(paths["svg"], paths["qa_svg"])
    geometry = layout_audit(args.layout, paths["svg"], args.qa_dir)
    pdf_result = pdf_audit(paths["pdf"], args.qa_dir)
    png_results = {
        "publication": png_audit(paths["publication_png"], PUB_SIZE, 600.0, safe_band=True),
        "web": png_audit(paths["web_png"], WEB_SIZE, WEB_SIZE[0] / 7.2, safe_band=False),
    }
    cross = cross_format(paths["publication_png"], paths["pdf"], paths["svg"], args.qa_dir, layout_data["panel_boxes_pt"])
    visual_assets = make_qa_assets(paths["publication_png"], paths["web_png"], cross, args.qa_dir, layout_data["panel_boxes_pt"])
    ocr = ocr_audit(paths["publication_png"], args.qa_dir, layout_data["panel_boxes_pt"])
    human = None
    if args.human_review and args.human_review.is_file():
        human = json.loads(args.human_review.read_text(encoding="utf-8"))
    else:
        human = {"status": "pending", "checklist": {}}

    mandatory = {
        "scientific_recomputation": science.get("status") == "pass",
        "geometry": geometry["status"] == "pass",
        "svg": svg_result["status"] == "pass",
        "pdf": pdf_result["status"] == "pass",
        "publication_png": png_results["publication"]["status"] == "pass",
        "web_png": png_results["web"]["status"] == "pass",
        "cross_format": cross["status"] == "pass",
        "ocr_or_text_presence": ocr["status"] in {"pass", "review"} and not pdf_result["text_presence_missing"],
        "human_visual_review": human.get("status") == "pass",
    }
    report = {
        "status": "pass" if all(mandatory.values()) else "fail",
        "generated_utc": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
        "canvas": {"pt": [FIG_W_PT, FIG_H_PT], "mm": [FIG_W_MM, FIG_H_MM], "px_600dpi": list(PUB_SIZE), "px_web": list(WEB_SIZE)},
        "mandatory_rules": mandatory,
        "science": science,
        "geometry": geometry,
        "svg": svg_result,
        "pdf": pdf_result,
        "png": png_results,
        "cross_format": cross,
        "ocr": ocr,
        "human_visual_review": human,
        "visual_assets": visual_assets,
        "core_artifacts": {name: {"filename": path.name, "bytes": path.stat().st_size, "sha256": sha256(path)} for name, path in paths.items()},
    }
    args.audit_output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "mandatory_rules": mandatory, "audit": str(args.audit_output)}, indent=2))
    if report["status"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
