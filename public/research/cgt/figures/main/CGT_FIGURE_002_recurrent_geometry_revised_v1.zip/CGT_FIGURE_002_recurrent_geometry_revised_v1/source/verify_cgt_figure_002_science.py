#!/usr/bin/env python3
"""Independently rebuild every frozen Figure 2 panel table from upstream inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


ATOL = 1e-12
SCHEMES = ["context", "dataset_shrink", "dataset"]
PRIMARY_METHOD = "same_label_residual_shrink"
SEED = 1201
BOOTSTRAPS = 4000

CONTEXT_LABELS = {
    "K562_hematopoietic": "K562",
    "RPE1_epithelial": "RPE1",
    "T_cell_immune": "T cell",
    "compact_screen": "Compact screen",
    "drug_cancer_response": "Drug / cancer",
    "epithelial_cancer": "Epithelial cancer",
    "iPSC_neuron": "iPSC / neuron",
    "immune_cancer": "Immune cancer",
    "unclassified": "Unclassified",
}
SCHEME_SHORT = {"context": "Context", "dataset_shrink": "Dataset shrink", "dataset": "Dataset"}
SCHEME_LONG = {"context": "Context residual", "dataset_shrink": "Dataset-shrink residual", "dataset": "Dataset residual"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assert_frame(name: str, observed: pd.DataFrame, frozen: pd.DataFrame) -> dict[str, Any]:
    if list(observed.columns) != list(frozen.columns):
        raise AssertionError(f"{name}: column mismatch {list(observed.columns)} != {list(frozen.columns)}")
    if observed.shape != frozen.shape:
        raise AssertionError(f"{name}: shape mismatch {observed.shape} != {frozen.shape}")
    max_abs = 0.0
    for column in observed.columns:
        left = observed[column]
        right = frozen[column]
        if pd.api.types.is_numeric_dtype(left) and pd.api.types.is_numeric_dtype(right):
            a = left.to_numpy(dtype=float)
            b = right.to_numpy(dtype=float)
            if not np.allclose(a, b, rtol=0.0, atol=ATOL, equal_nan=True):
                delta = np.nanmax(np.abs(a - b))
                raise AssertionError(f"{name}.{column}: max |difference|={delta}")
            if len(a):
                finite = np.abs(a - b)[np.isfinite(a - b)]
                if len(finite):
                    max_abs = max(max_abs, float(finite.max()))
        else:
            a = left.fillna("<NA>").astype(str).to_numpy()
            b = right.fillna("<NA>").astype(str).to_numpy()
            if not np.array_equal(a, b):
                mismatch = int(np.flatnonzero(a != b)[0])
                raise AssertionError(f"{name}.{column}: row {mismatch}: {a[mismatch]!r} != {b[mismatch]!r}")
    return {"status": "pass", "rows": len(observed), "columns": len(observed.columns), "max_abs_difference": max_abs, "atol": ATOL, "rtol": 0.0}


def cluster_bootstrap(df: pd.DataFrame, group: str, rng: np.random.Generator) -> dict[str, float | int]:
    working = df[[group, "cosine"]].dropna().copy()
    stats = working.groupby(group)["cosine"].agg(["sum", "count"]).reset_index(drop=True)
    sums = stats["sum"].to_numpy(float)
    counts = stats["count"].to_numpy(float)
    values = np.empty(BOOTSTRAPS, dtype=float)
    for i in range(BOOTSTRAPS):
        sample = rng.integers(0, len(stats), size=len(stats))
        values[i] = sums[sample].sum() / counts[sample].sum()
    return {
        "mean": float(working["cosine"].mean()),
        "ci_low": float(np.quantile(values, 0.025)),
        "ci_high": float(np.quantile(values, 0.975)),
        "n_groups": int(len(stats)),
        "n_rows": int(len(working)),
    }


def rebuild(upstream: Path) -> dict[str, pd.DataFrame]:
    meta = upstream / "CGT_META_003"
    predict = upstream / "CGT_PREDICT_003B"
    atlas = pd.read_csv(meta / "CGT_META_003_universal_constraint_atlas_annotated.csv")
    family_context = pd.read_csv(meta / "CGT_META_003_family_context_row_normalized.csv")
    coordinates = pd.read_csv(predict / "CGT_PREDICT_003B_coordinates_residualized_context.csv")
    variance = pd.read_csv(predict / "CGT_PREDICT_003B_variance_decomposition.csv")
    controls = pd.read_csv(predict / "CGT_PREDICT_003B_residual_real_vs_controls.csv")

    a = coordinates.groupby("context").agg(n_observations=("label", "size"), n_datasets=("dataset", "nunique"), n_labels=("label", "nunique")).reset_index()
    a["context_label"] = a["context"].map(CONTEXT_LABELS).fillna(a["context"].str.replace("_", " ", regex=False))
    a = a.sort_values("n_observations", ascending=True).reset_index(drop=True)

    b = variance.copy()
    b["scheme_label"] = b["scheme"].map({"context": "Context mean", "dataset_shrink": "Dataset shrink", "dataset": "Dataset mean"})
    b["scheme_order"] = b["scheme"].map({name: idx for idx, name in enumerate(SCHEMES)})
    b = b.sort_values("scheme_order").reset_index(drop=True)

    order = atlas.sort_values("universality_index", ascending=False)["unsup_family"].astype(int).tolist()
    wide = family_context.set_index("unsup_family").loc[order]
    c = wide.reset_index().melt(id_vars="unsup_family", var_name="context", value_name="fraction_of_family_modes")
    c = c.merge(atlas[["unsup_family", "universality_index", "family_class"]], on="unsup_family", how="left")
    c = c[["unsup_family", "context", "fraction_of_family_modes", "universality_index", "family_class"]]

    d = atlas[["unsup_family", "n_modes", "n_datasets", "n_contexts", "universality_index", "family_class", "dominant_context", "dominant_context_fraction"]].copy()
    d["plot_x"] = d["n_datasets"].astype(float)
    d["plot_y"] = d["n_contexts"].astype(float)
    for _, duplicate in d.groupby(["n_datasets", "n_contexts"]):
        indices = duplicate.index.to_list()
        if len(indices) <= 1:
            continue
        angles = np.linspace(0, 2 * np.pi, len(indices), endpoint=False)
        for row_index, angle in zip(indices, angles):
            d.loc[row_index, "plot_x"] += 0.18 * np.cos(angle)
            d.loc[row_index, "plot_y"] += 0.11 * np.sin(angle)
    d = d.reset_index(drop=True)

    rows = []
    for scheme in SCHEMES:
        subset = controls[(controls["scheme"] == scheme) & (controls["method"] == PRIMARY_METHOD)]
        shuffled = subset[subset["control"] == "shuffled_label"].iloc[0]
        random = subset[subset["control"] == "random_label"].iloc[0]
        rows.append({
            "scheme": scheme,
            "scheme_label": SCHEME_SHORT[scheme],
            "real_mean_cosine": float(subset["real_mean_cosine"].iloc[0]),
            "shuffle_mean_cosine": float(shuffled["control_mean_cosine"]),
            "random_mean_cosine": float(random["control_mean_cosine"]),
            "shuffle_p": float(shuffled["cosine_mannwhitney_p"]),
            "random_p": float(random["cosine_mannwhitney_p"]),
            "real_n": int(shuffled["real_n"]),
        })
    e = pd.DataFrame(rows)

    leave_dataset = pd.read_csv(predict / "CGT_PREDICT_003B_residual_leave_dataset_out_benchmark.csv")
    rows = []
    for scheme in SCHEMES:
        subset = leave_dataset[
            (leave_dataset["scheme"] == scheme)
            & (leave_dataset["method"] == PRIMARY_METHOD)
        ]
        rows.append({
            "scheme": scheme,
            "generated_rows": int(len(subset)),
            "finite_cosine_rows": int(np.isfinite(subset["cosine"]).sum()),
            "zero_true_norm_rows": int((subset["residual_norm_true"] == 0).sum()),
            "zero_pred_norm_rows": int((subset["residual_norm_pred"] == 0).sum()),
        })
    e_denominators = pd.DataFrame(rows)

    specs = [
        ("Leave dataset out", leave_dataset, "heldout_dataset"),
        ("Exclude same-study proxy", predict / "CGT_PREDICT_003B_residual_excluding_same_study_proxy.csv", "heldout_dataset"),
        ("Leave context out", predict / "CGT_PREDICT_003B_residual_leave_context_out_benchmark.csv", "heldout_context"),
    ]
    loaded = [(name, frame if isinstance(frame, pd.DataFrame) else pd.read_csv(frame), group) for name, frame, group in specs]
    rng = np.random.default_rng(SEED)
    rows = []
    for scheme in SCHEMES:
        for holdout, frame, group in loaded:
            subset = frame[(frame["scheme"] == scheme) & (frame["method"] == PRIMARY_METHOD)]
            rows.append({"scheme": scheme, "scheme_label": SCHEME_LONG[scheme], "holdout": holdout, **cluster_bootstrap(subset, group, rng)})
    f = pd.DataFrame(rows)
    return {
        "Fig2a_contexts.csv": a,
        "Fig2b_variance.csv": b,
        "Fig2c_context_matrix.csv": c,
        "Fig2d_recurrence.csv": d,
        "Fig2e_controls.csv": e,
        "Fig2e_same_label_denominators.csv": e_denominators,
        "Fig2f_robustness.csv": f,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--upstream-root", type=Path, required=True)
    parser.add_argument("--frozen-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rebuilt = rebuild(args.upstream_root)
    results: dict[str, Any] = {}
    for filename, frame in rebuilt.items():
        frozen_path = args.frozen_dir / filename
        results[filename] = {
            **assert_frame(filename, frame, pd.read_csv(frozen_path)),
            "frozen_bytes": frozen_path.stat().st_size,
            "frozen_sha256": sha256(frozen_path),
        }
    report = {
        "status": "pass",
        "seed": SEED,
        "bootstrap_iterations": BOOTSTRAPS,
        "comparison": {"atol": ATOL, "rtol": 0.0},
        "tables": results,
        "analysis_universes": {
            "PREDICT-003B": {"observations": 2720, "datasets": 39, "contexts": 8, "panels": ["a", "b", "e", "f"]},
            "META-003": {"modes": 248, "datasets": 43, "contexts": 9, "families": 16, "panels": ["c", "d"]},
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
