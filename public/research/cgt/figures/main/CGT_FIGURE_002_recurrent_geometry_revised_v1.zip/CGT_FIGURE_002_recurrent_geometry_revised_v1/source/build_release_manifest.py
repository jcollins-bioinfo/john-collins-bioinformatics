#!/usr/bin/env python3
"""Build the Figure 2 release manifest (the manifest self-excludes)."""

from __future__ import annotations

import argparse
import hashlib
import json
import mimetypes
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image
from pypdf import PdfReader


MANIFEST_NAME = "CGT_FIGURE_002_release_manifest.json"

MIME_OVERRIDES = {
    ".csv": "text/csv",
    ".ipynb": "application/x-ipynb+json",
    ".json": "application/json",
    ".md": "text/markdown",
    ".py": "text/x-python",
    ".svg": "image/svg+xml",
    ".tsv": "text/tab-separated-values",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def dimensions(path: Path) -> dict[str, object] | None:
    suffix = path.suffix.lower()
    if suffix == ".png":
        with Image.open(path) as image:
            result: dict[str, object] = {
                "width_px": image.width,
                "height_px": image.height,
                "mode": image.mode,
            }
            dpi = image.info.get("dpi")
            if dpi:
                result["dpi"] = [float(dpi[0]), float(dpi[1])]
            return result
    if suffix == ".pdf":
        reader = PdfReader(path)
        page = reader.pages[0]
        width_pt = float(page.mediabox.width)
        height_pt = float(page.mediabox.height)
        return {
            "pages": len(reader.pages),
            "width_pt": width_pt,
            "height_pt": height_pt,
            "width_mm": width_pt * 25.4 / 72.0,
            "height_mm": height_pt * 25.4 / 72.0,
        }
    if suffix == ".svg":
        root = ET.parse(path).getroot()
        viewbox = root.attrib.get("viewBox", "").replace(",", " ").split()
        return {
            "width": root.attrib.get("width"),
            "height": root.attrib.get("height"),
            "viewBox": [float(value) for value in viewbox] if viewbox else None,
        }
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    output = (args.output or root / MANIFEST_NAME).resolve()
    files = []
    for path in sorted(candidate for candidate in root.rglob("*") if candidate.is_file()):
        if path.resolve() == output:
            continue
        suffix = path.suffix.lower()
        mime = MIME_OVERRIDES.get(suffix) or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        entry: dict[str, object] = {
            "path": path.relative_to(root).as_posix(),
            "bytes": path.stat().st_size,
            "mime_type": mime,
            "sha256": sha256(path),
        }
        measured = dimensions(path)
        if measured is not None:
            entry["dimensions"] = measured
        files.append(entry)
    manifest = {
        "schema": "org.johnpatrickcollins.cgt.release-manifest.v1",
        "release": root.name,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "hash_algorithm": "sha256",
        "manifest_self_excluded": True,
        "artifact_count": len(files),
        "total_artifact_bytes": sum(int(entry["bytes"]) for entry in files),
        "artifacts": files,
    }
    output.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"manifest": str(output), "artifact_count": len(files)}, indent=2))


if __name__ == "__main__":
    main()
