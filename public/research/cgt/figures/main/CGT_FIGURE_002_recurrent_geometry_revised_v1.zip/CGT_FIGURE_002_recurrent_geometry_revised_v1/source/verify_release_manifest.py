#!/usr/bin/env python3
"""Verify every Figure 2 release artifact against the release manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest_path = (args.manifest or root / "CGT_FIGURE_002_release_manifest.json").resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected = {entry["path"]: entry for entry in manifest["artifacts"]}
    actual_paths = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.resolve() != manifest_path
    }
    errors: list[str] = []
    for relative, entry in expected.items():
        path = root / relative
        if not path.is_file():
            errors.append(f"missing: {relative}")
            continue
        if path.stat().st_size != entry["bytes"]:
            errors.append(f"bytes: {relative}: {path.stat().st_size} != {entry['bytes']}")
        digest = sha256(path)
        if digest != entry["sha256"]:
            errors.append(f"sha256: {relative}: {digest} != {entry['sha256']}")
    for relative in sorted(actual_paths - set(expected)):
        errors.append(f"unexpected: {relative}")
    if len(expected) != manifest.get("artifact_count"):
        errors.append("manifest artifact_count disagrees with artifacts array")
    print(json.dumps({"status": "pass" if not errors else "fail", "checked": len(expected), "errors": errors}, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
